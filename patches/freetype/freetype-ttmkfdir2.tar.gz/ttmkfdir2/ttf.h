/* -*- C++ -*-  */
#ifndef TTF_H__
#define TTF_H__

#include <string>
#include <freetype.h>

#include "util.h"
#include "encoding.h"

namespace ttf {
    class Engine {
    public:
	Engine (void) { TT_Init_FreeType (&engine);}
	~Engine (void) {TT_Done_FreeType (engine);}
	operator TT_Engine (void) {return engine;}
    protected:
	TT_Engine engine;
    };

    typedef util::Singleton<Engine> engine;

    class Face {
    public:
	typedef std::vector<std::string> xlfdcontainer;
	Face (const std::string &filename);
	~Face (void);
	const char         *FontFamilyName (void) const;
	const char         *FoundryName (void) const;
	const char         *Weight (void) const;
	const char         *Width (void) const;
	xlfdcontainer       xlfdnames;
    protected:
	const std::string   xlfd (const string &encodingname) const;
	bool                MappingPresent (int cmapidx, NumericMapping *m);
	const char         *OS2Weight (void) const;
	const char         *PanoseWeight (void) const;
	const char         *ExtractName (int idx, bool unicode) const;
	const char         *OS2Width (void) const;
	const char         *PanoseWidth (void) const;
	mutable char        name_buffer[257];
	TT_Face             face;
	TT_Face_Properties  properties;
    };
};

#endif /* TTF_H__ */


