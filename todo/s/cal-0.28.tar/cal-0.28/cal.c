static char rcsid[]="$Id: cal.c 0.28 1994/08/27 15:54:43 tom Exp $";
/*
*  cal.c
*
*  Un*x like `cal' program (REPLACEMENT) with MORE features !
*
*  Prints a calendar (gregorian dates, before [ 1582 | 1752 ] julian dates)
*    of one specified month or of one specified year.
*    --> For further comments/information see:  text below, main()
*
*
   **************************************************************************
   *                                                                        *
   *  Thomas Esken Software , Im Hagenfeld 84 , D-48147 M"unster , GERMANY  *
   *  --------------------------------------------------------------------  *
   *                                                                        *
   *  This software doesn't claim completeness, correctitude or usability.  *
   *  On principle I will not be liable for any damages or losses, which    *
   *  result from using or handling my software. If you use this software,  *
   *  you agree without any exception to this agreement,                    *
   *                                                                        *
   *                    which binds you LEGALLY !!                          *
   *                                                                        *
   **************************************************************************
*
*
*
*  System requirements :
*  ---------------------
*    Compiler         : any? ANSI-C compiler (GCC, TCC, BCC, MSC, WCC, XLC, CC...)
*    Computer         : MS-DOS/Linux PC, Atari ST, most Un*x Workstations,
*                         OS/2 in future, perhaps some Mainfraimes
*    RAM              : below 50 KByte(Un*x/MS-DOS) load size
*    Graphics adapter : none
*    Device driver    : [n]ansi.sys recommended, but not essential
*    Harddisk         : none
*
*
*
*  This `C' program is `public domain' !!
*
*  It is written in ANSI-C style using Turbo-C (2.0, ++1.0 ...)
*  and should be able to be compiled using any ANSI-C compiler.
*
*  Any suggestions, improvements, extensions, bug reports, donations,
*  proposals for contract work, and so forth are welcome !
*  Do what you like with this source and have fun  :)
*
*
*                                    \\\_''/'
* ::-*-::-*-::-*-::-*-::-*-::-oOO    (/o-o\)    OOo-::-*-::-*-::-*-::-*-::-*-::
* :  Thomas Esken                o  (.  "  .)  o   Internet :                 :
* :  Im Hagenfeld 84              \___) ~ (___/      <esken@uni-muenster.de>  :
* :  D-48147 M"unster ; GERMANY                    Phone : (+49) 0251 232585  :
* ::-*-::-*-::-*-::-*-::-*-::-*-::-*-::-*-::-*-::-*-::-*-::-*-::-*-::-*-::-*-::
*
*
*  If you like this tool, I'd appreciate a postcard from you !!
*
*
*
*  Incomplete history (dates from my brain):
*  -----------------------------------------
*    v0.28 19940827 management of %byyyy && %yyyyy entries in rc file
*    v0.27 19940824 help screen / holiday list modified (highlighting)
*    v0.26 19940819 extended year-list / year-range mode implemented
*                     (yyyy+yyyy   yyyy;...;yyyy)
*    v0.25 19940815 extended month-list / month-range mode implemented
*                     (mm[/yyyy]-mm[/yyyy]   mm[/yyyy],...,mm[/yyyy])
*    v0.24 19940808 (quick)sorted output of rc file lines implemented (internal version)
*    v0.23 19940803 some conditional compilation statements (USE_RC) added (internal version)
*    v0.22 19940717 resource file management implemented (internal version)
*    v0.21 19940712 textual day/month names feature added
*    v0.20 19940603 variable starting day of week feature (-s1..7) added
*    v0.19 19931117 \
*     ...            | internal versions
*    v0.01 19910923 /
*/



/*
*
*  BEGIN: general program modification symbols,
*           which may be changed by the user !!
*
*/

/*
*  to adapt this program (-D`efinitions' in Makefile):
*
*  a)  - define GERMAN for using german messages
*      - delete the symbol GERMAN for using english messages
*
*  b)  - define EXT_ASCII to use the extended IBM-ASCII character set
*      - define ISO_ASCII to use the          ISO-ASCII/EBCDIC character set
*
*  c)  - define ANSISYS to run this program using the [n]ansi.sys driver
*          (ibm-pc ms/pc-dos/linux) for highlighting the actual day/holidays/text
*      - delete the symbol ANSISYS to run this program not using the
*          [n]ansi.sys driver (recent Un*ces) for highlighting the actual day
*      ... resp., replace the ANSI control sequence for highlighting the
*          actual day according to your terminal type
*            (take a look into your local termcap/terminfo file)
*
*  d)  - define USE_RC for using the special month dates functions
*          (print special dates as stated in the resource file)
*      - delete the symbol USE_RC if you don't like this feature...
*/
#define  ISO_ASCII
#define  ANSISYS
#define  USE_RC
#define  UNIX

/*
*
*  END: general program modification symbols,
*         which may be changed by the user !!
*
*/

/*
*  no further modifications, please !!!
*/





/*
*  compiler dependent pragmas
*/
#ifdef __TURBOC__
 #pragma warn -pia
 #pragma warn -def
#endif /* __TURBOC__ */



/*
*  define the symbol MSDOS for MS-DOS machines
*/
#if defined(__MSDOS__) || defined(__MSDOS) || defined(_MSDOS) || defined(MSDOS)
 #ifndef MSDOS
  #define MSDOS     /* now let's define the symbol MSDOS generally */
 #endif /* !MSDOS */
#endif /* __MSDOS__ || __MSDOS || _MSDOS || MSDOS */
#if defined(__TURBOC__) || defined(__ZTC__) || defined(M_I86xM)
 #ifndef MSDOS
  #define MSDOS     /* now let's define the symbol MSDOS generally */
 #endif /* !MSDOS */
#endif /* __TURBOC__ || __ZTC__ || M_I86xM */
/*
*  define the symbol LINUX for Linux machines
*/
#if defined(__LINUX__) || defined(__LINUX) || defined(_LINUX) || defined(LINUX)
 #ifndef LINUX
  #define LINUX     /* now let's define the symbol LINUX generally */
 #endif /* !LINUX */
#endif /* __LINUX__ || __LINUX || _LINUX || LINUX */
#if defined(__linux__) || defined(__linux) || defined(_linux) || defined(linux)
 #ifndef LINUX
  #define LINUX     /* now let's define the symbol LINUX generally */
 #endif /* !LINUX */
#endif /* __linux__ || __linux || _linux || linux */
/*
*  define the symbol UNIX for Un*x machines
*/
#if defined(__UNIX__) || defined(__UNIX) || defined(_UNIX) || defined(UNIX)
 #ifndef UNIX
  #define UNIX      /* now let's define the symbol UNIX generally */
 #endif /* !UNIX */
#endif /* __UNIX__ || __UNIX || _UNIX || UNIX */
#if defined(__unix__) || defined(__unix) || defined(_unix) || defined(unix)
 #ifndef UNIX
  #define UNIX      /* now let's define the symbol UNIX generally */
 #endif /* !UNIX */
#endif /* __unix__ || __unix || _unix || unix */
#if defined (___AIX) || defined(__AIX) || defined(_AIX) || defined(AIX)
 #ifndef UNIX
  #define UNIX      /* now let's define the symbol UNIX for these machines, too */
 #endif /* !UNIX */
#endif /* ___AIX || __AIX || _AIX || AIX */
#if defined(___aix) || defined(__aix) || defined(_aix) || defined(aix) || defined(LINUX)
 #ifndef UNIX
  #define UNIX      /* now let's define the symbol UNIX for these machines, too */
 #endif /* !UNIX */
#endif /* ___aix || __aix || _aix || aix || LINUX */


/*
*  include header files
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
/*
*  necessary for isatty()
*/
#if defined(MSDOS) || defined(ATARI)
 #include <io.h>
#else
 #if defined(LINUX)
  #include <unistd.h>
 #else /* !LINUX == UNIX   ;) */
  #include <unistd.h>   /* change line in case isatty() is anywhere */
 #endif /* LINUX */
#endif /* MSDOS || ATARI  */



/*
*  define only ONE of the symbols EXT_ASCII / ISO_ASCII
*/
#ifdef EXT_ASCII
 #ifdef ISO_ASCII
  #undef ISO_ASCII
 #endif /* ISO_ASCII */
#endif /* EXT_ASCII */
#ifdef ISO_ASCII
 #ifdef EXT_ASCII
  #undef EXT_ASCII
 #endif /* EXT_ASCII */
#endif /* ISO_ASCII */
#ifndef EXT_ASCII
 #ifndef ISO_ASCII
  #define ISO_ASCII
 #endif /* !ISO_ASCII */
#endif /* !EXT_ASCII */



/*
*  define the representation of the german `umlaute'
*/
#ifdef  EXT_ASCII
 #define  AE          "\x84"
 #define  OE          "\x94"
 #define  UE          "\x81"
 #define  SZ          "\xE1"
#else
 #define  AE          "\"a"
 #define  OE          "\"o"
 #define  UE          "\"u"
 #define  SZ          "\"s"
#endif /* EXT_ASCII */



/*
*  define the highlighting sequences
*/
#ifdef ANSISYS

#define R_MARKER	"\x1bq"
#define R_HMARKER	"\x1bq"


/* #define  R_MARKER    "\x1b[0m"
 #define  R_HMARKER   R_MARKER */

 #if defined(MSDOS) || defined(LINUX) || defined(ATARI)
  #define  L_MARKER    " \x1b[1m"
  #define  L_HM        "\x1b[36m"
  #define  L_HMARKER   " "L_HM
 #else
  #define  L_MARKER    " \x1bp"   /*" \x1b[7m"*/
  #define  L_HM        "\x1bp"
  #define  L_HMARKER   " "L_HM
 #endif /* MSDOS || LINUX || ATARI */
#else
 #ifdef EXT_ASCII
  #define  L_MARKER    "\x11"
  #define  R_MARKER    "\x10"
  #define  L_HMARKER   "\xae"
  #define  R_HMARKER   "\xaf"
 #else
  #define  L_MARKER    "<"
  #define  R_MARKER    ">"
  #define  L_HMARKER   ":"
  #define  R_HMARKER   ":"
 #endif /* EXT_ASCII */
#endif /* ANSISYS */



/*
*  basic preprocessor statements
*/
#ifndef TRUE
 #define  TRUE         (0==0)
#endif /* !TRUE */
#ifndef FALSE
 #define  FALSE        (!TRUE)
#endif /* !FALSE */
#ifndef BUFSIZ
 #define BUFSIZ        1024
#endif /* BUFSIZ */
#define  LOOP          for(;;)



/*
*  special preprocessor statements
*/
#define  PRGR_NAME     "cal"
#define  VERSION_NO    "v0.28"
#ifdef USE_RC
 #define RC_ELEMS_MAX   500
 #define REMARK_CHAR    ';'
 #define FORMAT_CHAR    '%'
 #ifdef UNIX
  #define HOME_PATH      "HOME"
  #define DIR_SEP        "/"
  #define PATH_SEP       ":"
  #define PRGR_RC_NAME   "."PRGR_NAME"rc"
 #else
  #define HOME_PATH      "PATH"
  #define DIR_SEP        "\\"
  #define PATH_SEP       ";"
  #define PRGR_RC_NAME   PRGR_NAME"rc"
 #endif /* UNIX */
#endif /* USE_RC */
#define  MLIST_SEP     ","
#define  MRANGE_SEP    "-"
#define  YLIST_SEP     ";"
#define  YRANGE_SEP    "+"
#define  YEAR_SEP      "/"
#define  OUT_ROWS      4
#define  OUT_COLS      3
#define  CENTURY       1900
#ifdef GERMAN
 #define  USAGE         "Aufruf: "
 #define  YEAR_LIT1     "jj"
 #define  YEAR_LIT2     YEAR_LIT1""YEAR_LIT1
 #define  GREGOR_YEAR   1582            /* year of gregorian reformation in most parts of germany */
 #define  GREGOR_MONTH  10              /* month of ... */
 #define  GREGOR_F_DAY  5               /* first missing day/date in oct 1582 */
 #define  GREGOR_L_DAY  14              /* last missing day/date ... */
#else
 #define  USAGE         "Usage:  "
 #define  YEAR_LIT1     "yy"
 #define  YEAR_LIT2     YEAR_LIT1""YEAR_LIT1
 #define  GREGOR_YEAR   1752            /* year of gregorian reformation in most parts of uk/usa */
 #define  GREGOR_MONTH  9               /* month of ... */
 #define  GREGOR_F_DAY  3               /* first missing day/date in sep 1752 */
 #define  GREGOR_L_DAY  13              /* last missing day/date ... */
#endif /* GERMAN */
#define  DAY_MIN       1
#define  DAY_MAX       7
#define  MONTH_MIN     1
#define  MONTH_MAX     12
#define  YEAR_MIN      1
#define  YEAR_MAX      9999
#define  EASTER_MIN    GREGOR_YEAR+1
#define  EASTER_MAX    YEAR_MAX
#define  MONTH_ROWS    7
#define  MONTH_COLS    6
/*
*  VEC_BLOCK = MONTH_ROWS * MONTH_COLS :   42 = 7 * 6
*/
#define  VEC_BLOCK     42
/*
*  VEC_ELEMS = MONTH_MAX * VEC_BLOCK :    504 = 12 * 42
*/
#define  VEC_ELEMS     504



/*
*  preprocessor macros
*/
#define  S_NEWLINE(dev)  fputc('\n',(dev))
#define  D_NEWLINE(dev)  fputs("\n\n",(dev))
#define  SYEAR(_d,_s)    (((_d)-(_s)+1) < DAY_MIN) \
                         ? ((_d)-(_s)+(DAY_MAX+1)) \
                         : ((_d)-(_s)+1)
#define  SDAY(_d,_s)     (((_d)+(_s)-1) > DAY_MAX) \
                         ? ((_d)+(_s)-(DAY_MAX+1)) \
                         : ((_d)+(_s)-1)



/*
*  cut resp., replace some long names to 6 significant places
*    so ANY linker should be able to bind an executable file
*/
#define compare_dayname         F_cd
#define compare_monthname       F_cm
#ifndef USE_RC
 #define days_of_feb             V_dof
#endif /* !USE_RC */
#define days_of_february        F_dof
#define days_of_month           V_dom
#define holiday_flag            V_hf
#define holiday_mode            V_hm
#define holiday_name            V_hn
#define holiday_vector          V_hv
#define julian_days             V_jd
#define julian_flag             V_jf
#define month_list              V_ml
#define month_name              F_mn
#define month_set               V_ms
#define print_all_holidays      F_pah
#define print_calendar          F_pc
#define print_highlighted_date  F_phd
#ifdef USE_RC
 #define print_line              V_pl
#endif /* USE_RC */
#define print_single_date       F_psd
#define print_single_holiday    F_psh
#ifdef USE_RC
 #define print_two_times         V_ptt
 #define rc_use                  F_ru
 #define rc_use_flag             V_ruf
#endif /* USE_RC */
#define short_day_name          F_sdn
#define short_month_name        F_smn



/*
*  type definitions
*/
typedef
  char
  Schar;
typedef
  int
  Sint;
typedef
  signed long int
  Slint;
typedef
  unsigned long int
  Ulint;
typedef
  Schar
  Bool;
#ifdef USE_RC
typedef
  Sint
  (*Func_cmp)(const void *,const void *);
#endif /* USE_RC */



/*
*  function prototypes
*/
#if __cplusplus
extern "C"
  {
#endif /* __cplusplus */
Sint
  my_atoi (const Schar *s);
void
  get_actual_date (void);
void
  check_command_line (      Sint   argc,
                      const Schar *argv[]);
void
  eliminate_invalid_data (void);
void
  fill_year_vector (const Sint year);
void
  print_calendar (void);
Bool
  print_single_date (Bool marker_flag);
Bool
  print_highlighted_date (      Bool   marker_flag,
                          const Schar *l_marker,
                          const Schar *r_marker);
void
  print_single_holiday (      Bool   init_data,
                        const Bool   detect,
                        const Schar *holiday_name,
                        const Schar *holiday_mode,
                              Sint   day,
                              Sint   month,
                        const Sint   year);
void
  print_all_holidays (      Bool init_data,
                      const Bool detect);
Sint
  compare_monthname (const Schar *s);
Sint
  compare_dayname (const Schar *s);
void
  build_month_list (const Schar *argv[]);
#ifdef USE_RC
Sint
  rc_sort (const Schar **a,
           const Schar **b);
Schar
  *rc_get_date (Schar *ptr_char,
                Schar *s,
                Sint  *d,
                Sint  *m,
                Sint  *y);
Bool
  rc_read_line (FILE  *fp,
                Schar *tmp_buffer,
                Sint  *line);
void
  rc_check (      Schar *tmp_buffer,
                  Schar *s,
                  Sint  *line,
                  Sint  *rc_elems,
                  Sint   day,
                  Sint   ed,
            const Sint   wd);
void
  rc_use (void);
#endif /* USE_RC */
#ifndef GERMAN
const Schar
  *day_suffix (const Sint day);
#endif /* !GERMAN */
const Schar
  *short_day_name (const Sint day);
const Schar
  *day_name (const Sint day);
const Schar
  *short_month_name (const Sint month);
const Schar
  *month_name (const Sint month);
#ifdef USE_RC
void
  prev_date (Sint *day,
             Sint *month,
             Sint *year);
void
  next_date (Sint *day,
             Sint *month,
             Sint *year);
Bool
  valid_date (const Sint day,
              const Sint month,
              const Sint year);
#endif /* USE_RC */
Sint
  weekday_of_date (const Sint day,
                   const Sint month,
                   const Sint year);
Sint
  day_of_year (const Sint day,
               const Sint month,
               const Sint year);
Sint
  days_of_february (const Sint year);
Sint
  gauss_easter_formula (const Sint year);
#if __cplusplus
  }
#endif /* __cplusplus */




/*
*  global variables
*/
struct
 {
  Sint month[MONTH_MAX+1];
  Sint year[MONTH_MAX+1];
 }      month_list;
Sint    day,
        month,
        year,
        act_day,
        act_month,
        act_year,
#ifdef GERMAN
        start_day=DAY_MIN,
#else
        start_day=DAY_MAX,
#endif /* GERMAN */
        out_rows=OUT_ROWS,
        out_cols=OUT_COLS,
        is_tty,
        is_leap_year,
        holiday_vector[MONTH_MAX][MONTH_MAX],
        year_vector[VEC_ELEMS];
Schar   name_startday[BUFSIZ+1],
        s[BUFSIZ+1];
#ifdef USE_RC
Schar  *rc_buffer[RC_ELEMS_MAX];
#endif /* USE_RC */
Bool    year_flag=FALSE,
        julian_flag=FALSE,
        holiday_flag=FALSE,
        calendar_flag=TRUE,
        highlight_flag=TRUE,
        help_flag=FALSE,
        ext_year=FALSE,
        ext_list=FALSE,
        ext_range=FALSE;
#ifdef USE_RC
Bool    rc_use_flag=FALSE,
        rc_tomorrow_flag=FALSE,
        rc_week_flag=FALSE,
        rc_month_flag=FALSE,
        rc_year_flag=FALSE,
        rc_backwards_flag=FALSE,
        rc_only_rc_flag = FALSE;
#endif /* USE_RC */






Sint
  main(      Sint   argc,
       const Schar *argv[])
/*
*  usage: cal [<switch>option(s)] [command]
*
*              <switch>   = + or - or /
*
*              [option]   = ? or h or H    --> print help screen
*
*                           r or R         --> amount of month rows [1|2|3|4|6|12]
*
*                           f or F         --> print holiday list
*
*                           j or J         --> print julian dates
*
*                           s or S<number> --> starting day of week <1..7>|<dayname>
*                                                -s1=mo,-s2=tu...-s7=su
*                                                -ssu or -ssund or -ssunday
*                                                   thus all specifies the sunday
*
*                           d or D         --> disable highlighting actual day/holiday/text
*                                               --  if symbol  ANSISYS  is defined,
*                                                   this is done automatically in
*                                                   case output is redirected/piped
*
*                        if symbol USE_RC is defined:
*
*                           c or C         --> USE RESOURCE FILE
*                                              and list dates referring to current day
*
*                        if you want to operate with the following modifieres,
*                          the -c switch MUST be leading (e.g., -ct -cw- ...)
*
*                          t or T         --> list dates referring to tomorrow, too
*
*                          w|W[+|-]       --> w|w+ = list dates between actual day
*                                                    of actual week and last day
*                                                    of actual week
*                                               w- = list dates between starting day
*                                                    of actual week and day before
*                                                    actual day of actual week
*
*                          m|M[+|-]       --> m|m+ = list dates between actual day
*                                                    of actual month and last day
*                                                    of actual month
*                                               m- = list dates between starting day
*                                                    of actual month and day before
*                                                    actual day of actual month
*
*                          y|Y[+|-]       --> y|y+ = list dates between actual day
*                                                    of actual year and last day
*                                                    of actual year
*                                               y- = list dates between starting day
*                                                    of actual year and day before
*                                                    actual day of actual year
*
*              [command]  =
*
*         cal                      --> actual month of actual year
*
*         cal  monthname           --> selected month of actual year
*                                        e.g.,  "cal may"
*
*         cal  mm-mm               --> range of actual month's
*                                        e.g.,  "cal 3-7     or   cal 11-8"
*                                               "cal mar-dec or   cal 12-aug"
*
*         cal  mm/yyyy-mm/yyyy     --> range of month's of year
*                                        e.g.,  "cal 3/1991-july/1992"
*                                               "cal dec/1994-3"
*                                               "cal sep-dec/2000"
*
*         cal  mm,...,mm           --> list of actual month's (maximum 12)
*                                        e.g.,  "cal 1,5,12  or   cal 3,1,5,3"
*                                               "cal june,9,jan"
*
*         cal  mm/yyyy,...,mm/yyyy --> list of month's of year (maximum 12)
*                                        e.g.,  "cal 1/1992,5,12/2001"
*                                               "cal june/1991,9/1801,jan"
*
*         cal  mm-mm yyyy          --> range of specified month's of selected year
*
*         cal  mm,...,mm yyyy      --> list of specified month's of selected year (maximum 12)
*
*         cal  mm yyyy             --> single month of selected year
*
*         cal  yyyy                --> selected year
*
*         cal  yyyy+yyyy           --> range of specified years
*
*         cal  yyyy;...;yyyy       --> list of specified years (maximum 12)
*
*
*         NOTE: `mm' is either a number or a monthname (you may use both notations mixed)
*               the range of `mm' is valid from `1' to `12'
*                                 or valid from `january'...`december'
*               (you may abbreviate the monthnames in case you do it significant)
*
*               `yyyy' is a number
*               the range of `yyyy' is valid from `1' to `9999'
*
*
*
*  you may create a `cal' resource file for showing special month dates !
*  the use/management of the resource file is done by `cal' ONLY, if you
*  define the preprocessor symbol  USE_RC  !!!
*
*  every time you execute `cal' in single month mode
*    (referencing the current month of actual year)
*
*    e.g.:   todays date is: may 27th 1994
*
*            cal -c
*            cal -c may
*            cal -c 5 1994
*
*  it checks the resource file for dates and processes those that refer to
*  the current date
*
*  you can list dates of past/present/future years, too
*
*    e.g.:   cal -c 1993        --> list all date entries referring to entire 1993
*                                   and all eternal date entries referring to entire 1993
*            cal -c july 1993   --> list all date entries referring to july 1993
*                                   and all eternal date referring to july 1993
*
*
*  the name of the resource file MUST be:
*    --  Un*x-systems:  .calrc
*    --  otherwise:     calrc
*
*  the `cal' program expects the resource file in the actual directory
*  if it's not found, `cal' inspects:
*    --  Un*x-systems:  the $HOME directory
*    --  otherwise:     the PATH-environment variable
*  and scans the referenced directory(s) for the resource file
*
*
*  the structure of the resource file is:
*
*    yyyymmdd `text'
*
*    where:  yyyy   is the year including the century (range 0000..9999)
*              mm   is the month (range 00..12)
*              dd   is the day (range 00..31) or a weekday-name (range mo..su)
*           `text'  is any text you like
*
*    e.g., 19940715 dentist
*          00000921 my %b1962 birthday
*          00000903 gregorian reformation is %y1752 year ago
*          00000000 every day in every month in every year
*          199400fr every friday in 1994
*          000007mo every monday in july every year
*
*    NOTE: between yyyymmdd and `text' may occur whitespace characters (tab, blank...)
*
*          if yyyy is specified as 0000:
*            the month and day are assumed to be annual events
*            and the `text' will be displayed for any year
*          if mm is specified as 00:
*            the day is assumed to be a monthly event for the specified year
*            and the `text' will be displayed for any month
*          if dd is specified as 00:
*            each day is assumed to be a dayly event for the specified year
*            and month and the `text' will be displayed for any day
*          if dd is specified as a (short %2s)weekday-name:
*            the given weekday-name is assumed to be a weekly event for the
*            specified year and month and the `text' will be displayed for
*            any week
*
*          the `text' of a resource file line may contain two special macros:
*            1) %byyyy references a year of birth and is converted to an age value
*                 e.g., the line `my %b1962 birthday'
*                       will be expanded to `my 32nd birthday'
*                       in case the current year is 1994
*               the year of birth entries are evaluated/respeced only
*               if the age value is >0
*            2) %yyyyy references any year and is converted to an age value
*                 e.g., the line `sylvester 1912 is %y1912 years ago'
*                       will be expanded to `sylvester 1912 is -82 years ago'
*                       in case the current year is 1994
*
*
*          yyyymmdd  accepted command line switches
*          ----------------------------------------
*          00000000  c, ct
*          000000dd  c, ct, cw, cm
*          0000mm00  c, ct
*          0000mmdd  c, ct, cw, cm, cy
*          yyyy0000  c, ct
*          yyyy00dd  c, ct, cw, cm
*          yyyymm00  c, ct
*          yyyymmdd  c, ct, cw, cm, cy
*          000000wn  c, ct, cw          ---
*          0000mmwn  c, ct, cw             \  `wn' is a short weekday-name
*          yyyy00wn  c, ct, cw             /    (two places, e.g., mo, tu, we ...)
*          yyyymmwn  c, ct, cw          ---
*
*
*  a line beginning with a `;'-character in the resource file is treated as
*  a remark and will not be used by `cal'.
*
*
*
*  `cal' produces the following exit-codes:
*
*    255 = request for help screen
*    254 = invalid option
*    253 = year out of range for computing easter
*    252 = malloc() fails
*    251 = invalid date entry in resource file
*    250 = invalid month entry in resource file
*    249 = invalid day entry in resource file
*      0 = normal program termination
*/
 {
   setbuf(stdout,NULL);
   is_tty = isatty(1);
   get_actual_date ();
   check_command_line (argc,argv);
   eliminate_invalid_data ();
   if (   !year
       && holiday_flag)
     calendar_flag = FALSE;
   if (   !ext_list
       && !ext_range)
    {
      is_leap_year = (days_of_february (year) == 29);
      fill_year_vector (year);
      /*
         get the actual dates of holidays, used for highlighting the calendar
      */
      if (   (year >= EASTER_MIN)
          && (year <= EASTER_MAX))
        print_all_holidays (FALSE,TRUE);
    }
   if (calendar_flag)
     if (! rc_only_rc_flag)
       print_calendar ();
   if (!month_list.month [1])
    {
#ifdef USE_RC
      /*
         if not omitted, read resource file from:      actual path,
         if not found, search environment variable:    %PATH (MS/PC-DOS)
                                         resp.,:    $HOME (Un*x)
      */
      if (   calendar_flag
          && rc_use_flag)
        rc_use ();
#endif /* USE_RC */
      if (holiday_flag)
       {
         if (   year < EASTER_MIN
             || year > EASTER_MAX)
          {
#ifdef GERMAN
            fputs("\nUnzul"AE"ssiges Jahr f"UE"r Ostertagsberechnung !\n",stderr);
            fprintf(stderr,"Jahr mu"SZ" im Bereich (%d..%d) sein\n",
                    EASTER_MIN,EASTER_MAX);
#else
            fputs("\nInvalid year for computing easter !\n",stderr);
            fprintf(stderr,"Year must be in range (%d..%d)\n",
                    EASTER_MIN,EASTER_MAX);
#endif /* GERMAN */
#ifdef ISO_ASCII
            S_NEWLINE(stderr);
#endif /* ISO_ASCII */
            exit(253);
          }
         print_all_holidays (FALSE,FALSE);
       }
    }
#ifdef ISO_ASCII
   S_NEWLINE(stdout);
#endif /* ISO_ASCII */

   return(0);
 }





/*
*  function implementations
*/
 Sint
   my_atoi (const Schar *s)
 /*
    converts string `s' to a numerical value
      and returns values in range 0..9999 only (invalid values are set to 0)
 */
  {
    if (   *s == '-'
        || strlen(s) > 4)
      return(0);


    return(atoi(s));
  }


 void
   get_actual_date (void)
 /*
    like the function name says
 */
  {
    auto struct tm      *sys_date;
    auto        time_t   sys_time;


    sys_time = time(NULL);
    sys_date = localtime(&sys_time);
    act_day = sys_date->tm_mday;
    act_month = sys_date->tm_mon + 1;
    act_year = sys_date->tm_year;
    if (act_year < CENTURY)
      act_year += CENTURY;
  }


 void
   check_command_line (      Sint   argc,
                       const Schar *argv[])
 /*
    like the function name says
 */
  {
    auto   const Schar  *option;
#ifdef USE_RC
    static const Schar  *usage_msg={USAGE""PRGR_NAME" [<+|-|/>{[?|h] | "
                                    "{r<1|2|3|4|6|12>|f|j|s<n>|d|c}}]  "
                                    "[[mm] <"YEAR_LIT2">]\n"};
#else
                        *usage_msg={USAGE""PRGR_NAME" [<+|-|/>{[?|h] | "
                                    "{r<1|2|3|4|6|12>|f|j|s<n>|d}}]  "
                                    "[[mm] <"YEAR_LIT2">]\n"};
#endif /* USE_RC */


    while (argc > 1)
     {
       option = *++argv;
       if (   *option == '+'
           || *option == '-'
           || *option == '/')
        {
          for (option++ ; *option ; option++)
           {
             switch (*option)
              {
                case '?':
                case 'h':
                case 'H':
                  help_flag = TRUE;
                  break;
                case 'f':
                case 'F':
                  holiday_flag = TRUE;
                  break;
                case 'j':
                case 'J':
                  julian_flag = TRUE;
                  break;
                case 'd':
                case 'D':
                  highlight_flag = FALSE;
                  break;
                case 'r':
                case 'R':
                  year_flag = TRUE;
                  option++;
                  out_rows = my_atoi (option);
                  if (   !*option
                      || out_rows > MONTH_MAX
                      || out_rows < MONTH_MIN)
                    option--;
                  else
                    if (   out_rows < 1
                        || out_rows > 9)
                      {
                        while (*option)
                          option++;
                        option--;
                      }
                  break;
                case 's':
                case 'S' :
                  option++;
                  if (*option)
                   {
                     register Sint  i=0;


                     while (   *option
                            && (i < BUFSIZ))
                       name_startday [i++] = *(option++);
                     name_startday [i] = '\0';
                     start_day = my_atoi (name_startday);
                   }
                  else
                    start_day = 0;
                  if (   !*option
                      || start_day > DAY_MAX
                      || start_day < DAY_MIN)
                    option--;
                  else
                    if (   start_day < 1
                        || start_day > 9)
                     {
                       while (*option)
                         option++;
                       option--;
                     }
                  break;
#ifdef USE_RC
                case 'o':
                case 'O':
                  rc_only_rc_flag = TRUE;
                  break;
                case 'c':
                case 'C':
                  rc_use_flag = TRUE;
                  break;
                case 't':
                case 'T':
                  rc_tomorrow_flag = TRUE;
                  break;
                case 'w':
                case 'W':
                  if (   !rc_month_flag
                      && !rc_year_flag)
                    rc_week_flag = TRUE;
                  option++;
                  if (*option)
                   {
                     rc_backwards_flag = (Bool)(*option == '-');
                     while (*option)
                       option++;
                   }
                  option--;
                  break;
                case 'm':
                case 'M':
                  if (   !rc_week_flag
                      && !rc_year_flag)
                    rc_month_flag = TRUE;
                  option++;
                  if (*option)
                   {
                     rc_backwards_flag = (Bool)(*option == '-');
                     while (*option)
                       option++;
                   }
                  option--;
                  break;
                case 'y':
                case 'Y':
                  if (   !rc_week_flag
                      && !rc_month_flag)
                    rc_year_flag = TRUE;
                  option++;
                  if (*option)
                   {
                     rc_backwards_flag = (Bool)(*option == '-');
                     while (*option)
                       option++;
                   }
                  option--;
                  break;
#endif /* USE_RC */
                default:
#ifdef GERMAN
                  fprintf(stderr,"\nUnbekannte Option: %s\n%s",*argv,usage_msg);
#else
                  fprintf(stderr,"\nUnknown option: %s\n%s",*argv,usage_msg);
#endif /* GERMAN */
#ifdef ISO_ASCII
                  S_NEWLINE(stderr);
#endif /* ISO_ASCII */
                  exit(254);
              }
           }
          argc--;
        }
       else
         break;
     }
    if (help_flag)
     {
#ifndef ISO_ASCII
       S_NEWLINE(stdout);
#endif /* !ISO_ASCII */
#ifdef ANSISYS
       if (   is_tty
           && highlight_flag)
         fputs(L_HM,stdout);
#endif /* ANSISYS */
       fputs(PRGR_NAME,stdout);
#ifdef ANSISYS
       if (   is_tty
           && highlight_flag)
         fputs(R_HMARKER,stdout);
#endif /* ANSISYS */
#ifdef GERMAN
       fputs(" :   Erweitertes Un*x `calendar' Programm  (",stdout);
#else
       fputs(" :   Extended Un*x `calendar' program  (",stdout);
#endif /* GERMAN */
#ifdef ANSISYS
       if (   is_tty
           && highlight_flag)
         fputs(L_HM,stdout);
#endif /* ANSISYS */
       fputs(VERSION_NO,stdout);
#ifdef ANSISYS
       if (   is_tty
           && highlight_flag)
         fputs(R_HMARKER,stdout);
#endif /* ANSISYS */
       fputs(")\n",stdout);
       fprintf(stdout,"\n%s\n",usage_msg);
#ifdef GERMAN
       fprintf(stdout,
               "-? -h = Dieser Hilfetext\n"
               "-r<n> = Ausgabe des Jahreskalenders in %d...%d Monatsbl"OE"cken\n"
               "-f    = Ausgabe der Feiertagsliste (Jahr im Bereich %d...%d)\n"
               "-j    = Ausgabe in julianischem Datumsformat\n"
               "-s<n> = Starttag der Woche (Bereich: %d=%s, %d=%s...%d=%s | Wochentagsname)\n"
               "-d    = Aktuellen Tag/Feiertag/Text ohne Hervorhebung ausgeben\n"
 #ifdef USE_RC
               "-c    = Inhalt der Ressourcendatei `%s' ber"UE"cksichtigen\n"
               "        >> Zus"AE"tzliche Optionen:  -ct, -cw, -cw-, -cm, -cm-, -cy, -cy-\n"
 #endif /* USE_RC */
               "mm    = Monat im Bereich [%d...%d]"
               "        Liste:   mm["YEAR_SEP""YEAR_LIT2"]"MLIST_SEP"..."
               MLIST_SEP"mm["YEAR_SEP""YEAR_LIT2"]\n                                 "
               "        Bereich: mm["YEAR_SEP""YEAR_LIT2"]"MRANGE_SEP"mm["YEAR_SEP""YEAR_LIT2"]\n"
               YEAR_LIT2"  = Jahr  im Bereich [%d...%d]"
               "      Liste:   "YEAR_LIT2""YLIST_SEP"..."YLIST_SEP""YEAR_LIT2"\n"
               "                                   "
               "      Bereich: "YEAR_LIT2""YRANGE_SEP""YEAR_LIT2"\n"
               "        ( Bei zweistelliger Jahresangabe wird NICHT von "
               "%2d"YEAR_LIT1" ausgegangen )\n\n",
               MONTH_MIN,MONTH_MAX,
               EASTER_MIN,EASTER_MAX,
               DAY_MIN,short_day_name (DAY_MIN),
               DAY_MIN+1,short_day_name (DAY_MIN+1),
               DAY_MAX,short_day_name (DAY_MAX),
 #ifdef USE_RC
               PRGR_RC_NAME,
 #endif /* USE_RC */
               MONTH_MIN,MONTH_MAX,
               YEAR_MIN,YEAR_MAX,
               act_year / 100);
#else
       fprintf(stdout,
               "-? -h = This help screen\n"
               "-r<n> = Output of year calendar divided into %d...%d month block(s)\n"
               "-f    = Output of holiday list (year must be in range %d...%d)\n"
               "-j    = Output of julian dates\n"
               "-s<n> = Starting day of week (Range: %d=%s, %d=%s...%d=%s | name of weekday)\n"
               "-d    = Disable highlighting of actual day/holiday/text\n"
 #ifdef USE_RC
               "-c    = List/respect contents of resource file `%s'\n"
               "        >> Additional options:  -ct, -cw, -cw-, -cm, -cm-, -cy, -cy-\n"
 #endif /* USE_RC */
               "mm    = Month in range [%d...%d]"
               "        List:  mm["YEAR_SEP""YEAR_LIT2"]"MLIST_SEP"..."
               MLIST_SEP"mm["YEAR_SEP""YEAR_LIT2"]\n                               "
               "        Range: mm["YEAR_SEP""YEAR_LIT2"]"MRANGE_SEP"mm["YEAR_SEP""YEAR_LIT2"]\n"
               YEAR_LIT2"  = Year  in range [%d...%d]"
               "      List:  "YEAR_LIT2""YLIST_SEP"..."YLIST_SEP""YEAR_LIT2"\n"
               "                                 "
               "      Range: "YEAR_LIT2""YRANGE_SEP""YEAR_LIT2"\n"
               "        ( If you specify two digits for the year "
               "I DON'T assume %2d"YEAR_LIT1" )\n\n",
               MONTH_MIN,MONTH_MAX,
               EASTER_MIN,EASTER_MAX,
               DAY_MIN,short_day_name (DAY_MIN),
               DAY_MIN+1,short_day_name (DAY_MIN+1),
               DAY_MAX,short_day_name (DAY_MAX),
 #ifdef USE_RC
               PRGR_RC_NAME,
 #endif /* USE_RC */
               MONTH_MIN,MONTH_MAX,
               YEAR_MIN,YEAR_MAX,
               act_year / 100);
#endif /* GERMAN */
#ifdef GERMAN
       fputs("`"PRGR_NAME"' ist `public domain' !!       ",stdout);
#else
       fputs("`"PRGR_NAME"' is `public domain' !!        ",stdout);
#endif /* GERMAN */
#ifdef ANSISYS
       if (   is_tty
           && highlight_flag)
         fputs(L_HM,stdout);
#endif /* ANSISYS */
       fputs("\\\\\\_''/'",stdout);
#ifdef ANSISYS
       if (   is_tty
           && highlight_flag)
         fputs(R_HMARKER,stdout);
#endif /* ANSISYS */
#ifdef GERMAN
       fputs("              Viel Spa"SZ" damit  :)\n",stdout);
#else
       fputs("                     Have fun  :)\n",stdout);
#endif /* GERMAN */
#ifdef ANSISYS
       if (   is_tty
           && highlight_flag)
         fputs(L_HM,stdout);
#endif /* ANSISYS */
       fputs("::-*-::-*-::-*-::-*-::-*-::-oOO    (/o-o\\) "
             "   OOo-::-*-::-*-::-*-::-*-::-*-::\n"
             ":  Thomas Esken                o  (.  \"  .)"
             "  o   Internet :                 :\n"
             ":  Im Hagenfeld 84              \\___) ~ (__"
             "_/      <esken@uni-muenster.de>  :\n"
             ":  D-48147 M\"unster ; GERMANY              "
             "      Phone : (+49) 0251 232585  :\n"
             "::-*-::-*-::-*-::-*-::-*-::-*-::-*-::-*-::-"
             "*-::-*-::-*-::-*-::-*-::-*-::-*-::",stdout);
#ifdef ANSISYS
       if (   is_tty
           && highlight_flag)
         fputs(R_HMARKER,stdout);
#endif /* ANSISYS */
#ifdef ISO_ASCII
       S_NEWLINE(stdout);
#endif /* ISO_ASCII */
       exit(255);
     }
    /*
       check the command-line for commands
    */
    if (argc > 1)
     {
       register Sint  i;
       auto     Bool  list=FALSE,
                      range=FALSE,
                      month_set=FALSE;


       for ( ; argc > 1 ; argc--,argv++)
        {
          if (!month)
           {
             option = *argv;
             i = 0;
             while (*option)
              {
                if (   *option == *MLIST_SEP
                    || *option == *YLIST_SEP)
                  list = TRUE;
                else
                  if (   *option == *MRANGE_SEP
                      || *option == *YRANGE_SEP)
                    range = TRUE;
                s [i++] = *(option++);
              }
             s [i] = '\0';
             if (   !list
                 && !range
                 && !my_atoi(s))
              {
                month = compare_monthname (s);
                if (month)
                 {
                   month_set = TRUE;
                   continue;
                 }
              }
           }
          if (!month)
           {
             build_month_list (argv);
             if (!*month_list.month)
               month = my_atoi (*argv);
             else
               month = *month_list.month;
             if (   month < MONTH_MIN
                 || month > MONTH_MAX)
              {
                year = month;
                month = 0;
                break;
              }
           }
          else
            if (!year)
              year = my_atoi (*argv);
        }
       if (   month
           && !year
           && !month_set
           && !*month_list.month)
         year = month,month = 0;
     }
#ifdef ANSISYS
    if (!is_tty)
      highlight_flag = FALSE;
#endif /* ANSISYS */
  }


 void
   eliminate_invalid_data (void)
 /*
    like the function name says
 */
  {
    if (   !month
        && !year)
     {
       month = act_month;
       year = act_year;
     }
    else
      if (   year < YEAR_MIN
          || year > YEAR_MAX)
       {
         if (   month
             && year)
           month = act_month;
         year = act_year;
       }
    if (   year_flag
        && month)
      month = 0;
    if (   month
        && !*month_list.month)
      *month_list.month = month;
    switch (out_rows)
     {
       case 1:
         out_cols = MONTH_MAX;
         break;
       case 2:
         out_cols = 6;
         break;
       case 3:
         out_cols = 4;
         break;
       case 4:
         out_cols = 3;
         break;
       case 6:
         out_cols = 2;
         break;
       case 12:
         out_cols = MONTH_MIN;
         break;
       default:
         out_rows = OUT_ROWS;
     }
    /*
       check for delivered weekday-name
    */
    if (   !start_day
        && *name_startday)
      start_day = compare_dayname (name_startday);
    if (   start_day > DAY_MAX
        || start_day < DAY_MIN)
#ifdef GERMAN
      start_day = DAY_MIN;
#else
      start_day = DAY_MAX;
#endif /* GERMAN */
  }


 void
   fill_year_vector (const Sint year)
 /*
    like the function name says
 */
  {
    register Sint  i=weekday_of_date (DAY_MIN,MONTH_MIN,year),
#ifndef USE_RC
                   days_of_feb=days_of_february (year),
#endif /* !USE_RC */
                   count,
                   d,m;


    /*
       first, detect starting day of the year
    */
    i=day = SYEAR(i,start_day);
    d=count = 0;
    m = MONTH_MIN;
    /*
       then, fill the year_vector
    */
    LOOP
     {
       d++;
       count++;
#ifdef USE_RC
       if (!valid_date (d,m,year))
#else
       if (   d > 31
           || (   (d > 30)
               && (   m == 4
                   || m == 6
                   || m == 9
                   || m == 11))
           || (   (d > days_of_feb)
               && (m == 2)))
#endif /* USE_RC */
        {
          if (m < MONTH_MAX)
           {
             d = DAY_MIN;
             i = m * VEC_BLOCK + day;
             m++;
           }
          else
            break;
        }
       if (   (year == GREGOR_YEAR)
           && (m == GREGOR_MONTH)
           && (   (d >= GREGOR_F_DAY)
               && (d <= GREGOR_L_DAY)))
         i--;
       else
        {
          day++;
          if (julian_flag)
            year_vector [i-1] = count;
          else
            year_vector [i-1] = d;
        }
       i++;
       if (day > DAY_MAX)
         day = DAY_MIN;
     }
  }


 void
   print_calendar (void)
 /*
    prints out the whole month resp., year calendar
 */
  {
    auto           Slint  amount=0L,
                          count;
    register       Sint   tmp_ad=act_day,
                          i=0,
                          d,m,
                          hday,hmonth;
    static   const Sint   scale1[]={9,13},
                          scale2[]={13,19};
    auto           Bool   marker_flag=FALSE,
                          backwards=FALSE;


    if (   !ext_list
        && !ext_range
        && julian_flag)
      act_day = day_of_year (act_day,act_month,act_year);
    if (!ext_range)
      for ( ; month_list.month [i] ; i++)
       {
         if (!month_list.year [i])
           month_list.year [i] = act_year;
         amount++;
       }
    else
     {
       if (!ext_year)
        {
          if (!*month_list.year)
            *month_list.year = act_year;
          if (!month_list.year [1])
            month_list.year [1] = act_year;
          if (backwards=(Bool)(*month_list.year > month_list.year [1]))
            amount = (((*month_list.year - 1L) - month_list.year [1]) * MONTH_MAX)
                       + *month_list.month + ((MONTH_MAX - month_list.month [1]) + 1L);
          else
            amount = (((month_list.year [1] - 1L) - *month_list.year) * MONTH_MAX)
                       + month_list.month [1] + ((MONTH_MAX - *month_list.month) + 1L);
          month = *month_list.month;
          year = *month_list.year;
        }
       else
        {
          if (backwards=(Bool)(*month_list.month > month_list.month [1]))
            amount = (*month_list.month - month_list.month [1]) + 1L;
          else
            amount = (month_list.month [1] - *month_list.month) + 1L;
          year = *month_list.month;
        }
     }
    if (!amount)
      amount++;
    for (count=0L ; count < amount ; count++)
     {
       if (   !ext_list
           && !ext_range)
        {
          if (!ext_year)
            month = month_list.month [(Sint)count];
        }
       else
        {
          d = 0;
          if (ext_list)
           {
             if (!ext_year)
              {
                month = month_list.month [(Sint)count];
                if (   count
                    && (year == month_list.year [(Sint)count]))
                  d = year;
                else
                  year = month_list.year [(Sint)count];
              }
             else
              {
                month = 0;
                if (   count
                    && (year == month_list.month [(Sint)count]))
                  d = year;
                else
                  year = month_list.month [(Sint)count];
              }
           }
          else
            if (   ext_range
                && count)
             {
               if (!ext_year)
                {
                  d = year;
                  if (backwards)
                   {
                     month--;
                     if (month < MONTH_MIN)
                       month = MONTH_MAX,year--;
                   }
                  else
                   {
                     month++;
                     if (month > MONTH_MAX)
                       month = MONTH_MIN,year++;
                   }
                }
               else
                {
                  month = 0;
                  if (backwards)
                    year--;
                  else
                    year++;
                }
             }
            else
              if (ext_year)
                month = 0;
          if (d != year)
           {
             is_leap_year = (days_of_february (year) == 29);
             for (i=0 ; i < VEC_ELEMS ; i++)
               year_vector [i] = 0;
             fill_year_vector (year);
             if (   (year >= EASTER_MIN)
                 && (year <= EASTER_MAX))
               print_all_holidays (TRUE,TRUE);
             else
               for (i=0 ; i < MONTH_MAX ; i++)
                 holiday_vector [i] [0] = 0;
             if (julian_flag)
               act_day = day_of_year (act_day,act_month,act_year);
           }
        }
       if (    !ext_year
            && (   month
                || ext_list
                || ext_range))
        {
          fprintf(stdout,"\n%s %04d\n\n",month_name (month),year);
          for (i=1 ; i <= MONTH_ROWS ; i++)
           {
#ifdef GERMAN
             fprintf(stdout,"%-11s",day_name (SDAY(i,start_day)));
#else
             fprintf(stdout,"%-10s",day_name (SDAY(i,start_day)));
#endif /* GERMAN */
             for (d=1 ; d <= MONTH_COLS ; d++)
              {
                day = (  (month - 1) * VEC_BLOCK - 1)
                       + (d * MONTH_ROWS - MONTH_COLS) + (i - 1);
                if (   highlight_flag
                    && (year_vector [day] == act_day)
                    && (month == act_month)
                    && (year == act_year))
                  marker_flag = print_highlighted_date (marker_flag,L_MARKER,R_MARKER);
                else
                 {
                   hday = 0;
                   if (   year_vector [day]
                       && *holiday_vector [month-1])
                    {
                      register Sint  k;


                      for (k=0 ; holiday_vector [month-1] [k] ; k++)
                        if (holiday_vector [month-1] [k] == year_vector [day])
                         {
                           hday = holiday_vector [month-1] [k];
                           break;
                         }
                    }
                   if (   hday
                       && highlight_flag)
                     marker_flag = print_highlighted_date (marker_flag,L_HMARKER,R_HMARKER);
                   else
                     marker_flag = print_single_date (marker_flag);
                 }
              }
             S_NEWLINE(stdout);
           }
          if (   rc_use_flag
              && (   ext_list
                  || ext_range
                  || amount > 1))
           {
             if (   (month == act_month)
                 && (year == act_year))
              {
                act_year--;
                rc_use ();
                act_year++;
              }
             else
               rc_use ();
           }
        }
       else
        {
          fprintf(stdout,"\n\n%*d\n\n\n",scale1 [(Sint)julian_flag]*out_cols,year);
          for (m=0 ; m < out_rows ; m++)
           {
             for (i=1 ; i <= out_cols ; i++)
               fprintf(stdout,"     %-*s",
                       scale2 [(Sint)julian_flag],month_name (m*out_cols+i));
             D_NEWLINE(stdout);
             for (i=1 ; i <= MONTH_ROWS ; i++)
              {
                fprintf(stdout,"%-4s",short_day_name (SDAY(i,start_day)));
                for (d=1 ; d <= MONTH_COLS * out_cols ; d++)
                 {
                   day = (  (m * out_cols) * VEC_BLOCK - 1)
                          + (d * MONTH_ROWS - MONTH_COLS) + (i - 1);
                   hmonth = (m * out_cols) + ((d-1) / MONTH_COLS) + 1;
                   if (   highlight_flag
                       && (year_vector [day] == act_day)
                       && (hmonth == act_month)
                       && (year == act_year))
                     marker_flag = print_highlighted_date (marker_flag,L_MARKER,R_MARKER);
                   else
                    {
                      hday = 0;
                      if (   year_vector [day]
                          && *holiday_vector [hmonth-1])
                       {
                         register Sint  k;


                         for (k=0 ; holiday_vector [hmonth-1] [k] ; k++)
                           if (holiday_vector [hmonth-1] [k] == year_vector [day])
                            {
                              hday = holiday_vector [hmonth-1] [k];
                              break;
                            }
                       }
                      if (   hday
                          && highlight_flag)
                        marker_flag = print_highlighted_date (marker_flag,L_HMARKER,R_HMARKER);
                      else
                        marker_flag = print_single_date (marker_flag);
                    }
                 }
                S_NEWLINE(stdout);
              }
             if (m < out_rows-1)
               D_NEWLINE(stdout);
           }
          if (   rc_use_flag
              && (   ext_list
                  || ext_range))
            rc_use ();
          if (   ext_year
              && holiday_flag
              && (year >= EASTER_MIN)
              && (year <= EASTER_MAX))
           {
             print_all_holidays (FALSE,FALSE);
           }
        }
     }
    if (julian_flag)
      act_day = tmp_ad;
  }


 Bool
   print_single_date (Bool marker_flag)
 /*
    like the function name says
 */
  {
    if (julian_flag)
     {
       if (year_vector [day])
        {
          if (marker_flag)
           {
             fprintf(stdout,"%3d",year_vector [day]);
             marker_flag = FALSE;
           }
          else
           fprintf(stdout,"%4d",year_vector [day]);
        }
       else
        {
          if (marker_flag)
           {
             fputs("   ",stdout);
             marker_flag = FALSE;
           }
          else
            fputs("    ",stdout);
        }
     }
    else
     {
       if (year_vector [day])
        {
          if (marker_flag)
           {
             fprintf(stdout,"%2d",year_vector [day]);
             marker_flag = FALSE;
           }
          else
            fprintf(stdout,"%3d",year_vector [day]);
        }
       else
        {
          if (marker_flag)
           {
             fputs("  ",stdout);
             marker_flag = FALSE;
           }
          else
            fputs("   ",stdout);
        }
     }
/*
    previous could be written like this (but that's hard to read ;)

    (julian_flag)
      ? (year_vector [day])
        ? (marker_flag)
          ? fprintf(stdout,"%3d",year_vector [day]),
            marker_flag = FALSE
          : fprintf(stdout,"%4d",year_vector [day])
        : (marker_flag)
          ? fputs("   ",stdout),
            marker_flag = FALSE
          : fputs("    ",stdout)
      : (year_vector [day])
        ? (marker_flag)
          ? fprintf(stdout,"%2d",year_vector [day]),
            marker_flag = FALSE
          : fprintf(stdout,"%3d",year_vector [day])
        : (marker_flag)
          ? fputs("  ",stdout),
            marker_flag = FALSE
          : fputs("   ",stdout);
*/

    return(marker_flag);
  }


 Bool
   print_highlighted_date (      Bool   marker_flag,
                           const Schar *l_marker,
                           const Schar *r_marker)
 /*
    like the function name says
 */
  {
    if (julian_flag)
      fprintf(stdout,"%s%3d%s",l_marker,year_vector [day],r_marker);
    else
      fprintf(stdout,"%s%2d%s",l_marker,year_vector [day],r_marker);
#ifndef ANSISYS
    marker_flag = TRUE;
#endif /* !ANSI_SYS */

    return(marker_flag);
  }


 void
   print_single_holiday (      Bool   init_data,
                         const Bool   detect,
                         const Schar *holiday_name,
                         const Schar *holiday_mode,
                               Sint   day,
                               Sint   month,
                         const Sint   year)
 /*
    prints a single holiday date to stdout in formated manner
 */
  {
    register Sint  i,
                   hd;
    static   Sint  hcount[MONTH_MAX];


    if (init_data)
      for (i=0 ; i < MONTH_MAX ; i++)
        hcount [i] = 0;
    if (!month)
     {
       if (day-is_leap_year > 59)
        {
          month = (Sint)((63 + day - is_leap_year) / 30.61) - 1;
          day = (Sint)(63 + day - is_leap_year - abs((Sint)((month + 1) * 30.61)));
        }
       else
        {
          month = (Sint)((428 + day) / 30.61) - 13;
          day = (Sint)(428 + day - abs((Sint)((month + 13) * 30.61)));
        }
     }
    hd = day_of_year (day,month,year);
    if (!detect)
     {
       i = hd - day_of_year (act_day,act_month,act_year);
       fprintf(stdout,"%-*s  %-1s  ",25,holiday_name,holiday_mode);
#ifdef GERMAN
       fprintf(stdout,"ist %2s, der",short_day_name (weekday_of_date (day,month,year)));
       if (!i)
 #ifdef ANSISYS
         fprintf(stdout,"%s%2d%s ",L_MARKER,day,R_MARKER);
 #else
         fprintf(stdout,"%s%2d%s",L_MARKER,day,R_MARKER);
 #endif /* ANSISYS */
       else
         fprintf(stdout," %2d ",day);
       if (year == act_year)
         fprintf(stdout,"%s %-4d  >>  %+4d Tag%s\n",short_month_name (month),year,i,
                        (abs(i) == 1)
                        ? ""
                        : "e");
       else
         fprintf(stdout,"%s %-4d\n",short_month_name (month),year);
#else
       fprintf(stdout,"is %2s, %s ",short_day_name (weekday_of_date (day,month,year)),
                      short_month_name (month));
       if (!i)
 #ifdef ANSISYS
         fprintf(stdout,"%s%2d%s%s ",L_MARKER,day,day_suffix (day),R_MARKER);
 #else
         fprintf(stdout,"%s%2d%s%s",L_MARKER,day,day_suffix (day),R_MARKER);
 #endif /* ANSISYS */
       else
         fprintf(stdout," %2d%s ",day,day_suffix (day));
       if (year == act_year)
         fprintf(stdout,"%-4d  >>  %+4d day%s\n",year,i,
                        (abs(i) == 1)
                        ? ""
                        : "s");
       else
         fprintf(stdout,"%-4d\n",year);
#endif /* GERMAN */
     }
    else
      if (*holiday_mode != '*')
        holiday_vector [month-1] [hcount [month-1]++] =
          (julian_flag)
          ? hd
          : day;
  }


 void
   print_all_holidays (      Bool init_data,
                       const Bool detect)
 /*
    like the function name says
 */
  {
    register Sint  easter=gauss_easter_formula (year),
                   i,j;
#ifdef GERMAN
    register Sint  day;


    if (!detect)
      fprintf(stdout,"\nDas Jahr %04d ist %sEIN Schaltjahr\n\n",
              year,(is_leap_year)
                   ? ""
                   : "K");
    if (init_data)
      for (i=0 ; i < MONTH_MAX ; i++)
        for (j=0 ; j < MONTH_MAX ; j++)
          holiday_vector [i] [j] = 0;
    print_single_holiday (init_data,detect,"Neujahr","",1,1,year);
    if (init_data)
      init_data = FALSE;
    print_single_holiday (init_data,detect,"Rosenmontag","*",easter-48,0,year);
    print_single_holiday (init_data,detect,"Aschermittwoch","*",easter-46,0,year);
    print_single_holiday (init_data,detect,"Palmsonntag","*",easter-7,0,year);
    print_single_holiday (init_data,detect,"Karfreitag","",easter-2,0,year);
    print_single_holiday (init_data,detect,"Ostersonntag","",easter,0,year);
    print_single_holiday (init_data,detect,"Ostermontag","",easter+1,0,year);
    print_single_holiday (init_data,detect,"Tag der Arbeit","",1,5,year);
    day = 1;
    LOOP
     {
       if (weekday_of_date (day,5,year) == 7)
         break;
       else
         day++;
     }
    day += 7;
    if (day_of_year (day,5,year) == easter+49)
      day -= 7;
    print_single_holiday (init_data,detect,"Muttertag","*",day,5,year);
    print_single_holiday (init_data,detect,"Christi Himmelfahrt","#",easter+39,0,year);
    print_single_holiday (init_data,detect,"Pfingstsonntag","",easter+49,0,year);
    print_single_holiday (init_data,detect,"Pfingstmontag","",easter+50,0,year);
    print_single_holiday (init_data,detect,"Fronleichnam","#",easter+60,0,year);
    print_single_holiday (init_data,detect,"Mari"AE" Himmelfahrt","*",15,8,year);
    print_single_holiday (init_data,detect,"Allerheiligen","#",1,11,year);
    day = weekday_of_date (1,11,year);
    day = (day < 3)
          ? 18 - day
          : 25 - day;
    print_single_holiday (init_data,detect,"Bu"SZ"- und Bettag","",day,11,year);
    print_single_holiday (init_data,detect,"Heiligabend","#",24,12,year);
    print_single_holiday (init_data,detect,"1. Weihnachtstag","",25,12,year);
    print_single_holiday (init_data,detect,"2. Weihnachtstag","",26,12,year);
    print_single_holiday (init_data,detect,"Silvester","*",31,12,year);
#else
    if (!detect)
      fprintf(stdout,"\nThe year %04d is %s leap year\n\n",
              year,(is_leap_year)
                   ? "A"
                   : "NO");
    if (init_data)
      for (i=0 ; i < MONTH_MAX ; i++)
        for (j=0 ; j < MONTH_MAX ; j++)
          holiday_vector [i] [j] = 0;
    print_single_holiday (init_data,detect,"New years day","",1,1,year);
    if (init_data)
      init_data = FALSE;
    print_single_holiday (init_data,detect,"Palm sunday","*",easter-7,0,year);
    print_single_holiday (init_data,detect,"Good friday","",easter-2,0,year);
    print_single_holiday (init_data,detect,"Easter sunday","",easter,0,year);
    print_single_holiday (init_data,detect,"Easter monday","",easter+1,0,year);
    print_single_holiday (init_data,detect,"Whitsunday","",easter+49,0,year);
    print_single_holiday (init_data,detect,"Whit monday","",easter+50,0,year);
    print_single_holiday (init_data,detect,"Feast of Corpus Christi","#",easter+60,0,year);
    print_single_holiday (init_data,detect,"All Saints' Say","",1,11,year);
    print_single_holiday (init_data,detect,"Christmas Eve","#",24,12,year);
    print_single_holiday (init_data,detect,"1. Christmas Day","",25,12,year);
    print_single_holiday (init_data,detect,"2. Christmas Day","",26,12,year);
    print_single_holiday (init_data,detect,"Sylvester","*",31,12,year);
#endif /* GERMAN */
  }


 Sint
   compare_monthname (const Schar *s)
 /*
    compares delivered month name `s' with the built-in monthnames
    returns: 1..12 == monthname 1..12 found ; 0 otherwise
 */
  {
    register       Sint    len=strlen(s),
                           i,j;
    auto     const Schar  *ptr_char;


    if (len)
      for (i=MONTH_MIN ; i <= MONTH_MAX ; i++)
       {
         ptr_char = month_name (i);
         j = 0;
         while (   *(ptr_char + j)
                && s [j])
           if (toupper(*(ptr_char + j)) == toupper(s [j]))
             j++;
           else
             break;
         if (   j == len
             || !*(ptr_char + j))
           return(i);
       }

    return(0);
  }


 Sint
   compare_dayname (const Schar *s)
 /*
    compares delivered day name `s' with the built-in daynames
    returns: 1..7 == dayname 1..7 found ; 0 otherwise
 */
  {
    register       Sint    len=strlen(s),
                           i,j;
    auto     const Schar  *ptr_char;


    if (len)
      for (i=DAY_MIN ; i <= DAY_MAX ; i++)
       {
         ptr_char = day_name (i);
         j = 0;
         while (   *(ptr_char + j)
                && s [j])
           if (toupper(*(ptr_char + j)) == toupper(s [j]))
             j++;
           else
             break;
         if (   j == len
             || !*(ptr_char + j))
           return(i);
       }

    return(0);
  }


 void
   build_month_list (const Schar *argv[])
 /*
    like the function name says
 */
  {
    register       Sint    i,j;
    auto     const Schar  *option;
    auto           Bool    list=FALSE,
                           range=FALSE,
                           year_sep_found;


    option = *argv;
    for ( ; *option && !list && !range; option++)
      if (   *option == *MLIST_SEP
          || *option == *YLIST_SEP)
       {
         list = TRUE;
         if (*option == *YLIST_SEP)
           ext_list=ext_year = TRUE;
       }
      else
        if (   *option == *MRANGE_SEP
            || *option == *YRANGE_SEP)
         {
           range = TRUE;
           if (*option == *YRANGE_SEP)
             ext_range=ext_year = TRUE;
         }
    if (   list
        || range)
     {
       i = 0;
       option = *argv;
       while (   *option
              && (i < MONTH_MAX))
        {
          year_sep_found = FALSE;
          j = 0;
          while (   *option
                 && !year_sep_found
                 && (   (   list
                         && (   (*option != *MLIST_SEP)
                             && (*option != *YLIST_SEP)))
                     || (   range
                         && (   (*option != *MRANGE_SEP)
                             && (*option != *YRANGE_SEP)))))
            year_sep_found = (Bool)((s [j++]=*option++) == *YEAR_SEP);
          if (year_sep_found)
            s [j-1] = '\0';
          else
            s [j] = '\0';
          j = my_atoi (s);
          if (ext_year)
           {
             if (j)
               month_list.month [i++] = j;
             else
               if (list)
                 month_list.month [i++] = act_year;
             if (year_sep_found)
              {
                year_sep_found = FALSE;
                while (*option == *YEAR_SEP)
                  option++;
                while (   *option
                       && (   (   list
                               && (*option != *YLIST_SEP))
                           || (   range
                               && (*option != *YRANGE_SEP))))
                  option++;
              }
           }
          else
           {
             if (   (j >= MONTH_MIN)
                 && (j <= MONTH_MAX))
               month_list.month [i++] = j;
             else
               if (j=compare_monthname (s))
                 month_list.month [i++] = j;
           }
          if (year_sep_found)
           {
             if (j)
              {
                j = 0;
                while (*option == *YEAR_SEP)
                  option++;
                while (   *option
                       && (   (   list
                               && (*option != *MLIST_SEP))
                           || (   range
                               && (*option != *MRANGE_SEP))))
                  s [j++] = *option++;
                s [j] = '\0';
                j = my_atoi (s);
                if (   (j >= YEAR_MIN)
                    && (j <= YEAR_MAX)
                    && (j != act_year))
                 {
                   month_list.year [i-1] = j;
                   if (   list
                       && !ext_range)
                     ext_list = TRUE;
                   else
                     if (   range
                         && !ext_list)
                       ext_range = TRUE;
                 }
              }
             else
               while (   *option
                      && (   (   list
                              && (*option != *MLIST_SEP))
                          || (   range
                              && (*option != *MRANGE_SEP))))
                 option++;
           }
          while (   *option == *MLIST_SEP
                 || *option == *MRANGE_SEP
                 || *option == *YLIST_SEP
                 || *option == *YRANGE_SEP)
            option++;
        }
       if (   range
           && !ext_range)
        {
          register Sint  k;


          j = *month_list.month;
          k = month_list.month [1];
          i = 0;
          while (month_list.month [i])
            month_list.month [i++] = 0;
          if (   !j
              && !k)
            *month_list.month = act_month;
          else
           {
             if (!j)
               j = MONTH_MIN;
             if (!k)
               k = MONTH_MAX;
             i = 0;
             if (j > k)
               for ( ; j >= k ; i++,j--)
                 month_list.month [i] = j;
             else
               for ( ; j <= k ; i++,j++)
                 month_list.month [i] = j;
           }
        }
       if (   ext_range
           && ext_year
           && !month_list.month [1])
        {
          *month_list.month = 0;
          ext_range=ext_year = FALSE;
        }
     }
  }


#ifdef USE_RC
 Sint
   rc_sort (const Schar **a,
            const Schar **b)
 /*
    the (q)sort compare function
 */
  {
    return(strcmp(*a,*b));
  }


 Schar
   *rc_get_date (Schar *ptr_char,
                 Schar *s,
                 Sint  *d,
                 Sint  *m,
                 Sint  *y)
 /*
    converts a string `date' to a numerical `date'
 */
  {
    register Sint   i;
    static   Schar  str[5];


    for (i=0 ; i < 4 ; i++)
      str [i] = *ptr_char++;
    str [i] = '\0';
    *y = my_atoi (str);
    for (i=0 ; i < 2 ; i++)
      str [i] = *ptr_char++;
    str [i] = '\0';
    *m = my_atoi (str);
    for (i=0 ; i < 2 ; i++)
      str [i] = *ptr_char++;
    str [i] = '\0';
    *d = my_atoi (str);
    strcpy(s,str);

    return(ptr_char);
  }


 Bool
   rc_read_line (FILE  *fp,
                 Schar *tmp_buffer,
                 Sint  *line)
 /*
    reads a textline of the delivered (resource-)file
 */
  {
    register Sint    i=0,
                     j=1,
                     ch;
    auto     Schar  *ptr_char;
    auto     Bool    is_error=FALSE,
                     is_remark=FALSE;


    (*line)++;
    ptr_char = tmp_buffer;
    if ((ch=fgetc(fp)) != EOF)
     {
       while (   (ch != REMARK_CHAR)
              && (ch != EOF)
              && !isalnum(ch))
         ch=fgetc(fp);
       if (ch == EOF)
         return(FALSE);
       else
         if (ch == REMARK_CHAR)
           is_remark = TRUE;
         else
           *ptr_char++ = (Schar)ch;
       while (   (ch=fgetc(fp)) != EOF
              && (ch != '\n'))
         if (!is_remark)
          {
            i++;
            if (   (i < 6)
                && !isdigit(ch))
              is_error = TRUE;
            if (j++ < BUFSIZ)
              *ptr_char++ = (Schar)ch;
          }
       *ptr_char = '\0';
     }
    else
      return(FALSE);
    if (is_error)
     {
#ifdef GERMAN
       fprintf(stderr,"\nUnzul"AE"ssiger Datumseintrag in `%s'\nZeile %d: %s\n",
               PRGR_RC_NAME,*line,tmp_buffer);
#else
       fprintf(stderr,"\nInvalid date entry in `%s'\nLine %d: %s\n",
               PRGR_RC_NAME,*line,tmp_buffer);
#endif /* GERMAN */
#ifdef ISO_ASCII
       S_NEWLINE(stderr);
#endif /* ISO_ASCII */
       exit(251);
     }

    return(TRUE);
  }


 void
   rc_check (      Schar *tmp_buffer,
                   Schar *s,
                   Sint  *line,
                   Sint  *rc_elems,
                   Sint   day,
                   Sint   ed,
             const Sint   wd)
 /*
    checks whether a single line of resource file must be printed
 */
  {
    register Sint    i,
                     save_year=0,
                     print_two_times;
    auto     Sint    d,m,y,
                     dd,mm,yy;
    auto     Schar  *ptr_char;
    auto     Bool    print_line,
                     is_weekday_mode,
                     is_valid_date;


    ptr_char = rc_get_date (tmp_buffer,s,&d,&m,&y);
    if (m > MONTH_MAX)
     {
#ifdef GERMAN
       fprintf(stderr,"\nUng"UE"ltiger Monat in `%s'\nZeile %d: %s\n",
               PRGR_RC_NAME,*line,tmp_buffer);
#else
       fprintf(stderr,"\nInvalid month in `%s'\nLine %d: %s\n",
               PRGR_RC_NAME,*line,tmp_buffer);
#endif /* GERMAN */
#ifdef ISO_ASCII
       S_NEWLINE(stderr);
#endif /* ISO_ASCII */
       exit(250);
     }
    is_weekday_mode = FALSE;
    if (d=compare_dayname (s))
      is_weekday_mode = TRUE;
    else
      d = my_atoi (s);
    if (   !month
        || year != act_year
        || (   (month != act_month)
            && (year == act_year)))
     {
       if (   m
           && d)
         is_valid_date = valid_date (d,m,(y) ? y : year);
       else
         is_valid_date = TRUE;
     }
    else
      is_valid_date = valid_date (d,(m) ? m : month,(y) ? y : year);
    if (!is_valid_date)
     {
#ifdef GERMAN
       fprintf(stderr,"\nUng"UE"ltiger Tag in `%s'\nZeile %d: %s\n",
               PRGR_RC_NAME,*line,tmp_buffer);
#else
       fprintf(stderr,"\nInvalid day in `%s'\nLine %d: %s\n",
               PRGR_RC_NAME,*line,tmp_buffer);
#endif /* GERMAN */
#ifdef ISO_ASCII
       S_NEWLINE(stderr);
#endif /* ISO_ASCII */
       exit(249);
     }
    /*
       check if current line must be printed
    */
    print_line = FALSE;
    print_two_times = 1;
    if (   !month
        || year != act_year
        || (   (month != act_month)
            && (year == act_year)))
     {
       if (   !is_weekday_mode
           && (   !y
               || y == year)
           && m
           && d)
        {
          if (month)
           {
             if (m == month)
               print_line = TRUE;
           }
          else
            print_line = TRUE;
        }
     }
    else
     {
       if (   (   rc_week_flag
               || rc_month_flag
               || rc_year_flag)
           && (   !y
               || y == year
               || (   rc_week_flag
                   && rc_backwards_flag
                   && (y == year-1))
               || (   rc_week_flag
                   && !rc_backwards_flag
                   && (y == year+1))))
        {
          register Sint  td;


          if (   m
              && d)
           {
             if (day < 1)
               if (   !y
                   && (m != month)
                   && rc_week_flag
                   && rc_backwards_flag)
                 y = year - 1;
             if (ed > 365+is_leap_year)
               if (   !y
                   && (m != month)
                   && rc_week_flag
                   && !rc_backwards_flag)
                 y = year + 1;
             if (!y)
               y = year;
           }
          if (   (   rc_week_flag
                  && is_weekday_mode)
              || (   !is_weekday_mode
                  && (   y
                      || m
                      || d)))
           {
             /*
                respect short day name entry yyyymm## ...   (##==short dayname)
             */
             if (   rc_week_flag
                 && is_weekday_mode)
              {
                static   struct {
                                 Schar day[DAY_MAX];
                                 Schar dst[DAY_MAX];
                                } wday_list;
                register Sint   j=0;
                static   Bool   fill_wday_list=FALSE;


                if (!fill_wday_list)
                 {
                   if (rc_backwards_flag)
                    {
                      if (wd != start_day)
                       {
                         i = wd-1;
                         LOOP
                          {
                            if (i < DAY_MIN)
                              i = DAY_MAX;
                            wday_list.day [i-1] = (Schar)i;
                            wday_list.dst [i-1] = (Schar)++j;
                            if (i == start_day)
                              break;
                            i--;
                          }
                       }
                    }
                   else
                    {
                      i = wd;
                      LOOP
                       {
                         wday_list.day [i-1] = (Schar)i;
                         wday_list.dst [i-1] = (Schar)j++;
                         i++;
                         if (i > DAY_MAX)
                           i = DAY_MIN;
                         if (i == start_day)
                           break;
                       }
                    }
                   fill_wday_list = TRUE;
                 }
                if (wday_list.day [d-1])
                 {
                   dd = act_day;
                   mm = month;
                   yy = year;
                   if (rc_backwards_flag)
                     for (i=0 ; i < wday_list.dst [d-1] ; i++)
                       prev_date (&dd,&mm,&yy);
                   else
                     for (i=0 ; i < wday_list.dst [d-1] ; i++)
                       next_date (&dd,&mm,&yy);
                   if (   (   !m
                           || m == mm)
                       && (   !y
                           || y == yy))
                     d = dd,m = mm,y = yy;
                   else
                     y = -1;
                 }
                else
                  y = -1;
              }
             if (   rc_week_flag
                 && (   day < 1
                     || ed > 365+is_leap_year))
              {
                if (   rc_backwards_flag
                    && (y < year))
                 {
                   i = (days_of_february (y) == 29);
                   ed = 365 + i;
                   day = ed + day;
                   td = day_of_year (d,m,y) + i;
                   if (   (td <= ed)
                       && (td >= day))
                    {
                      save_year = year;
                      year = y;
                      print_line = TRUE;
                    }
                 }
                else
                  if (   !rc_backwards_flag
                      && (y > year))
                   {
                     td = day_of_year (d,m,y) + 365 + is_leap_year;
                     if (   (td < ed)
                         && (td >= day))
                      {
                        save_year = year;
                        year = y;
                        print_line = TRUE;
                      }
                   }
                  else
                   {
                     if (   d
                         && m)
                      {
                        td = day_of_year (d,m,y);
                        if (   (td >= day)
                            && (td < ed))
                          print_line = TRUE;
                      }
                   }
              }
             else
               if (   !y
                   || y == year)
                {
                  if (   (   rc_year_flag
                          || (   rc_week_flag
                              && rc_backwards_flag))
                      && (   !m
                          || !d))
                    ;
                  else
                   {
                     if (!m)
                       m = month;
                     if (!y)
                       y = year;
                     td = day_of_year (d,m,y);
                     if (   (td >= day)
                         && (td < ed))
                       print_line = TRUE;
                   }
                }
           }
        }
       else
        {
          dd = act_day;
          mm = month;
          yy = year;
          if (is_weekday_mode)
           {
             auto Bool  is_next_date=FALSE;


             if (rc_tomorrow_flag)
               next_date (&dd,&mm,&yy);
             if (   (   !y
                     || y == year)
                 && (   !m
                     || m == month)
                 && (   d == weekday_of_date (act_day,month,year)
                     || (is_next_date=(Bool)(d == weekday_of_date (dd,mm,yy)))))
              {
                if (is_next_date)
                  m = mm,d = dd;
                else
                  m = month,d = act_day;
                print_line = TRUE;
              }
           }
          else
           {
             if (rc_tomorrow_flag)
               next_date (&dd,&mm,&yy);
             if (   (   !y
                     || y == year)
                 && (   !m
                     || m == month)
                 && (   !d
                     || d == act_day
                     || (   (d == dd)
                         && (mm == month))))
              {
                if (   rc_tomorrow_flag
                    && !d
                    && (   !m
                        || mm == month))
                  print_two_times = 2;
                if (!m)
                  m = month;
                if (!d)
                  d = act_day;
                print_line = TRUE;
              }
           }
        }
     }
    /*
       put current line into rc_buffer vector
    */
    if (   print_line
        && (*rc_elems < RC_ELEMS_MAX-print_two_times+1))
     {
       register Sint  j=0,
                      k=0;
       auto     Bool  is_b=FALSE;


       while (isspace(*ptr_char))
         ptr_char++;
       while (   *(ptr_char + j)
              && (*(ptr_char + j) != FORMAT_CHAR))
        {
          s [j] = *(ptr_char + j);
          k = ++j;
        }
       if (*(ptr_char + j++))
        {
          if (   (is_b=(Bool)(toupper(*(ptr_char + j)) == 'B'))
              || toupper(*(ptr_char + j)) == 'Y')
           {
             auto   Slint  diff=0L;
             static Schar  str[8];
             auto   Schar  ok=TRUE;


             j++;
             i = 0;
             while (   *(ptr_char + j) == '-'
                    || isdigit(*(ptr_char + j)))
              {
                if (i < 4)
                  str [i++] = *(ptr_char + j);
                j++;
              }
             str [i] = '\0';
             i = my_atoi (str);
             if (i)
              {
                if (is_b)
                  diff = (Slint)(year - i);
                else
                  diff = (Slint)(i - year);
                if (   is_b
                    && (diff < 1L))
                  ok = FALSE;
                if (ok)
                 {
                   sprintf(str,"%ld",diff);
                   i = 0;
                   while (str [i])
                     s [k++] = str [i++];
#ifndef GERMAN
                   if (is_b)
                    {
                      sprintf(str,"%s",day_suffix ((Sint)diff));
                      i = 0;
                      while (str [i])
                        s [k++] = str [i++];
                    }

#endif /* !GERMAN */
                 }
                else
                  if (   (*(ptr_char + j) == ' ')
                      && (s [k-1] = ' '))
                    k--;
              }
             else
               if (   (*(ptr_char + j) == ' ')
                   && (s [k-1] == ' '))
                 k--;
             while (*(ptr_char + j))
               s [k++] = *(ptr_char + j++);
             s [k] = '\0';
             strcpy(tmp_buffer,s);
             ptr_char = tmp_buffer;
           }
        }
       i = year;
       do
        {
          sprintf(s,"%04d%02d%02d%s",year,m,d,ptr_char);
          rc_buffer [*rc_elems] = (Schar *)(malloc(strlen(s)+1));
          if (rc_buffer [*rc_elems] == NULL)
           {
#ifdef GERMAN
             fputs("\nmalloc() hat versagt\n",stderr);
#else
             fputs("\nmalloc() fails\n",stderr);
#endif /* GERMAN */
#ifdef ISO_ASCII
             S_NEWLINE(stderr);
#endif /* ISO_ASCII */
             exit(252);
           }
          else
            strcpy(rc_buffer [(*rc_elems)++],s);
          next_date (&d,&m,&year);
        } while (--print_two_times);
       year = i;
     }
    if (save_year)
      year = save_year;
  }


 void
   rc_use (void)
 /*
    processes the resource file
 */
  {
    auto   FILE  *fp;
    auto   Schar *tmp_buffer=(Schar *)malloc(BUFSIZ+1),
                 *ptr_char;
    static Schar *ptr_env;


    if (tmp_buffer == NULL)
     {
#ifdef GERMAN
       fputs("\nmalloc() hat versagt\n",stderr);
#else
       fputs("\nmalloc() fails\n",stderr);
#endif /* GERMAN */
#ifdef ISO_ASCII
       S_NEWLINE(stderr);
#endif /* ISO_ASCII */
       exit(252);
     }
    fp = fopen(PRGR_RC_NAME,"r");
    if (fp == NULL)
     {
#ifdef ATARI
       *tmp_buffer = '\0';
       *ptr_env = '\0';
#else
       if ((ptr_env=(Schar *)getenv(HOME_PATH)) != NULL)
#endif /* ATARI */
        {
#ifdef MSDOS
          register Sint  i;
          auto     Bool  ok=FALSE;


          strcpy(tmp_buffer,ptr_env);
          while (   !ok
                 && (fp == NULL))
           {
             ok = (Bool)((ptr_char=strstr(tmp_buffer,PATH_SEP)) == NULL);
             i = strlen(tmp_buffer) - strlen(ptr_char);
             strcpy(s,tmp_buffer);
             s [i] = '\0';
             ptr_char = strrchr(s,*DIR_SEP);
             if (strlen(ptr_char) > 1)
               strcat(s,DIR_SEP);
             strcat(s,PRGR_RC_NAME);
             strcpy(tmp_buffer,tmp_buffer + i + 1);
             if (!*tmp_buffer)
               ok = TRUE;
             fp = fopen(s,"r");
           }
#else
          strcpy(tmp_buffer,ptr_env);
          strcat(tmp_buffer,DIR_SEP);
          strcat(tmp_buffer,PRGR_RC_NAME);
          fp = fopen(tmp_buffer,"r");
#endif /* MSDOS */
        }
     }
    if (fp != NULL)
     {
       register Sint   wd=weekday_of_date (act_day,act_month,act_year),
                       ed;
       auto     Sint   line=0,
                       rc_elems=0;


       ed=day = day_of_year (act_day,act_month,act_year);
       if (   rc_week_flag
           || rc_month_flag
           || rc_year_flag)
        {
          if (rc_week_flag)
           {
             if (rc_backwards_flag)
               ed -= DAY_MAX;
             ed += SDAY(DAY_MAX-wd+1,start_day);
           }
          else
            if (rc_month_flag)
             {
               if (rc_backwards_flag)
                 ed = day_of_year (1,act_month,act_year);
               else
                {
                  if (act_month < MONTH_MAX)
                    ed = day_of_year (1,act_month+1,act_year);
                  else
                    ed = 365 + is_leap_year + 1;
                }
             }
            else
             {
               if (rc_backwards_flag)
                 ed = 1;
               else
                 ed = 365 + is_leap_year + 1;
             }
          /*
             swap
          */
          if (rc_backwards_flag)
            day ^= ed ^= day ^= ed;
        }
       /*
          now read and check contents of resource file
       */
       while (   (rc_elems < RC_ELEMS_MAX)
              && rc_read_line (fp,tmp_buffer,&line))
         if (*tmp_buffer)
           rc_check (tmp_buffer,s,&line,&rc_elems,day,ed,wd);
       /*
          now print the valid resource file items in sorted order
       */
       if (rc_elems)
        {
          if (rc_elems > 1)
            qsort((void **)rc_buffer,rc_elems,sizeof *rc_buffer,(Func_cmp)rc_sort);
          S_NEWLINE(stdout);
          for (line=0 ; line < rc_elems ; line++)
           {
             ptr_char = rc_get_date (rc_buffer [line],s,&day,&month,&year);
             wd = 0;
             fprintf(stdout,"%s,",short_day_name (weekday_of_date (day,month,year)));
#ifdef GERMAN
             if (   highlight_flag
                 && (year == act_year)
                 && (month == act_month)
                 && (day == act_day))
 #ifdef ANSISYS
               fprintf(stdout,"%s%2d%s ",L_MARKER,day,R_MARKER);
 #else
               fprintf(stdout,"%s%2d%s",L_MARKER,day,R_MARKER);
 #endif /* ANSISYS */
             else
              {
                if (   highlight_flag
                    && *holiday_vector [month-1])
                 {
                   for (ed=0 ; holiday_vector [month-1] [ed] ; ed++)
                     if (holiday_vector [month-1] [ed] == day)
                      {
                        wd = day;
                        break;
                      }
                 }
                if (wd)
 #ifdef ANSISYS
                  fprintf(stdout,"%s%2d%s ",L_HMARKER,day,R_HMARKER);
 #else
                  fprintf(stdout,"%s%2d%s",L_HMARKER,day,R_HMARKER);
 #endif /* ANSISYS */
                else
                  fprintf(stdout," %2d ",day);
              }
             fprintf(stdout,"%s %-4d: %s\n",short_month_name (month),year,ptr_char);
#else
             fprintf(stdout," %s",short_month_name (month));
             if (   highlight_flag
                 && (year == act_year)
                 && (month == act_month)
                 && (day == act_day))
 #ifdef ANSISYS
               fprintf(stdout,"%s%2d%s%s ",L_MARKER,day,day_suffix (day),R_MARKER);
 #else
               fprintf(stdout,"%s%2d%s%s",L_MARKER,day,day_suffix (day),R_MARKER);
 #endif /* ANSISYS */
             else
              {
                if (   highlight_flag
                    && *holiday_vector [month-1])
                 {
                   for (ed=0 ; holiday_vector [month-1] [ed] ; ed++)
                     if (holiday_vector [month-1] [ed] == day)
                      {
                        wd = day;
                        break;
                      }
                 }
                if (wd)
 #ifdef ANSISYS
                  fprintf(stdout,"%s%2d%s%s ",L_HMARKER,day,day_suffix (day),R_HMARKER);
 #else
                  fprintf(stdout,"%s%2d%s%s",L_HMARKER,day,day_suffix (day),R_HMARKER);
 #endif /* ANSISYS */
                else
                  fprintf(stdout," %2d%s ",day,day_suffix (day));
              }
             fprintf(stdout,"%-4d: %s\n",year,ptr_char);
#endif /* GERMAN */
             free(rc_buffer [line]);
           }
        }
       fclose(fp);
     }
    free(tmp_buffer);
  }
#endif /* USE_RC */


#ifndef GERMAN
 const Schar
   *day_suffix (const Sint day)
 /*
    returns the ordinal suffix (st, nd, rd or th) which is
    added to a single day number using the format %-2s
 */
  {
    static   const Schar  *suffix[]=
     {
       "th",
       "st",
       "nd",
       "rd",
     };
    register       Sint   i=0;


    if (   day < 11
        || day > 13)
      i = day % 10;
    if (i > 3)
      i = 0;

    return(suffix [i]);
  }
#endif /* !GERMAN */


 const Schar
   *short_day_name (const Sint day)
 /*
    returns the short name of the day using the format %-2s
 */
  {
#ifdef GERMAN
    static const Schar  *name[]=
     {
       "ung"UE"ltiger Tag",
       "Mo",
       "Di",
       "Mi",
       "Do",
       "Fr",
       "Sa",
       "So"
     };
#else
    static const Schar  *name[]=
     {
       "invalid day",
       "Mo",
       "Tu",
       "We",
       "Th",
       "Fr",
       "Sa",
       "Su"
     };
#endif /* GERMAN */

    return((   day < DAY_MIN
            || day > DAY_MAX)
           ? name[0]
           : name[day]);
  }


 const Schar
   *day_name (const Sint day)
 /*
    returns the whole name of the day
 */
  {
#ifdef GERMAN
    static const Schar  *name[]=
     {
       "ung"UE"ltiger Tag",
       "Montag",
       "Dienstag",
       "Mittwoch",
       "Donnerstag",
       "Freitag",
       "Samstag",
       "Sonntag"
     };
#else
    static const Schar  *name[]=
     {
       "invalid day",
       "Monday",
       "Tuesday",
       "Wednesday",
       "Thursday",
       "Friday",
       "Saturday",
       "Sunday"
     };
#endif /* GERMAN */

    return((   day < DAY_MIN
            || day > DAY_MAX)
           ? name[0]
           : name[day]);
  }


 const Schar
   *short_month_name (const Sint month)
 /*
    returns the whole name of the month using the format %-3s
 */
  {
#ifdef GERMAN
    static const Schar  *name[]=
     {
       "ung"UE"ltiger Monat",
       "Jan",
       "Feb",
#ifdef ISO_ASCII
       "M"AE,
#else
       "M"AE"r",
#endif /* ISO_ASCII */
       "Apr",
       "Mai",
       "Jun",
       "Jul",
       "Aug",
       "Sep",
       "Okt",
       "Nov",
       "Dez"
     };
#else
    static const Schar  *name[]=
     {
       "invalid month",
       "Jan",
       "Feb",
       "Mar",
       "Apr",
       "May",
       "Jun",
       "Jul",
       "Aug",
       "Sep",
       "Oct",
       "Nov",
       "Dec"
     };
#endif /* GERMAN */

    return((   month < MONTH_MIN
            || month > MONTH_MAX)
           ? name[0]
           : name[month]);
  }


 const Schar
   *month_name (const Sint month)
 /*
    returns the whole name of the month
 */
  {
#ifdef GERMAN
    static const Schar  *name[]=
     {
       "ung"UE"ltiger Monat",
       "Januar",
       "Februar",
       "M"AE"rz",
       "April",
       "Mai",
       "Juni",
       "Juli",
       "August",
       "September",
       "Oktober",
       "November",
       "Dezember"
     };
#else
    static const Schar  *name[]=
     {
       "invalid month",
       "January",
       "February",
       "March",
       "April",
       "May",
       "June",
       "July",
       "August",
       "September",
       "October",
       "November",
       "December"
     };
#endif /* GERMAN */

    return((   month < MONTH_MIN
            || month > MONTH_MAX)
           ? name[0]
           : name[month]);
  }


#ifdef USE_RC
 void
   prev_date (Sint *day,
              Sint *month,
              Sint *year)
 /*
    sets a given date to yesterdays date
 */
  {
    (*day)--;
    if (   !*day
        || !valid_date (*day,*month,*year))
     {
       (*month)--;
       if (*month < MONTH_MIN)
         *month = MONTH_MAX,(*year)--;
       *day = 31;
       while (!valid_date (*day,*month,*year))
         (*day)--;
     }
  }


 void
   next_date (Sint *day,
              Sint *month,
              Sint *year)
 /*
    sets a given date to tomorrows date
 */
  {
    (*day)++;
    if (!valid_date (*day,*month,*year))
     {
       *day = 1;
       if (*month == MONTH_MAX)
         *month = 1,(*year)++;
       else
         (*month)++;
     }
  }


 Bool
   valid_date (const Sint day,
               const Sint month,
               const Sint year)
 /*
    checks whether a delivered date is valid
 */
  {
    if (   day < 0
        || day > 31
        || month < MONTH_MIN
        || month > MONTH_MAX
        || (   (day > 30)
            && (   month == 4
                || month == 6
                || month == 9
                || month == 11))
        || (   (day > days_of_february (year))
            && (month == 2)))
      return(FALSE);

    return(TRUE);
  }
#endif /* USE_RC */


 Sint
   weekday_of_date (const Sint day,
                    const Sint month,
                    const Sint year)
 /*
    computes the weekday of a gregorian/julian date
      and returns 1..7 ; 1==mo,2==tu...7==su
 */
  {
    if (year > GREGOR_YEAR)
     {
       register Sint  yearfact=year+(month-14)/12;


       yearfact = ((13 * (month + 10 - (month + 10) / 13 * 12) - 1) / 5
                    + day + 77 + ((5 * (yearfact % 100)) >> 2)
                    + yearfact / 400 - ((yearfact / 100) << 1)) % 7;

       return((yearfact)
              ? abs(yearfact)
              : 7);
     }
    else
     {
       auto           Ulint  julian_days;
       register       Sint   i;
       static   const Schar  dvec[]={31,28,31,30,31,30,31,31,30,31,30,31};


       julian_days = (Ulint)((year - 1) * 365UL + ((year - 1) >> 2));
       if (   (days_of_february (year) == 29)
           && (  (   (month == 2)
                  && (day == 29))
               || month > 2))
         julian_days++;
       for (i=1 ; i < month ; i++)
         julian_days += (Sint)(dvec [i-1]);
       julian_days += day;
       julian_days %= 7;

       return((julian_days > 2)
              ? (Sint)(julian_days - 2)
              : (Sint)(julian_days + 5));
     }
  }


 Sint
   day_of_year (const Sint day,
                const Sint month,
                const Sint year)
 /*
    computes the day of the year of a delivered date
 */
  {
    static const Sint  mvec[]={0,31,59,90,120,151,181,212,243,273,304,334};


    if (month < 3)
      return(mvec[month-1]+day);

    return(mvec[month-1]+day+(days_of_february (year) == 29));
  }


 Sint
   days_of_february (const Sint year)
 /*
    computes the number of days in february and returns them
 */
  {
    return((year > GREGOR_YEAR)
           ? (year & 3)
             ? 28
             : (   year % 100
                || !(year % 400))
               ? 29
               : 28
           : (year & 3)
             ? 28
             : 29);
  }


 Sint
   gauss_easter_formula (const Sint year)
 /*
    computes the day of easter sunday in a gregorian year
      using gauss's easter formular
 */
  {
    register Sint  i,j,
                   a,b,
                   d,m;


    i = year / 100 - year / 400 + 4;
    j = i - year / 300 + 11;
    a = (((year % 19) * 19) + j) % 30;
    b = ((((year & 3) << 1) + (year << 2) + (6 * a) + i) % 7) + a - 9;
    if (b < 1)
     {
       d = 31 + b;
       m = 3;
     }
    else
     {
       if (   (b == 26)
           || (   (a == 28)
               && (b == 25)
               && ((11*(j+1)%30) < 19)))
         b -= 7;
       d = b;
       m = 4;
     }

    return(day_of_year (d,m,year));
  }
