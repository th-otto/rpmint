#ifndef __AES_H__
#define __AES_H__

#include <windom.h>
#include <sqlite3.h>

extern WINDOW *primary_window;

#define SYS_TOS    0x0001
#define SYS_MAGIC  0x0002
#define SYS_MINT   0x0004
#define SYS_GENEVA 0x0010
#define SYS_NAES   0x0020
#define SYS_XAAES  0x0040
#define WORD short
#define UWORD unsigned short
extern UWORD _systype_v;
extern UWORD _systype(void);
#define sys_type()    (_systype_v ? _systype_v : _systype())
#define sys_MAGIC()   ((sys_type() & SYS_MAGIC) != 0)
#define sys_NAES()    ((sys_type() & SYS_NAES)  != 0)
#define sys_XAAES()   ((sys_type() & SYS_XAAES) != 0)

typedef struct system_status_s {
	int progress_one;
	int progress_two;
	int progress_three;
	int server_pkg_total;
	int client_pkg_total;
	int server_pkg_count;
	int client_pkg_count;
} system_status_t;

system_status_t *system_status;

void Destroy(WINDOW *win);
char *get_string(int idx);
OBJECT *get_tree(int idx);
void about_sum(void);
void draw_progress_bars(void);
void destroy_main_window(WINDOW *win, int index, int mode);
void do_main_window(void);

#endif