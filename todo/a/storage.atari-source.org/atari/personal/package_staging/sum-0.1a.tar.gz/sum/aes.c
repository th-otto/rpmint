#include <stdio.h>
#include <sqlite3.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <windom.h>
#include <mint/osbind.h>

#include "sum.rsh"
#include "fileio.h"

WINDOW *primary_window=NULL;

#define SYS_TOS    0x0001
#define SYS_MAGIC  0x0002
#define SYS_MINT   0x0004
#define SYS_GENEVA 0x0010
#define SYS_NAES   0x0020
#define SYS_XAAES  0x0040
#define WORD short
#define UWORD unsigned short
UWORD _systype_v;
UWORD _systype(void);
#define sys_type()    (_systype_v ? _systype_v : _systype())
#define sys_MAGIC()   ((sys_type() & SYS_MAGIC) != 0)
#define sys_NAES()    ((sys_type() & SYS_NAES)  != 0)
#define sys_XAAES()   ((sys_type() & SYS_XAAES) != 0)

/* Special thanks to Ralph Lowinski and the highwire project for
   this aes detection code! */

typedef struct system_status_s {
	int progress_one;
	int progress_two;
	int progress_three;
	int server_pkg_total;
	int client_pkg_total;
	int server_pkg_count;
	int client_pkg_count;
} system_status_t;

system_status_t *system_status=NULL;

UWORD
_systype (void)
{
	long * ptr = (long *)Setexc(0x5A0/4, (void (*)())-1);
	
	_systype_v = SYS_TOS;
	
	if (!ptr) {
		return _systype_v;   /* stone old TOS without any cookie support */
	}
	while (*ptr) {
		if (*ptr == 0x4D674D63L/*MgMc*/ || *ptr == 0x4D616758L/*MagX*/) {
			_systype_v = (_systype_v & ~0xF) | SYS_MAGIC;
		} else if (*ptr == 0x4D694E54L/*MiNT*/) {
			_systype_v = (_systype_v & ~0xF) | SYS_MINT;
		
		} else if (*ptr == 0x476E7661L/*Gnva*/) {
			_systype_v |= SYS_GENEVA;
		} else if (*ptr == 0x6E414553L/*nAES*/) {
			_systype_v |= SYS_NAES;
		}
		ptr += 2;
	}
	if (_systype_v & SYS_MINT) { /* check for XaAES */
		WORD out = 0, u;
		if (wind_get (0, (((WORD)'X') <<8)|'A', &out, &u,&u,&u) && out) {
			_systype_v |= SYS_XAAES;
		}
	}
	return _systype_v;
}

void grect_conv(GRECT *rect, short int *array)
{
	*array++ = rect->g_x;
	*array++ = rect->g_y;
	*array++ = rect->g_x+rect->g_w - 1;
	*array = rect->g_y+rect->g_h - 1;
}

void Destroy(WINDOW *win)
{
	WindClose(win);
	WindDelete(win);
	return;
}

char *get_string(int idx)
{
	char *txt;
	rsrc_gaddr(5, idx, &txt);
	return txt;
}

OBJECT *get_tree(int idx)
{
	OBJECT *tree;
	rsrc_gaddr(0, idx, &tree);
	return tree;
}

void about_sum(void)
{
	WINDOW *win;
	int res;

	win=FormWindBegin(get_tree(ABOUT), get_string(APP_NAME));
	res = FormWindDo(MU_MESAG|MU_BUTTON|MU_KEYBD);
	if (res==ABOUT_OKAY)
	{
		ObjcChange(OC_FORM, win, res, NORMAL, 0);
		FormWindEnd();
	}
}

void destroy_main_window(WINDOW *win, int index, int mode, void *bob)
{
	ObjcChange(OC_FORM, win, MAIN_QUIT, NORMAL, TRUE);
	if (form_alert(1, get_string(QUITSURE))==1)
	{
		Destroy(win);
		while (wglb.first) {
			ApplWrite((int)wglb.first, WM_DESTROY,0,0,0,0,0);
			EvntWindom(MU_MESAG);
		}
		RsrcXtype(0, NULL, 0);
		RsrcFree();
		ApplExit();
		exit(0);
	}
}

void draw_progress_bars(void)
{
	ObjcDraw(OC_FORM, primary_window, MAIN_DOWNLOAD_PERCENT_BAR, 1);
	ObjcDraw(OC_FORM, primary_window, MAIN_PACKAGE_PERCENT_BAR, 1);
	ObjcDraw(OC_FORM, primary_window, MAIN_TOTAL_PERCENT_BAR, 1);
}

void draw_progress_one(WINDOW *win, PARMBLK *pblk, system_status_t *system_status)
{
	short int pxy[8];
	float percent_pix=0;
	int width_temp=0;
	GRECT *myrect=malloc(sizeof(GRECT));
	int our_percent=system_status->progress_one; /* I have no idea how to do this better */

	percent_pix=((float)pblk->pb_w)/(float)100.0;
	myrect->g_h=pblk->pb_h;
	width_temp=(int)(our_percent*percent_pix);
	myrect->g_w=pblk->pb_w;
	myrect->g_x=pblk->pb_x;
	myrect->g_y=pblk->pb_y;
	grect_conv(myrect, pxy);
	vsf_color(win->graf->handle, WHITE);
	vr_recfl(win->graf->handle, pxy);
	myrect->g_w=width_temp;
	grect_conv(myrect, pxy);
	vsf_color(win->graf->handle, RED);
	vr_recfl(win->graf->handle, pxy);
	free(myrect);
}

void draw_progress_two(WINDOW *win, PARMBLK *pblk, system_status_t *system_status)
{
	short int pxy[8];
	float percent_pix=0;
	int width_temp=0;
	GRECT *myrect=malloc(sizeof(GRECT));
	int our_percent=system_status->progress_two; /* I have no idea how to do this better */

	percent_pix=((float)pblk->pb_w)/(float)100.0;
	myrect->g_h=pblk->pb_h;
	width_temp=(int)(our_percent*percent_pix);
	myrect->g_w=pblk->pb_w;
	myrect->g_x=pblk->pb_x;
	myrect->g_y=pblk->pb_y;
	grect_conv(myrect, pxy);
	vsf_color(win->graf->handle, WHITE);
	vr_recfl(win->graf->handle, pxy);
	myrect->g_w=width_temp;
	grect_conv(myrect, pxy);
	vsf_color(win->graf->handle, RED);
	vr_recfl(win->graf->handle, pxy);
	free(myrect);
}

void draw_progress_three(WINDOW *win, PARMBLK *pblk, system_status_t *system_status)
{
	short int pxy[8];
	float percent_pix=0;
	int width_temp=0;
	GRECT *myrect=malloc(sizeof(GRECT));
	int our_percent=system_status->progress_three; /* I have no idea how to do this better */

	percent_pix=((float)pblk->pb_w)/(float)100.0;
	myrect->g_h=pblk->pb_h;
	width_temp=(int)(our_percent*percent_pix);
	myrect->g_w=pblk->pb_w;
	myrect->g_x=pblk->pb_x;
	myrect->g_y=pblk->pb_y;
	grect_conv(myrect, pxy);
	vsf_color(win->graf->handle, WHITE);
	vr_recfl(win->graf->handle, pxy);
	myrect->g_w=width_temp;
	grect_conv(myrect, pxy);
	vsf_color(win->graf->handle, RED);
	vr_recfl(win->graf->handle, pxy);
	free(myrect);
}

void pkgentry_okay(WINDOW *win, int index)
{
	OBJECT *tree;
	char *pkgname;
	
	ObjcChange(OC_FORM, win, PKG_ENTRY_OKAY, NORMAL, TRUE);
	rsrc_gaddr(0, PKG_ENTRY, &tree);
	pkgname=ObjcString(tree, PKG_ENTRY_PKGNAME, NULL);
	Destroy(win);
	download_install_latest_by_name(system_db, pkgname);
}

void pkgentry_cancel(WINDOW *win, int index)
{
	ObjcChange(OC_FORM, win, PKG_ENTRY_CANCEL, NORMAL, TRUE);
	Destroy(win);
}

void install_specific_pkg(WINDOW *win, int index, int mode, void *bob)
{
	OBJECT *tree;
	WINDOW *win;
	
	rsrc_gaddr(0, PKG_ENTRY, &tree);
	win=FormCreate(tree, NAME|MOVER|CLOSER, NULL, "Install a Package", NULL, 1, 0);
	ObjcAttachFormFunc(win, PKG_ENTRY_OKAY, pkgentry_okay, NULL);
	ObjcAttachFormFunc(win, PKG_ENTRY_CANCEL, pkgentry_cancel, NULL);
}

void do_main_window(void)
{
	OBJECT *tree;
	WINDOW *mainwin;
	char *buf=NULL;
	
	system_status->progress_one=0;
	system_status->progress_two=0;
	system_status->progress_three=0;

	rsrc_gaddr(0, MAIN, &tree);
	buf=malloc(sizeof(char)*100);
	sprintf(buf, "Sparemint Update Manager");
	mainwin=FormCreate(tree, NAME|MOVER, NULL, buf, NULL, TRUE, TRUE);
	primary_window=mainwin;
	
	/* Draw the progress bars */
	RsrcUserDraw(OC_FORM, mainwin, MAIN_DOWNLOAD_PERCENT_BAR, draw_progress_one, system_status);
	RsrcUserDraw(OC_FORM, mainwin, MAIN_PACKAGE_PERCENT_BAR, draw_progress_two, system_status);
	RsrcUserDraw(OC_FORM, mainwin, MAIN_TOTAL_PERCENT_BAR, draw_progress_three, system_status);

	ObjcAttachFormFunc(mainwin, MAIN_QUIT, destroy_main_window, NULL);
	ObjcAttachFormFunc(mainwin, MAIN_INSTALL_SPECIFIC_PKG, install_specific_pkg, NULL);
	
	/* Disable buttons for features that don't yet exist */
	ObjcChange(OC_FORM, mainwin, MAIN_CHECK_UPDATES, DISABLED, FALSE);
	ObjcChange(OC_FORM, mainwin, MAIN_INSTALL_UPDATES, DISABLED, FALSE);
}