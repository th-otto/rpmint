#ifndef __FILEIO_H__
#define __FILEIO_H__

#include <sqlite3.h>

#define TMP_DIR "/tmp/rpminst"

#define CLIENT_LIST 1
#define SERVER_LIST 2

#define COMPARE_SERVER_NEWER 1
#define COMPARE_SERVER_OLDER 2

sqlite3 *system_db;

size_t my_write_func(void *ptr, size_t size, size_t nmemb, FILE *stream);
size_t my_read_func(void *ptr, size_t size, size_t nmemb, FILE *stream);
int tos_progress_func(void *stuff, double t, double d, double ultotal, double ulnow);
int gem_progress_func(void *stuff, double t, double d, double ultotal, double ulnow);
sqlite3 *setup_sql(void);
int load_table_data(int type, sqlite3 *db);
void print_table_comparison(int type, sqlite3 *db);
void fetch_server_list(int repository_id);
void init_tmp_dir(void);
void remove_tmp_dir(void);
int download_install_latest_by_name(sqlite3 *db, char *name);
int upgrade_system(sqlite3 *db);
int reverse_upgrade_system(sqlite3 *db);

#endif