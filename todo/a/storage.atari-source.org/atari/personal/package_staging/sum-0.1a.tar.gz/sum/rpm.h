int rpm_download(char *rpm_path);
int rpm_install(char *rpm);
void build_pkg_list(void);