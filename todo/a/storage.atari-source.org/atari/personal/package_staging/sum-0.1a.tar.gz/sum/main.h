#ifndef __MAIN_H__
#define __MAIN_H__

extern char *temp_dir;
extern int is_gem;
extern int pdes[2];

#endif