Sparemint Update Manager				Version 0.1

		An Automatic Updater for your Atari!

-------------------------------------------------------------------

Thanks for downloading the Sparemint Update Manager.  This software
is used to keep your Atari up-to-date.

Currently this software runs in GEM mode but does nothing at all.

Under command line mode, the only functionality that works is help
and info.  Run "sum help" to display the usage help (keeping in
mint that most functionality is not yet implemented).  Run
"sum info" in order to display information about the relationship 
between packages on your system and packages on the server.

Good luck and please make sure to report any bugs to 
mduckworth@atari-source.com!

Copyright (c) 2004 Mark Duckworth
Released under the GNU GPL.  Warranty neither expressed
nor implied!  You use this software at your own risk!
