/*
  Sum Version 0.1 alpha.  SUM is short for Sparemint Update Manager
  This program is a glorified rpm download/installer...  Most of the logic
  is done through slick sqlite3 queries to save coding time.
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windom.h>
#include "sum.rsh"
#include "aes.h"
#include "rpm.h"
#include "fileio.h"

char *temp_dir;
int is_gem=0;
int pdes[2];
int operating_repository=2;

void quit_sum(WINDOW *win, short buff[8])
{
	if (form_alert(1, get_string(QUITSURE))==1)
	{
		while (wglb.first) {
			ApplWrite((int)wglb.first, WM_DESTROY,0,0,0,0,0);
			EvntWindom(MU_MESAG);
		}
		RsrcXtype(0,NULL,0);
		RsrcFree();
		ApplExit();
		exit(0);
	}
}

void menu_binding(void)
{
	//ObjcAttachMenuFunc(primary_window, MAINMEN_QUIT, quit_sum, NULL);
	//ObjcAttachMenuFunc(primary_window, MAINMEN_ABOUT, about_sum, NULL);
}

int gem_main(void)
{
	OBJECT *menu, *abouttree;
	int res=0;
	extern int is_gem;
	sqlite3 *db;
	
	ApplInit();
	is_gem=1;

	db=setup_sql();
	system_db=db;
	
	if (!RsrcLoad("SUM.RSC"))
	{
		if (!RsrcLoad("u:\\usr\\bin\\sum.rsc"))
		{
			form_alert(1, "[1][Resource file wasn't found!][End]");
			ApplExit();
			exit(0);
		}
	}
	
	RsrcXtype(1, NULL, 0);
	menu=get_tree(MAINMEN);
	abouttree=get_tree(ABOUT);
	MenuBar(menu, 1);

	do_main_window();
	menu_binding();

	for (;;)
	{
		res=EvntWindom(MU_MESAG|MU_TIMER);
	}
	return 0;
}

int tos_main(int argc, char *argv[])
{
	sqlite3 *db;
	
	printf("Sparemint Update Manager version 0.1a\n");
	printf("Copyright (c)2005 by Mark Duckworth, All Rights Reserved\n");
	printf("Console mode due to presence of command line arguments\n");
	printf("Give no arguments for GEM Mode\n");
	printf("--------------------------------------------------------\n\n");

	printf("Setting up SQL Tables\n");
	db=setup_sql();

	if (argc==3)
	{
		if (!strcmpi("install", argv[1]))
		{
			printf("Installing %s...\n", argv[2]);
			printf("Building local package list\n");
			build_pkg_list();
			printf("Building server package list\n");
			fetch_server_list(operating_repository);
			printf("Populating local package table\n");
			load_table_data(CLIENT_LIST, db);
			printf("Populating server package table\n");
			load_table_data(SERVER_LIST, db);
			// Nice function name eh?
			download_install_latest_by_name(db, argv[2]); // This will later be configurable
		}
	}
	else if (argc==2)
	{
		if (!strcmpi("help", argv[1]))
		{
			printf("How to use the Sparemint Update Manager\n\n");
			printf("sum info\t\t-> Show basic information\n");
			printf("sum update\t\t-> Update your system\n");
			printf("sum install pkgname\t-> Download and install latest version\n\t\t\t\t of package from the server\n");
		}
		else if (!strcmpi("info", argv[1]))
		{
			printf("Building local package list\n");
			build_pkg_list();
			printf("Downloading server package list\n");
			fetch_server_list(operating_repository);
			printf("Populating local package table\n");
			load_table_data(CLIENT_LIST, db);
			printf("Populating server package table\n");
			load_table_data(SERVER_LIST, db);
			printf("The following packages are newer on the server\n\n");
			print_table_comparison(COMPARE_SERVER_NEWER, db);
			printf("The following packages are older on the server.\n\n");
			print_table_comparison(COMPARE_SERVER_OLDER, db);
			printf("\n\nThanks for using the Sparemint Update Manager!\n");
		}
		else if (!strcmpi("update", argv[1]))
		{
			printf("Building local package list\n");
			build_pkg_list();
			printf("Downloading server package list\n");
			fetch_server_list(operating_repository);
			printf("Populating local package table\n");
			load_table_data(CLIENT_LIST, db);
			printf("Populating server package table\n");
			load_table_data(SERVER_LIST, db);
			printf("Updating...\n");
			upgrade_system(db);
			printf("\n\nThanks for using the Sparemint Update Manager!\n");
		}
		else if (!strcmpi("fakeupdate", argv[1]))
		{
			printf("Updating your system\n");
			printf("Building our current package list\n");
			build_pkg_list();
			printf("Downloading server package list\n");
			fetch_server_list(operating_repository);
			printf("Loading package list array\n");
		}
	}
	else
	{
		printf("Invalid Arguments.\nPlease type \"sum help\" to get assistance\n\n");
		exit(1);
	}
	sqlite3_close(db);
	exit(0);
}

int main(int argc, char *argv[])
{
	init_tmp_dir();

	/*if (sys_type() & (SYS_MAGIC))
		printf("Magic\n");
	if (sys_type() & (SYS_NAES))
		printf("N.aes\n");
	if (sys_type() & (SYS_XAAES))
		printf("Xaaes\n");
	if (sys_type() & (SYS_TOS))
		printf("TOS\n");
	if (sys_type() & (SYS_GENEVA))
		printf("Geneva\n");
	if (sys_type() & (SYS_MINT))
		printf("MiNT\n");*/
		
	if (!(sys_type() & SYS_MINT)) {
		fprintf(stderr, "The Sparemint Update Manager was designed for and works\nexclusively with MiNT.  We apologize\n");
		exit(1);
	}
		
	system_status=malloc(sizeof(struct system_status_s));

	if (argc>1)
		tos_main(argc, argv);
	else
		gem_main();
		
	remove_tmp_dir();
		
  return (0);
}