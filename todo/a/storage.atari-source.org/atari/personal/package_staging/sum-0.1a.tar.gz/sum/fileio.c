#include <stdio.h>
#include <sqlite3.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <mint/mintbind.h>
#include <curl/curl.h>
#include <curl/types.h>
#include <curl/easy.h>

#include "main.h"
#include "rpm.h"
#include "aes.h"

#define TMP_DIR "/tmp/rpminst"

#define TYPE_NEWER_VERSION 1
#define TYPE_NEWER_RELEASE 10
#define TYPE_OLDER_VERSION 20
#define TYPE_OLDER_RELEASE 30
#define TYPE_NOTPRESENT 100

#define CLASS_CLIENT 1
#define CLASS_SERVER 2

#define CLIENT_LIST 1
#define SERVER_LIST 2

#define COMPARE_SERVER_NEWER 1
#define COMPARE_SERVER_OLDER 2

sqlite3 *system_db=NULL;

size_t my_write_func(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
  return fwrite(ptr, size, nmemb, stream);
}

size_t my_read_func(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
  return fread(ptr, size, nmemb, stream);
}

int tos_progress_func(void *stuff, double t, double d, double ultotal, double ulnow)
{
	int progcalc;

	if (t)
	{
		progcalc=d/t*100;
		printf("\r%.0f Bytes Downloaded...\t%d%%", d, progcalc);
	}
	else
	  printf("\r%.0f Bytes Downloaded...", d);
	fflush(stdout);
  return 0;
}

int gem_progress_func(void *stuff, double t, double d, double ultotal, double ulnow)
{
	int progcalc;

	if (t)
	{
		progcalc=d/t*100;
		system_status->progress_one=progcalc;
		draw_progress_bars();
		Syield();
	}
	
  return 0;
}

int http_foreground_fetch(char *url, char *outpath)
{
	CURL *curl;
	CURLcode res;
	FILE *outfile;
	
	curl = curl_easy_init();
	if (curl)
	{
		outfile=fopen (outpath, "w");
    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, outfile);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, my_write_func);
    curl_easy_setopt(curl, CURLOPT_READFUNCTION, my_read_func);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0);
    if (!is_gem)
    	curl_easy_setopt(curl, CURLOPT_PROGRESSFUNCTION, tos_progress_func);
    else
    	curl_easy_setopt(curl, CURLOPT_PROGRESSFUNCTION, gem_progress_func);
    curl_easy_setopt(curl, CURLOPT_PROGRESSDATA, NULL);

    res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);
    fclose(outfile);
    printf("\n");
	}
	
	return 0;
}

char *get_rep_name(int repid)
{
	char *line=NULL;
	size_t len;
	char *urlpath=NULL;
	char *outpath=NULL;
	FILE *outfile;

	urlpath=malloc(sizeof(char)*400);
	sprintf(urlpath, "http://dev.sparemint.org/updater_interaction.php?op=getrepname&repid=%d", repid);
	outpath=malloc(sizeof(char)*(strlen(temp_dir)+60));
	sprintf(outpath, "%s/repinfo.out", temp_dir);

	http_foreground_fetch(urlpath, outpath);

	outfile=fopen(outpath, "r");
	if (!outfile)
	{
		printf("Error loading file %s\n", outpath);
		exit(1);
	}
	else
	{
		getdelim(&line, &len, '\n', outfile);
		if (strlen(line)>=3)
		{
			line[strlen(line)-1]='\0';
			fclose(outfile);
			return strdup(line);
		}
		else
			return NULL;
	}
	return NULL;
}

int noresp_query(sqlite3 *db, char *query)
{
	char *zErrMsg=0;
	int rc=0;
	rc=sqlite3_exec(db, query, NULL, 0, &zErrMsg);
	if (rc!=SQLITE_OK) {
		fprintf(stderr, "SQL Error: %s\n", zErrMsg);
		exit(1);
	}
	return (0);
}

int noresperr_query(sqlite3 *db, char *query)
{
	char *zErrMsg=0;
	sqlite3_exec(db, query, NULL, 0, &zErrMsg);
	return (0);
}

static int std_print_callback(void *NotUsed, int argc, char **argv, char **azColName)
{
	printf("Package: %s-%s-%s.%s.rpm\n - Installed: %s-%s-%s.%s.rpm\n", argv[0], argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7]);
	return 0;
}

sqlite3 *setup_sql(void)
{
	sqlite3 *db;
	int rc;
	
	rc=sqlite3_open("./sum.sql", &db);
	if (rc)
	{
		printf("Can't open database: %s\n", sqlite3_errmsg(db));
		sqlite3_close(db);
		exit(1);
	}

	noresperr_query(db, "PRAGMA syncrhonous = OFF;");

	noresperr_query(db, "DROP TABLE client_list");
	noresperr_query(db, "DROP TABLE server_list");
	
	noresp_query(db, "CREATE TEMPORARY TABLE client_list (name, version, release, arch)");
	noresp_query(db, "CREATE TEMPORARY TABLE server_list (name, version, release, arch)");
	
	return db;
}

/* This function is complex and strange.  The trained eye can figure out
	 what's going on.  I'll try to make this more efficient and simpler
	 later but for now this seemed like the best way to go about this */

int load_table_data(int type, sqlite3 *db)
{
	FILE *fp;
	size_t len=0;
	char *fullpath=NULL;
	char *line=NULL, *tempbuf=NULL;
	char *name, *version, *release, *arch, *my_query;
	int i=0, j=0, testint=0;
	int z[4];
	
	if (type==CLIENT_LIST)
	{
		system_status->client_pkg_count=0;
		system_status->client_pkg_total=0;
		fullpath=malloc(sizeof(char)*(strlen(temp_dir)+strlen("sys_pkglist.out")+1));
		sprintf(fullpath, "%s/sys_pkglist.out", temp_dir);
	}
	else if (type==SERVER_LIST)
	{
		system_status->server_pkg_count=0;
		system_status->server_pkg_total=0;
		fullpath=malloc(sizeof(char)*(strlen(temp_dir)+strlen("server_pkglist.out")+1));
		sprintf(fullpath, "%s/server_pkglist.out", temp_dir);
	}
	else
	{
		fprintf(stderr, "Error: List type unrecognized\n");
		exit(1);
	}
	fp=fopen(fullpath, "r");
	if (!fp)
	{
		fprintf(stderr, "Error loading file %s\n", fullpath);
		exit(1);
	}
	else
	{
		while ((getdelim(&line, &len, '\n', fp))!=-1)
		{		
			for (i=0;i<4;i++)
			{
				if (!i)
					for (j=0;line[j]!='|';j++);
				else
					for (j=z[i-1]+i;line[j]!='|';j++);
				z[i]=j;
			}			
			
			for (i=0;i<4;i++)
			{
				if (i==0)
				{
					tempbuf=malloc(sizeof(char)*(z[i]+1));
					tempbuf[z[i]]='\0';
					strncpy(tempbuf, line, z[i]);
					//printf("startpos: 0, endpos: %d, %s\n", z[i], tempbuf);
				}
				else
				{
					tempbuf=malloc(sizeof(char)*(z[i]-z[i-1]));
					tempbuf[(z[i]-z[i-1])-1]='\0';
					testint=z[i]-z[i-1]-1;
					//printf("%s\n", line);
					//printf("startpos: %d, endpos: %d\n", z[i-1]+1, (z[i]-z[i-1]-1));
					strncpy(tempbuf, (z[i-1]+1)+line, (z[i]-z[i-1]-1));
				}
						
				switch (i)
				{
					case 0:
						name=tempbuf;
						break;
					case 1:
						version=tempbuf;
						break;
					case 2:
						release=tempbuf;
						break;
					case 3:
						arch=tempbuf;
						break;
				} // switch
			} // for
			free(line);
			line=NULL;
			len=0;
			
			my_query=malloc(sizeof(char)*512);
			if (type==CLIENT_LIST)
				sprintf(my_query, "INSERT INTO client_list VALUES ('%s', '%s', '%s', '%s');", name, version, release, arch);
			else if (type==SERVER_LIST)
				sprintf(my_query, "INSERT INTO server_list VALUES ('%s', '%s', '%s', '%s');", name, version, release, arch);
			noresp_query(db, my_query);
			free(name);
			free(version);
			free(release);
			free(arch);
			free(my_query);
		} /* while getline */
		fclose(fp);
		free(fullpath);
	} /* else fp is good */
	return 0;
}

void print_table_comparison(int type, sqlite3 *db)
{
	char *zErrMsg=0;
	
	if (type==COMPARE_SERVER_NEWER) {  // Show packages on the server that are newer
	 	sqlite3_exec(db, "select * from server_list m, client_list n where m.name=n.name and m.arch=n.arch and ((m.version=n.version and m.release>n.release) or (m.version>n.version))", std_print_callback, 0, &zErrMsg);
	}
	else if (type==COMPARE_SERVER_OLDER) { // Show packages on the server that are older
		sqlite3_exec(db, "select * from server_list m, client_list n where m.name=n.name and m.arch=n.arch and ((m.version=n.version and m.release<n.release) or (m.version<n.version))", std_print_callback, 0, &zErrMsg);
	}
}

void fetch_server_list(int repository_id)
{
	char *outpath=NULL;
	char *in_url=NULL;
	
	in_url=strdup("http://dev.sparemint.org/updater_interaction.php?op=pkglist&repid=1");
	outpath=malloc(sizeof(char)*(strlen(temp_dir)+19));
	sprintf(outpath, "%s/server_pkglist.out", temp_dir);
	
	http_foreground_fetch(in_url, outpath);

  return;
}

void init_tmp_dir(void)
{
	int rand_ext;

	rand_ext=rand();
#ifdef __DEBUG__
	printf("Our random number: %d\n", rand_ext);
#endif
	temp_dir=malloc(sizeof(char)*(strlen(TMP_DIR)+8));
	sprintf(temp_dir, "%s%d", TMP_DIR, rand_ext);
#ifdef __DEBUG__
	printf("Making directory: %s\n", temp_dir);
#endif
	mkdir (temp_dir, S_IRWXU);
}

void remove_tmp_dir(void)
{
	/* delete all files inside the dir */
	char *buf=malloc(sizeof(char)*(12+strlen(temp_dir)));
	sprintf(buf, "rm -f %s/*", temp_dir);
#ifdef __DEBUG__
	printf("Removing all files in %s\n", temp_dir);
	printf("Removing %s\n", temp_dir);
#endif
	if (strlen(temp_dir)>3)
		system(buf);
	else
		printf("Temp dir delete safety precaution activated\n");
	free(buf);
	rmdir(temp_dir);
	free(temp_dir);
}

static int dl_callback(void *NotUsed, int argc, char **argv, char **azColName)
{
	char *curlpath, *outpath;

	printf("I am downloading: %s-%s-%s.%s.rpm\n", argv[0], argv[1], argv[2], argv[3]);	

	curlpath=malloc(sizeof(char)*4096);
	sprintf(curlpath, "http://storage.atari-source.com/atari/sparemint_2/repositories/standard/RPMS/m68kmint/%s-%s-%s.%s.rpm", argv[0], argv[1], argv[2], argv[3]);
	outpath=malloc(sizeof(char)*4096);
	sprintf(outpath, "%s/%s-%s-%s.%s.rpm", temp_dir, argv[0], argv[1], argv[2], argv[3]);

	http_foreground_fetch(curlpath, outpath);

	return 0;
}

static int install_callback(void *NotUsed, int argc, char **argv, char **azColName)
{
	char *my_rpm=malloc(sizeof(char)*1024);
	
	printf("I am installing: %s-%s-%s.%s.rpm\n", argv[0], argv[1], argv[2], argv[3]);	
	sprintf(my_rpm, "%s-%s-%s.%s.rpm", argv[0], argv[1], argv[2], argv[3]);
	rpm_install(my_rpm);
	free(my_rpm);
	return 0;
}


static int dl_install_latest_callback(void *NotUsed, int argc, char **argv, char **azColName)
{
	char *curlpath, *outpath, *mychar, *rpm_name;
	
	mychar=malloc(sizeof(char)*100);
	printf("Found package: %s-%s-%s.%s.rpm\n", argv[0], argv[1], argv[2], argv[3]);	
	printf("\nConfirm you want to install/upgrade these packages (y/N): ");
	scanf("%s", mychar);
	if (!strcmpi("Y", mychar)) {
		printf("\nOkay, Downloading: %s-%s-%s.%s.rpm\n", argv[0], argv[1], argv[2], argv[3]);	
		curlpath=malloc(sizeof(char)*4096);
		sprintf(curlpath, "http://storage.atari-source.com/atari/sparemint_2/repositories/standard/RPMS/m68kmint/%s-%s-%s.%s.rpm", argv[0], argv[1], argv[2], argv[3]);
		outpath=malloc(sizeof(char)*4096);
		sprintf(outpath, "%s/%s-%s-%s.%s.rpm", temp_dir, argv[0], argv[1], argv[2], argv[3]);
		http_foreground_fetch(curlpath, outpath);
		printf("\nInstalling: %s-%s-%s.%s.rpm\n", argv[0], argv[1], argv[2], argv[3]);
		rpm_name=malloc(sizeof(char)*1024);
		sprintf(rpm_name, "%s-%s-%s.%s.rpm", argv[0], argv[1], argv[2], argv[3]);
		rpm_install(rpm_name);
	}
	else
		printf("Alright... Exiting!\n");

	return 0;
}

int download_install_latest_by_name(sqlite3 *db, char *name)
{
	char *zErrMsg=0;
	char *my_query=malloc(sizeof(char)*8192);
	
	sprintf(my_query, "select * from (select * from server_list where name='%s' order by version desc) order by release desc limit 0,1", name);
	if (SQLITE_OK!=sqlite3_exec(db, my_query, dl_install_latest_callback, 0, &zErrMsg)) {
		fprintf(stderr, "SQL Error on package search query: %s\n", zErrMsg);
		exit(1);
	}
	return (0);
}

int reverse_upgrade_system(sqlite3 *db)
{
	char *mychar=malloc(sizeof(char)*100);
	char *my_query=malloc(sizeof(char)*8192);
	sprintf(my_query, "select * from server_list m, client_list n where m.name=n.name and m.arch=n.arch and ((m.version=n.version and m.release<n.release) or (m.version<n.version))");
	sqlite3_exec(db, my_query, std_print_callback, 0, NULL);
	printf("\nConfirm you want to install/upgrade these packages (y/N): ");
	scanf("%s", mychar);
	if (!strcmpi("Y", mychar)) {
		sprintf(my_query, "select * from server_list m, client_list n where m.name=n.name and m.arch=n.arch and ((m.version=n.version and m.release<n.release) or (m.version<n.version))");
		sqlite3_exec(db, my_query, dl_callback, 0, NULL);
		sprintf(my_query, "select * from server_list m, client_list n where m.name=n.name and m.arch=n.arch and ((m.version=n.version and m.release<n.release) or (m.version<n.version))");
		sqlite3_exec(db, my_query, install_callback, 0, NULL);
	}
	else
		printf("Alright... Exiting!\n");
	return (0);
}

int upgrade_system(sqlite3 *db)
{
	char *mychar=malloc(sizeof(char)*100);
	char *my_query=malloc(sizeof(char)*8192);
	sprintf(my_query, "select * from server_list m, client_list n where m.name=n.name and m.arch=n.arch and ((m.version=n.version and m.release>n.release) or (m.version>n.version))");
	sqlite3_exec(db, my_query, std_print_callback, 0, NULL);
	printf("\nConfirm you want to install/upgrade these packages (y/N): ");
	scanf("%s", mychar);
	if (!strcmpi("Y", mychar)) {
		sprintf(my_query, "select * from server_list m, client_list n where m.name=n.name and m.arch=n.arch and ((m.version=n.version and m.release>n.release) or (m.version>n.version))");
		sqlite3_exec(db, my_query, dl_callback, 0, NULL);
		sprintf(my_query, "select * from server_list m, client_list n where m.name=n.name and m.arch=n.arch and ((m.version=n.version and m.release>n.release) or (m.version>n.version))");
		sqlite3_exec(db, my_query, install_callback, 0, NULL);
	}
	else
		printf("Alright... Exiting!\n");
	return (0);
}