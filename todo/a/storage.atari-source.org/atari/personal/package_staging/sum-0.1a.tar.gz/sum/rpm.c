#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <unistd.h>
#include <mint/osbind.h>
#include <curl/curl.h>
#include <curl/easy.h>

#include "main.h"
#include "fileio.h"

#define CMD_RPM_INST "rpm --force -Uvh "

int rpm_download(char *rpm_path)
{
	/* rpm download.  Need to determine filename... */
	CURL *curl;
	CURLcode res;
	FILE *outfile;
	
	curl = curl_easy_init();
	if (curl)
	{
		outfile=fopen ("test.curl", "w");
    curl_easy_setopt(curl, CURLOPT_URL, "http://dev.sparemint.org/blahblah.rpm");
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, outfile);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, my_write_func);
    curl_easy_setopt(curl, CURLOPT_READFUNCTION, my_read_func);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0);
    curl_easy_setopt(curl, CURLOPT_PROGRESSFUNCTION, tos_progress_func);
    curl_easy_setopt(curl, CURLOPT_PROGRESSDATA, NULL);

    res = curl_easy_perform(curl);

    curl_easy_cleanup(curl);
  }
  return 0;
}
  
/* Install a predownloaded rpm sitting in /tmp/specialdir/ */
int rpm_install(char *rpm)
{
	char *built_string=NULL;
	
	built_string=malloc(sizeof(char)*(strlen(CMD_RPM_INST)+1024));	
	sprintf(built_string, "%s %s/%s", CMD_RPM_INST, temp_dir, rpm);
	system(built_string);
	free(built_string);
	
	return (0);
}

/* Simple function to build up a string with packages on this system */
void build_pkg_list(void)
{
	char *our_string;

	our_string=malloc(sizeof(char)*(15+strlen(temp_dir)+16+58));
	sprintf(our_string, "/bin/rpm -qa --queryformat '%%{name}|%%{version}|%%{release}|%%{arch}|\n' > %s/sys_pkglist.out", temp_dir);
	system(our_string);
}

int rpm_search_install(char *name)
{

	/* Tasks.. 1. Find rpm name, 2. resolve deps - server side, 3. download rpms, 4. install
	*/

}
