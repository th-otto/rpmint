#ifndef __AES_H__
#define __AES_H__

#define WTXT 0x57545854L /*WTXT*/
#define BLST 0x57545855L /*BLST*/
#define CONV 0x57545856L /*CONV*/

extern WINDOW *mainwin;
extern char *buddylist;

void Destroy(WINDOW *win);
char *get_string(int idx);
OBJECT *get_tree(int idx);
void about_gim(void);
void set_conversation_window_state(void);
void disclaimer(void);
void not_implemented(char *msg);
void join_chat(void);
void create_info_window(struct aim_userinfo_s *userinfo, char *prof);
void newim_okay(WINDOW *win, int index);
void newim_cancel(WINDOW *win, int index);
void new_im_create(void);
WINDOW *create_conversation_window(char *sn);
void redraw_conversation(WINDOW *win);
void do_logon_form(struct faimtest_priv *priv);
char *tab2spc(int tab, char *dest, char *src, int max); 
void delete_buddylist(WINDOW *win);
void draw_buddylist(WINDOW *win);
void add_to_buddylist(WINDOW *win, char *data);
void remove_from_buddylist(WINDOW *win, char *data);
buddylist_t *CreateBuddylist(void);
WINDOW *Create_Buddylist_Window(int attrib);
#endif
