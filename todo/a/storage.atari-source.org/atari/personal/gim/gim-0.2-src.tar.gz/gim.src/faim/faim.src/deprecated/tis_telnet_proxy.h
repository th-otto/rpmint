
#ifndef __TIS_TELNET_PROXY_H
#define __TIS_TELNET_PROXY_H 1

void tis_telnet_proxy_connect( int fd, char *host, int port );

#endif /* !__TIS_TELNET_PROXY_H */

