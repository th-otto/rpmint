#include <stdio.h>
#include <string.h>
#include "aes.h"

char *load_buddylist_from_file(void)
{
  FILE *fp;
  char * line = NULL;
  size_t len = 0;
  ssize_t read;
  char buf[1024];
  char *blt, *c;

  blt=malloc(sizeof(char)*4096);
  fp=fopen("/d/Devel/Projects/gim/acct1.blt", "r");  /* FIX ME BABY */
  while ((read=getline(&line, &len, fp))!=-1)
  {
    blt=strcat(blt, line);
    blt=strcat(blt, "&");
  }  
  return blt;
}

char *load_permitdeny_from_file(void)
{

}