char *load_buddylist_from_file(void);
char *load_permitdeny_from_file(void);