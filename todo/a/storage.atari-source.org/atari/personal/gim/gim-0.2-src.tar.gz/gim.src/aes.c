#define _GNU_SOURCE
#include <scancode.h>
#include <stdio.h>
#include <math.h>
#include <windom.h>
#include "gim.rsh"
#include "gim_faim.h"
#include "main.h"
#include "buddfunc.h"

#define WTXT 0x57545854L /*WTXT*/
#define BLST 0x57545855L /*BLST*/
#define CONV 0x57545856L /*CONV*/
#define PROF 0x57545857L /*PROF*/
#define UNFO 0x57545857L /*UNFO*/

#define DEBUG(s)	FormAlert(1,"[1][Text %d|%s][ok]", __LINE__, s)
#define TESTATTR

#define VT_UNIX 1
#define VT_DOS 2
#define VT_MAC 3

#define WCAR	attr[6]
#define HCAR	attr[7]
#define WCELL attr[8]
#define HCELL	attr[9]

#define BOLD_BEG "�B"
#define BOLD_END "�b"
#define ITAL_BEG "�I"
#define ITAL_END "�i"
#define UNDL_BEG "�U"
#define UNDL_END "�u"
#define NONE_END "�0"

#define BOLD 0x1
#define LIGH 0x2
#define ITAL 0x4
#define UNDL 0x8

char *buddylist=" * AOL Instant Messenger *";
WINDOW *mainwin;

struct viewtext
{
	char *buf;
	int maxline;
	char **line;
	int type;
};

void Destroy(WINDOW *win)
{
	WindClose(win);
	WindDelete(win);
	return;
}

char *get_string(int idx)
{
	char *txt;
	rsrc_gaddr(5, idx, &txt);
	return txt;
}

OBJECT *get_tree(int idx)
{
	OBJECT *tree;
	rsrc_gaddr(0, idx, &tree);
	return tree;
}

void about_gim(void)
{
	WINDOW *win;
	int res;

	win=FormWindBegin(get_tree(ABOUTGIM), get_string(APP_NAME));
	res = FormWindDo(MU_MESAG|MU_BUTTON|MU_KEYBD);
	if (res==ABOUTGIM_OKAYBUTTON)
	{
		ObjcChange(OC_FORM, win, res, NORMAL, 0);
		FormWindEnd();
	}
}

void disclaimer(void)
{
	WINDOW *win;
	int res;
	
	win=FormWindBegin(get_tree(DISCLAIMER), get_string(APP_NAME));
	res=FormWindDo(MU_MESAG|MU_BUTTON|MU_KEYBD);
	if (res==DISCLAIMER_OKAY)
	{
		ObjcChange(OC_FORM, win, res, NORMAL, 0);
		FormWindEnd();
	}
}

void set_conversation_window_state(void)
{
	OBJECT *tree;
	conversation_t *conversation = DataSearch(mainwin, CONV);
	
	while (conversation)
	{	
		tree=ObjcTree(OC_FORM, conversation->win);
		if (get_buddy(conversation->screenname))
		{
			ObjcStrCpy(tree, IM_ADDREMOVE, "Remove from Buddylist");
			printf("ObjcAttach remove sn is: %s\n", conversation->screenname);
			ObjcAttach(OC_FORM, conversation->win, IM_ADDREMOVE, BIND_FUNC, remove_buddy_by_win);
			ObjcChange(OC_FORM, conversation->win, IM_ADDREMOVE, NORMAL, TRUE); /* w00t */
		}
		else
		{
			ObjcStrCpy(tree, IM_ADDREMOVE, "   Add to Buddylist  ");
			printf("ObjcAttach add sn is: %s\n", conversation->screenname);
			ObjcAttach(OC_FORM, conversation->win, IM_ADDREMOVE, BIND_FUNC, add_buddy_by_win);
			ObjcChange(OC_FORM, conversation->win, IM_ADDREMOVE, NORMAL, TRUE); /* w00t */
		}
		conversation=conversation->next;
	}
}

void not_implemented(char *msg)
{
	FormAlert(1, "[1][%s is not yet implemented.  Sorry.][Okay]", msg);
}

void draw_user_input(WINDOW *win, PARMBLK *pblk, char *sn)
{
	/* This function should at very LEAST be fixed to not redraw the whole
	freaking window ;-) */
	conversation_t *conversation;
	char *buf;
	short int x,y,w,h,attr[10];
	short int hcell, wcell;
	int run=0, linelen=0, runs=0, templen=0;
	
	conversation=find_conversation(sn);
	h=pblk->pb_h;
	w=pblk->pb_w;
	x=pblk->pb_x;
	y=pblk->pb_y-1;
	vswr_mode(win->graf.handle, MD_TRANS);
	vqt_attributes(win->graf.handle, attr);
	hcell=HCELL;
	wcell=WCELL;
	w=HCELL-HCAR;
	y+=hcell;
	linelen=pblk->pb_w/wcell;
	buf=malloc(sizeof(char)*linelen);
	runs=ceil((float)conversation->sendbuflen/(float)linelen);
	/*printf("linelen %d, runs: %d\n", linelen, runs); */
	
	if (conversation->sendbuflen)
		while (run<runs)
		{
			/* We'll keep this debug stuff around in case we need it later */
			/*printf("Looping once, run: %d\n", run);*/
			if (linelen>conversation->sendbuflen)
			{
				strncpy(buf, conversation->sendbuf, conversation->sendbuflen);
				buf[conversation->sendbuflen]='\0';				
			}
			else
			{
				if (runs-run==1)
				{
					templen=conversation->sendbuflen-(run*linelen);
					strncpy(buf, (run*linelen)+conversation->sendbuf, templen);
					buf[templen]='\0';
				}
				else
				{
					strncpy(buf, (run*linelen)+conversation->sendbuf, linelen);
					buf[linelen]='\0';
				}		
			}
			v_gtext(win->graf.handle, pblk->pb_x, y, buf);
			y+=hcell;
			run++;
		}
	free(buf);
	/*
	if (conversation->sendbuf)
	{
		strncpy(buf, conversation->sendbuf, conversation->sendbuflen);
		buf[conversation->sendbuflen]='\0';
		v_gtext(win->graf.handle, pblk->pb_x, y, buf);
		free(buf);
	}*/
}

void draw_conversation(WINDOW *win, PARMBLK *pblk, char *sn)
{
	conversation_t *conversation;
	short int x,y,w,h,attr[10];
	short int hcell;
	short int wcell;
	int k=0, i=0, j=0, linelen=0, origlinelen=0, templen=0, drawn=0, lefttodraw=0, numlines=0;
	int fontattr=0;
	int hlines;
	char *textstring;
	char *buf;

	conversation=find_conversation(sn);
	h=pblk->pb_h;
	w=pblk->pb_w;
	x=pblk->pb_x;
	y=pblk->pb_y;
	h+=pblk->pb_y-1;
	vswr_mode(win->graf.handle, MD_TRANS);
	vqt_attributes(win->graf.handle, attr);
	hcell = HCELL;
	w = HCELL - HCAR;
	wcell = WCELL;	
	hlines=pblk->pb_h/hcell;
	y+=hcell*hlines;
	origlinelen=pblk->pb_w/wcell;
	linelen=origlinelen;

	/* Okay visualizing the handling of multiple lines of output AND word wrap
	AND handling screenname or prefixes on the first line is a REAL PAIN!
	So if this code isn't 100% perfect, sue me ;-) */

	for (j=0;j<=hlines;j++)
	{
		textstring=get_latest_chat_num(conversation, j);
		if (textstring)
		{
			if (get_latest_chat_num_type(conversation, j)==0)
			{
				drawn=0;
				lefttodraw=strlen(textstring);
				buf=malloc(sizeof(char)*linelen);
				numlines=get_num_lines(textstring, linelen, strlen(sn)+2);
				y-=hcell*numlines;
				for (i=1;i<=numlines;i++)
				{
					if (i==1)
					{
						fontattr|=BOLD;
						vst_effects(win->graf.handle, fontattr);
						v_gtext(win->graf.handle, x, y, sn);
						v_gtext(win->graf.handle, x+(wcell*strlen(sn)), y, ": ");
						fontattr&=~BOLD;
						vst_effects(win->graf.handle, fontattr);
						templen=linelen;
						templen-=(strlen(sn)+2);
						if (i<numlines)
							for (k=(drawn+templen);textstring[k]!=' '; k--)
								templen--;
						else
							templen=lefttodraw;
						strncpy(buf, drawn+textstring, templen);
						buf[templen]='\0';
						lefttodraw-=templen-1;
						drawn+=templen+1;
						v_gtext(win->graf.handle, x+(wcell*(strlen(sn)+2)), y, buf);
						y+=hcell;
					}
					else
					{
						templen=linelen;
						if (i<numlines)
							for (k=(drawn+templen);textstring[k]!=' ';k--)
								templen--;
						else
							templen=lefttodraw;
						strncpy(buf, drawn+textstring, templen);
						buf[templen]='\0';
						lefttodraw-=templen-1;
						drawn+=templen+1;
						v_gtext(win->graf.handle, x, y, buf);
						y+=hcell;
					}
				}
				y-=hcell*(numlines);
			}
			if (get_latest_chat_num_type(conversation, j)==1)
			{
				/* Prefix myself */
				drawn=0;
				lefttodraw=strlen(textstring);
				buf=malloc(sizeof(char)*linelen);
				numlines=get_num_lines(textstring, linelen, 8);
				y-=hcell*numlines;
				for (i=1;i<=numlines;i++)
				{
					if (i==1)
					{
						fontattr|=BOLD;
						vst_effects(win->graf.handle, fontattr);
						v_gtext(win->graf.handle, x, y, "Myself: ");
						v_gtext(win->graf.handle, x+(wcell*8), y, ": ");
						fontattr&=~BOLD;
						vst_effects(win->graf.handle, fontattr);
						templen=linelen;
						templen-=8;
						if (i<numlines)
							for (k=(drawn+templen);textstring[k]!=' '; k--)
								templen--;
						else
							templen=lefttodraw;
						strncpy(buf, drawn+textstring, templen);
						buf[templen]='\0';
						lefttodraw-=templen-1;
						drawn+=templen+1;
						v_gtext(win->graf.handle, x+(wcell*8), y, buf);
						y+=hcell;
					}
					else
					{
						templen=linelen;
						if (i<numlines)
							for (k=(drawn+templen);textstring[k]!=' ';k--)
								templen--;
						else
							templen=lefttodraw;
						strncpy(buf, drawn+textstring, templen);
						buf[templen]='\0';
						lefttodraw-=templen-1;
						drawn+=templen+1;
						v_gtext(win->graf.handle, x, y, buf);
						y+=hcell;
					}
				}
				y-=hcell*(numlines);
			}
			if (get_latest_chat_num_type(conversation, j)==2)
			{
				/* Draw system, lets just not worry about word wrap here for now */
				/* Assume the system is smart enough to do it itself ;-) */
				drawn=0;
				lefttodraw=strlen(textstring);
				buf=malloc(sizeof(char)*linelen);
				strncpy(buf, textstring, lefttodraw);
				y-=hcell;
				v_gtext(win->graf.handle, x, y, buf);
				y+=hcell;
			}
			free(buf);
		}
	}
	/* 1, myself, 2 just draw (system) */
}

void draw_conversation_old(WINDOW *win, PARMBLK *pblk, char *sn)
{
	conversation_t *conversation;
	short int x,y,w,h,attr[10];
	short int hcell;
	short int wcell;
	int i;
	char *textstring;

	conversation=find_conversation(sn);
	h=pblk->pb_h;
	w=pblk->pb_w;
	x=pblk->pb_x;
	y=pblk->pb_y;
	h+=pblk->pb_y-1;
	vswr_mode(win->graf.handle, MD_TRANS);
	vqt_attributes(win->graf.handle, attr);
	hcell = HCELL;
	w = HCELL - HCAR;
	wcell = WCELL;
	y+=hcell;
	for(i=8;i>=0;i--)
	{
		textstring=get_latest_chat_num(conversation, i);
		if (textstring)
		{
			if (get_latest_chat_num_type(conversation, i)==0)
			{
				v_gtext(win->graf.handle, x, y, sn);
				v_gtext(win->graf.handle, x+(wcell*(strlen(sn))), y, ": ");
				v_gtext(win->graf.handle, x+(wcell*(strlen(sn)+2)), y, textstring);
			}
			else if (get_latest_chat_num_type(conversation, i)==1)
			{
				v_gtext(win->graf.handle, x, y, "Myself: ");
				v_gtext(win->graf.handle, x+(wcell*8), y, textstring);
			}
			else if (get_latest_chat_num_type(conversation, i)==2)
				v_gtext(win->graf.handle, x, y, textstring);
		}
		y+=hcell;
	}
	return;
}

void redraw_conversation(WINDOW *win)
{
	EvntRedraw(win);
	return;
}

void keybd_conversation(WINDOW *win, char *sn)
{
	char *buf;
	/*char key = keybd2ascii(evnt.keybd, evnt.mkstate & (K_LSHIFT|K_RSHIFT));
	char keyout[3];
	int i=0;*/
	conversation_t *conversation;
				
	conversation=find_conversation(sn);
	if (!conversation->sendbuf)
	{
		conversation->sendbuf=malloc(sizeof(char)*4096);  /* FIXME WE need to establish size */
		conversation->sendbuf[4096]='\0';
		conversation->sendbuflen=0;
		memset(conversation->sendbuf, ' ', strlen(conversation->sendbuf));
	}
	switch (evnt.keybd>>8) {
		case SC_RETURN:
			if (conversation->sendbuflen)
      {
        buf=malloc(sizeof(char)*conversation->sendbuflen);
				strncpy(buf, conversation->sendbuf, conversation->sendbuflen);
				buf[conversation->sendbuflen]='\0';
				im_send_message(sn, buf);
				free(buf);
				free(conversation->sendbuf);
				conversation->sendbuf=NULL;
				redraw_conversation(win);
			}
			break;
		case SC_BACK:
			if (conversation->sendbuflen)
			{
				conversation->sendbuflen--;
				redraw_conversation(win);
			}
			break;
		case SC_DEL:
			break;
		default:
			conversation->sendbuf[conversation->sendbuflen++]=evnt.keybd;
			//redraw_conversation(win);
			ObjcDraw(OC_FORM, win, IM_USERDEF2, 0);
	}
}

void destroy_conversation_nowinclose(WINDOW *win)
{
	conversation_t *conversation;
	
	conversation=DataSearch(mainwin, CONV);
	while (conversation->win!=win)
		conversation=conversation->next;
	if (conversation->win==win)
		free_conversation(conversation);
	else
		printf("Windows don't match in delete_conversation_full!\n");
}

void destroy_conversation_winclose(WINDOW *win)
{
	conversation_t *conversation;
	
	conversation=DataSearch(mainwin, CONV);
	while (conversation->win!=win)
		conversation=conversation->next;
	if (conversation->win==win)
	{
		free_conversation(conversation);
		Destroy(win);
	}
	else
		printf("Windows don't match in delete_conversation_full!\n");
}

void conversation_warn(WINDOW *win)
{
	conversation_t *conversation;
	char *str;
		
	if ((conversation=find_conversation_by_win(win)))
	{
		str=get_string(WARN);
		if (form_alert(1, str)==1)
			aim_send_warning(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), conversation->screenname, AIM_WARN_ANON);
		else
			aim_send_warning(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), conversation->screenname, 0);
		ObjcChange(OC_FORM, win, IM_WARN, NORMAL, TRUE); /* w00t */
	}
	else
		return;
}

void conversation_block(WINDOW *win)
{
	conversation_t *conversation;
	char *namelist;
	
	namelist=malloc(sizeof(char)*(strlen(conversation->screenname)+1));
	sprintf(namelist, "%s&", conversation->screenname);
	if ((conversation=find_conversation_by_win(win)))
	{
		aim_bos_changevisibility(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), AIM_VISIBILITYCHANGE_DENYADD, namelist);		
		ObjcChange(OC_FORM, win, IM_BLOCK, NORMAL, TRUE); /* w00t */
		EvntRedraw(win);
		EvntRedraw(mainwin);
	}
	else
		return;
}

void destroy_info_winclose(WINDOW *win, int index, int mode, struct aim_userinfo_s *userinfo)
{
	char *prof;
	
	ObjcChange(OC_FORM, win, USERINFO_CLOSE, NORMAL, TRUE); /* w00t */
	/* free prof, free userinfo, free titlebuf! */
	/* FIXME - how oh how do we get that titlebuf pointer? */
	prof=DataSearch(win, PROF);
	Destroy(win);
	free(prof);
	free(userinfo);
}

void draw_info_old(WINDOW *win, PARMBLK *pblk, struct aim_userinfo_s *userinfo)
{
	char *buf, *prof;
	short int x,y,w,h,attr[10];
	short int hcell, wcell;
	int run=0, linelen=0, runs=0, templen=0;
	int proflen=0;
	
	/* FIXME - uh duh.. wordwrap? not that it's hard, just unimportant MGD */
	/* FIXME - well we have userinfo, why not print it out like gaim! */
	
	prof=DataSearch(win, PROF);
	h=pblk->pb_h;
	w=pblk->pb_w;
	x=pblk->pb_x;
	y=pblk->pb_y-1;
	vswr_mode(win->graf.handle, MD_TRANS);
	vqt_attributes(win->graf.handle, attr);
	hcell=HCELL;
	wcell=WCELL;
	w=HCELL-HCAR;
	y+=hcell;
	proflen=strlen(prof);
	linelen=pblk->pb_w/wcell;
	buf=malloc(sizeof(char)*linelen);
	runs=ceil((float)proflen/(float)linelen);	
	
	if (proflen)
	{
		while (run<runs)
		{
			if (linelen>proflen)
			{
				strncpy(buf, prof, proflen);
				buf[proflen]='\0';				
			}
			else
			{
				if (runs-run==1)
				{
					templen=proflen-(run*linelen);
					strncpy(buf, (run*linelen)+prof, templen);
					buf[templen]='\0';
				}
				else
				{
					strncpy(buf, (run*linelen)+prof, linelen);
					buf[linelen]='\0';
				}		
			}
			v_gtext(win->graf.handle, pblk->pb_x, y, buf);
			y+=hcell;
			run++;
		}
	}
	free(buf);
}

void draw_info(WINDOW *win, PARMBLK *pblk, struct aim_userinfo_s *userinfo)
{
	char *buf, *prof;
	short int x,y,w,h,attr[10];
	short int hcell, wcell;
	int linelen=0, templen=0, lefttodraw=0, drawn=0, i=0;
	
	/* YAY FOR WORD WRAP - FIXED - sort of */
	/* FIXME - well we have userinfo, why not print it out like gaim! */
	
	prof=DataSearch(win, PROF);
	x=pblk->pb_x;
	y=pblk->pb_y-1;
	vswr_mode(win->graf.handle, MD_TRANS);
	vqt_attributes(win->graf.handle, attr);
	hcell=HCELL;
	wcell=WCELL;
	y+=hcell;
	lefttodraw=strlen(prof);
	linelen=pblk->pb_w/wcell;
	buf=malloc(sizeof(char)*linelen);
	
	if (lefttodraw)
	{
		while (lefttodraw>linelen)
		{
			templen=linelen;
			for (i=(drawn+linelen);prof[i]!=' ';i--)
				templen--;
			strncpy(buf, drawn+prof, templen);
			buf[templen]='\0';
			lefttodraw -= templen-1;
			drawn += templen+1;
			v_gtext(win->graf.handle, pblk->pb_x, y, buf);
			y+=hcell;
		}
		strncpy(buf, drawn+prof, lefttodraw);
		buf[lefttodraw]='\0';
		v_gtext(win->graf.handle, pblk->pb_x, y, buf);
	}
	/* FIXME hrmm.. does C know how big buf was originally or does it go by the \0?*/
	free(buf);
}

void keybd_info(WINDOW *win, char *sn)
{
	/* keyboard input on info screen.. if we care, and sure we do! MGD FIXME */
}

void create_info_window(struct aim_userinfo_s *userinfo, char *prof)
{
	OBJECT *tree;
	WINDOW *infowin;
	char *buf;

	rsrc_gaddr(0, USERINFO, &tree);
	buf=malloc(sizeof(char)*(strlen(userinfo->sn)+6));
	sprintf(buf, "Info: %s", userinfo->sn);
	infowin=FormCreate(tree, NAME|MOVER, NULL, buf, NULL, TRUE, TRUE);
	DataAttach(infowin, PROF, prof);
	RsrcUserDraw(OC_FORM, infowin, USERINFO_BOX, draw_info, userinfo);
	/*EvntDataAttach(infowin, WM_XKEYBD, keybd_info, conversation->screenname);*/
	ObjcAttach(OC_FORM, infowin, USERINFO_CLOSE, BIND_FUNC, destroy_info_winclose, userinfo);
	return;
}

void req_info(WINDOW *win, int index)
{
	conversation_t *conversation;
	
	printf("Requesting info from aim servers\n");
	conversation=find_conversation_by_win(win);
	if (conversation->screenname)
	{
		aim_getinfo(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), conversation->screenname, AIM_GETINFO_GENERALINFO);
		/* reset the button.. always must reset the button.. WHY!!?!?!? IT"S A BUTTON! 
		WHY CAN'T IT DEPRESS AUTOMATICALLY!?!!!!!*/
		ObjcChange(OC_FORM, conversation->win, IM_GETINFO, NORMAL, TRUE);
	}
	return;
}

WINDOW *create_conversation_window(char *sn)
{
	WINDOW *win;
	OBJECT *tree;
	char *buf;

	buf=malloc(sizeof(char)*(20+sizeof(sn))); /* FIXME memory leak */
	sprintf(buf, "Conversation with: %s", sn);
	rsrc_gaddr(0, IM, &tree);
	win=FormCreate(tree, NAME|MOVER|CLOSER, NULL, buf, NULL, TRUE, TRUE);
	EvntAdd(win, WM_DESTROY, destroy_conversation_nowinclose, EV_TOP);
	RsrcUserDraw(OC_FORM, win, IM_USERDEF1, draw_conversation, sn);
	RsrcUserDraw(OC_FORM, win, IM_USERDEF2, draw_user_input, sn);
	EvntDataAttach(win, WM_XKEYBD, keybd_conversation, sn);
	ObjcAttach(OC_FORM, win, IM_GETINFO, BIND_FUNC, req_info);
	ObjcAttach(OC_FORM, win, IM_WARN, BIND_FUNC, conversation_warn);
	ObjcAttach(OC_FORM, win, IM_BLOCK, BIND_FUNC, conversation_block);
	ObjcAttach(OC_FORM, win, IM_CLOSE, BIND_FUNC, destroy_conversation_winclose);
	return win;
}

void newim_okay(WINDOW *win, int index)
{
	OBJECT *tree;
	char *sn;
	
  rsrc_gaddr(0, NEWIM, &tree);
	sn=ObjcString(tree, NEWIM_SCREENNAME, NULL);
	ObjcChange(OC_FORM, win, NEWIM_OKAY, NORMAL, TRUE); /* w00t */
	initiate_conversation(sn);
	Destroy(win);	
}

void newim_cancel(WINDOW *win, int index)
{
	ObjcChange(OC_FORM, win, NEWIM_CANCEL, NORMAL, TRUE);
	Destroy(win);
}

void new_im_create(void)
{
  WINDOW *win;
  OBJECT *tree;
	static char *sn;

	sn=malloc(sizeof(char)*40);   /* MGD FIXME youch!  This is a HUGE memory leak! */
	sn[0]=0;
  rsrc_gaddr(0, NEWIM, &tree);
  ObjcString(tree, NEWIM_SCREENNAME, sn);
  win=FormCreate(tree, NAME|MOVER|CLOSER, NULL, "New Instant Message", NULL, 1, 0);
	ObjcAttach(OC_FORM, win, NEWIM_OKAY, BIND_FUNC, newim_okay);
	ObjcAttach(OC_FORM, win, NEWIM_CANCEL, BIND_FUNC, newim_cancel);
}

void do_logon_form(struct faimtest_priv *priv)
{
	OBJECT *tree;
	WINDOW *win;
	int res;
	char sn[40]="", passwd[40]="";
	
	rsrc_gaddr(0, LOGON, &tree);
	ObjcString(tree, LOGON_SCREENNAME, sn);
	ObjcString(tree, LOGON_PASSWORD, passwd);
	win=FormWindBegin(tree, "Logon to AIM");
	res=FormWindDo(MU_MESAG);
	if (res==LOGON_EXIT)
	{
		FormWindEnd();
		RsrcXtype(0, NULL, 0);
		RsrcFree();
		ApplExit();
		exit(0);
	}
	FormWindEnd();
	priv->screenname=strdup(ObjcString(tree, LOGON_SCREENNAME, NULL));
	priv->password=strdup(ObjcString(tree, LOGON_PASSWORD, NULL));
}

char *tab2spc(int tab, char *dest, char *src, int max) 
{
	int fill, pos = 0;
	char *beg = dest;

	max--;
	while( *src != '\0' && 
		   *src != '\n' &&
		   *src != '\r' && max) {

		if( *src == '\t') {
			
			fill = tab - (pos % tab);
			while( fill -- && max) {
				* dest++ = ' ';
				max --;
			}
			pos += tab - (pos % tab);
			src ++;
		} else {
			*dest++ = *src++;
			max--;
			pos++;
		}
	}
	*dest = '\0';
	return beg;
}

void delete_buddylist(WINDOW *win)
{
	buddylist_t *blist = DataSearch(win, BLST);
	buddylist_t *blisttemp;
	
	if (blist)
	{
		DataDelete(win, BLST);
		while (blist->next!=NULL)
		{
			free(blist->screenname);
			blisttemp=blist->next;
			free(blist);
			blist=blisttemp;
		}
	}
}

static void blist_click(WINDOW *win)
{
	printf("Like OMG he just clicked on the buddylist window!\n");
}

void draw_buddylist(WINDOW *win)
{
	short int x, y, w, h, attr[10];
	short int hcell;
	buddylist_t *blist = DataSearch(win, BLST);
	int count=0;
	
	WindGet(win, WF_WORKXYWH, &x, &y, &w, &h);
	h += y-1;
	
	WindClear(win);
	vswr_mode(win->graf.handle, MD_TRANS);
	vqt_attributes(win->graf.handle, attr);
	hcell = HCELL;

	while (blist)
	{
		if (blist->online)
		{
			if (count>(int)win->ypos)
			{	
				y += hcell;
				/* why clip.  are we really saving that much? */
				/*if (y<clip.g_y)
					continue;*/
			
				if (strlen(blist->screenname)>win->xpos)
					v_gtext(win->graf.handle, x, y, blist->screenname + win->xpos);
				/* same here.. one of these routines is broken! (and it's my fault!)s*/
				/*if (y>MIN(h, clip.g_y + clip.g_h-1))
					break;*/
			}
			count++;
		}
		blist=blist->next;
	}
}

void add_to_buddylist(WINDOW *win, char *data)
{
	int found=0,iterations=0;
	buddylist_t *blist = DataSearch(win, BLST);
	buddylist_t *blisttemp;

	while (blist)
	{
		iterations=iterations+1;
		if (strcasecmp(data, blist->screenname)==0)
		{
			/*printf("We've found a match while adding, not doing so\n");
			printf("Our match was found after %d iterations\n", iterations);*/
			found=1;
		}
		/*printf("addtolist: looking at %s\n", blist->screenname);*/
		blist=blist->next;
	}
	
	blist=DataSearch(win, BLST);
	/* renavigate to the appropiate spot */
	while (blist->next)
		blist=blist->next;
	
	/* now we SHOULD be at the end of the list, lets make sure */
	/* Also, we don't add if we already found the buddy in the list */
	
	if (blist->next==NULL && !found)
	{
		blisttemp=malloc(sizeof(buddylist_t));
		blisttemp->next=NULL;
		blisttemp->screenname=strdup(data);
		blist->next=blisttemp;
		/*printf("I've just added %s and it should match %s\n", data, blisttemp->screenname);*/
	}
	return;
}

void remove_from_buddylist(WINDOW *win, char *data)
{
	buddylist_t *blist = DataSearch(win, BLST);
	buddylist_t *blisttemp;
	char *p;
	
	/* even more interesting, now we have to pick through the linked list
	delete and patch */
	
	while (blist)
	{
		if (blist->next)
			blisttemp=blist->next;
		else
			blisttemp=blist;
		
		/*printf("We're comparing %s and %s\n", blisttemp->screenname, data);*/
		if (!strcasecmp(blisttemp->screenname, data))
		{
			/*printf("Found sn %s in the linked list, deleting\n", data);*/
			p=blisttemp->screenname;
			if (blisttemp->next)
				blist->next=blisttemp->next;
			free(p);
			free(blisttemp);
		}
		blist=blist->next;
	}	
	return;
}

void draw_mono_icon( WINDOW *win) {
	OBJECT *tree = get_tree(GIM_ICN);
	INT16 w, h;
	
	WindGet( win, WF_WORKXYWH, &tree->ob_x, &tree->ob_y, &w, &h);
	objc_draw( tree, 0, 2, clip.g_x, clip.g_y, clip.g_w, clip.g_h);
}

WINDOW *Create_Buddylist_Window(int attrib)
{
	WINDOW *win;
	buddylist_t *blist;
	INT16 attr[10];
	
	win = WindCreate(attrib, app.x, app.y, app.w, app.h);
	mainwin=win;
	blist=create_buddylist();
	WindSetStr(win, WF_ICONTITLE, "GIM");
	WindSetPtr(win, WF_ICONDRAW, draw_mono_icon, NULL);
	EvntAdd(win, WM_REDRAW, draw_buddylist, EV_BOT);
	EvntAttach(win, WM_XBUTTON, blist_click);
	EvntAdd(win, WM_DESTROY, delete_buddylist, EV_TOP);
	vqt_attributes(win->graf.handle, attr);
	win->w_u=WCELL;  /* set slider unit to be the size of a character cell */
	win->h_u=HCELL;
	win->ypos_max=50; /* Number of lines the window is or maximum maybe? */
	/* maybe we should dynamically update the ypos based on how many blist entries
	hrmm indeed! let's add a FIXME for that */
	win->xpos_max=50;
	WindSetStr(win, WF_NAME, "Buddy List");
	WindSlider(win, VSLIDER);
	return win;
}
