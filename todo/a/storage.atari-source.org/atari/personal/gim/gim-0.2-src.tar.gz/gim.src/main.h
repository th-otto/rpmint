#ifndef __MAIN_H__
#define __MAIN_H__
extern int keepgoing;
extern aim_session_t aimsess;
extern int lines;

typedef struct buddylist_s {
	char *screenname;
	short int online;
	struct aim_userinfo_s *userinfo;
	char *prof;
	struct buddylist_s *next;
} buddylist_t;

#endif
