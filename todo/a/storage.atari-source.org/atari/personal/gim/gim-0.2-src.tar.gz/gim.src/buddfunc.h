#ifndef __BUDDYFUNC_H__
#define __BUDDYFUNC_H__

/* chat types */
#define CONV_OTHERUSER 	0
#define CONV_USER				1
#define CONV_SYSTEM			2

typedef struct chat_s
{
  char *text;
  int type;
  struct chat_s *next;
  struct chat_s *prior;
} chat_t;

typedef struct conversation_s
{
  WINDOW *win;
  char *screenname;
  char *sendbuf;
  int sendbuflen;
  chat_t *chat;
  struct conversation_s *next;
} conversation_t;

int get_num_lines(char *string, int linelen, int extra);
void print_buddylist(void);
buddylist_t *get_buddy(char *sn);
int print_chat(char *sn);
char *get_latest_chat(conversation_t *conversation);
char *get_latest_chat_num(conversation_t *conversation, int num);
int get_latest_chat_num_type(conversation_t *conversation, int num);
int initiate_conversation(char *sn);
int add_to_conversation(char *sn, char *string, int type);
int free_chat(chat_t *chat);
int free_conversation(conversation_t *conversation);
chat_t *create_chat(void);
conversation_t *create_conversation(buddylist_t *blist);
conversation_t *find_conversation(char *sn);
conversation_t *find_conversation_by_win(WINDOW *win);
buddylist_t *add_buddy(char *sn);
void remove_buddy(char *sn);
buddylist_t *add_buddy_by_win(WINDOW *win, int obj);
void remove_buddy_by_win(WINDOW *win, int obj);
void buddy_online(char *sn);
void buddy_offline(char *sn);
buddylist_t *create_buddylist(void);
char *buddylist_init(void);
void im_send_message(char *sn, char *message);

#endif
