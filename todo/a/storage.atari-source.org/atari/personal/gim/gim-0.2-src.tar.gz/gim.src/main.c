#include <scancode.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <windom.h>
#include <sys/stat.h>
#include "gim_faim.h"
#include "faimfunc.h"
#include "gim.rsh"

/* external vars can hover around main */
int lines=1;
aim_session_t aimsess;
int keepgoing=1;

typedef struct buddylist_s {
	char *screenname;
	short int online;
	struct aim_userinfo_s *userinfo;
	char *prof;
	struct buddylist_s *next;
} buddylist_t;

#include "buddfunc.h"
#include "aes.h"

int main(void)
{
	OBJECT *menu, *abouttree;
	WINDOW *win;
	extern WINDOW *mainwin;
	int res, title;
	char *str;
	int selstat = 0;

	/* Aim stuff */
	aim_conn_t *waitingconn = NULL;
	int connectstat=0;
	static int faimtest_mode = 0;
	struct timeval tv;
	time_t lastnop = 0;
	const char *buddyiconpath = NULL;
	struct faimtest_priv priv = {NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
															 0, NULL, NULL, NULL, 0, 0, 0};
  
  ApplInit();
  
   if (!RsrcLoad("GIM.RSC"))
  {
    form_alert(1, "[1][Resource File Not Found!][End]");
    ApplExit();
    exit(0);
  }
  RsrcXtype(1, NULL, 0);

	disclaimer();

  menu=get_tree(MAINMEN);
  abouttree=get_tree(ABOUTGIM);
 
  MenuBar(menu, 1);
  
  priv.server = "login.oscar.aol.com";  
  do_logon_form(&priv);

  aim_session_init(&aimsess, AIM_SESS_FLAGS_NONBLOCKCONNECT, 1);
  aim_setdebuggingcb(&aimsess, faimtest_debugcb);
  aimsess.aux_data = &priv;  

  /* end aim stuff */

  win=Create_Buddylist_Window(WAT_ALL-SIZER);
  mainwin=win;
  WindSetStr(win, WF_INFO, "* Status: Offline");
  WindSetPtr(win, WF_MENU, menu, NULL);
  WindSetStr(win, WF_NAME, "Gem Instant Messenger");
  WindOpen(win, app.w-300, 50, 300, 400);

 	if (buddyiconpath) 
 	{
		struct stat st;
		FILE *f;

		if ((stat(buddyiconpath, &st) != -1) && (st.st_size <= MAXICONLEN) && (f = fopen(buddyiconpath, "r"))) {

			priv.buddyiconlen = st.st_size;
			priv.buddyiconstamp = st.st_mtime;
			priv.buddyicon = malloc(priv.buddyiconlen);
			fread(priv.buddyicon, 1, st.st_size, f);

			priv.buddyiconsum = aim_iconsum(priv.buddyicon, priv.buddyiconlen);

			dvprintf("read %d bytes of %s for buddy icon (sum 0x%08x)\n", priv.buddyiconlen, buddyiconpath, priv.buddyiconsum);

			fclose(f);

		} 
		else
			dvprintf("could not open buddy icon %s\n", buddyiconpath);
	}

	faimtest_init();

	if (login(&aimsess, priv.screenname, priv.password) == -1) 
		exit(-1);
	
	evnt_timer(500);

	while(keepgoing)
	{
		res=EvntWindom(MU_MESAG|MU_TIMER);
		if(res & MU_MESAG && evnt.buff[0]==MN_SELECTED)
		{
			title=evnt.buff[3];
			switch(evnt.buff[4])
			{
				case MAINMEN_QUIT:
					str=get_string(QUITSURE);
					if (form_alert(1, str)==1)
					{
						Destroy(win);
						while (wglb.first) {
							ApplWrite((int)wglb.first, WM_DESTROY,0,0,0,0,0);
							EvntWindom(MU_MESAG);
						}
						aim_session_kill(&aimsess);
  					logout(&aimsess);
						RsrcXtype(0, NULL, 0);
						RsrcFree();
						ApplExit();
						exit(0);
					}
					break;
				case MAINMEN_ABOUT:
					about_gim();
					break;
				case MAINMEN_ADDBUDDY:
					not_implemented("Add a buddy");
					break;
				case MAINMEN_JOINCHAT:
					print_buddylist();
					break;
				case MAINMEN_NEWIM:
					new_im_create();
					break;
				case MAINMEN_GETUSERINFO:
					not_implemented("Get User Info");
					break;
				case MAINMEN_IMPORTBLIST:
					not_implemented("Import Buddylist");
					break;
				case MAINMEN_SIGNOFF:
					not_implemented("Sign off");
					break;
				case MAINMEN_ACCOUNTS:
					not_implemented("Accounts");
					break;
				case MAINMEN_PREFS:
					not_implemented("Preferences");
					break;
				case MAINMEN_HELPCONT:
					not_implemented("Help Contents");
					break;
				case MAINMEN_HELPINDEX:
					not_implemented("Help Index");
					break;
			}
			MenuTnormal(NULL, title, 1);
			MenuTnormal(mainwin, title, 1);
		}
	
  /* insert aim eventloop code */  
	/* FIXME - in the long run, this needs to be gone over and better integrated */
	
    tv.tv_sec = 0;
    tv.tv_usec = 500;

  waitingconn = aim_select(&aimsess, &tv, &selstat);
  if (priv.connected && ((time(NULL) - lastnop) > 30)) {
    lastnop = time(NULL);
    aim_flap_nop(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS));
  }
  if (priv.connected && !connectstat)
  {
  	  WindSetStr(win, WF_INFO, "* Status: Online");
  	  connectstat=1;
 	}

		if (selstat == -1) { /* error */
			keepgoing = 0; /* fall through */
		} else if (selstat == 0) { /* no events pending */
			;
		} else if (selstat == 1) { /* outgoing data pending */
			aim_tx_flushqueue(&aimsess);
		} else if (selstat == 2) { /* incoming data pending */
			if ((faimtest_mode < 2) && (waitingconn->fd == STDIN_FILENO)) {
				cmd_gotkey();
			} else {
				if (waitingconn->type == AIM_CONN_TYPE_RENDEZVOUS_OUT) {
					if (aim_handlerendconnect(&aimsess, waitingconn) < 0) {
						dprintf("connection error (rend out)\n");
						aim_conn_kill(&aimsess, &waitingconn);
					}
				} else {
					if (aim_get_command(&aimsess, waitingconn) >= 0) {
						aim_rxdispatch(&aimsess);
					} else {
						dvprintf("connection error (type 0x%04x:0x%04x)\n", waitingconn->type, waitingconn->subtype);
						/* we should have callbacks for all these, else the library will do the conn_kill for us. */
						if (waitingconn->type == AIM_CONN_TYPE_RENDEZVOUS) {
							if (waitingconn->subtype == AIM_CONN_SUBTYPE_OFT_DIRECTIM)
								dvprintf("disconnected from %s\n", aim_directim_getsn(waitingconn));
							aim_conn_kill(&aimsess, &waitingconn);
						} else
							aim_conn_kill(&aimsess, &waitingconn);
						if (!aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS)) {
							dprintf("major connection error\n");
							if (faimtest_mode == 2)
								break;
						}
					}
				}
			}
		}
	}
  ApplExit();
  return 0;
}
