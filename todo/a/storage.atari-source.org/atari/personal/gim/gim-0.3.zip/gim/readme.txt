GIM									Mark Duckworth
GEM Instant Messenger			http://gim.atari-source.com

Saturday February 5th, 2005
Version 0.3alpha
This is the third alpha release of GIM which has a couple bugfixes and 
some new features.
* Bugfix in preferences
* Disclaimer removal, logon dialog changes
* Killed off an awful log of debug messages.  Will probably ifdef this later
* Proportional fonts in conversations for asthetics
* Start of defining __GIM_DEBUG__ for printfs debugging
* Mouse clicks!  Now when you click a buddy in the list, it starts a convo!
* Configuration system.. Stores font settings
* Some fixes to the info dialog
* Info scrolls now
* Resource Fixes
* XaAES Fixes (MenuBar stuff)
* Window position/size saving of main buddylist window

Things to do:
scroller adjustment on blist font change

Monday May 10th 2004
Version 0.2alpha

Here is the second release of GIM which has no bugfixes that I could 
find and the following features:
* Hidden password entry for login
* improved text input in conversations
* text attributes for user entries in conversations (just bold for now)
* multiple lines in conversations
* word wrapping in conversations

This release is getting fairly useable for holding a conversation with 
someone.  Enjoy.  PLEASE read the rest of this file before giving up 
getting things working!

Tuesday May 4th 2004
Version 0.1alpha

Well here is the initial release of GEM Instant Messenger.  A long time 
coming, the last few weeks of development have been fun and productive.  
The first thing that you should understand is that this is NOT A 
FINISHED PRODUCT.  Not by any means.  I'm a fan of the release early and 
release often philosophy, and as such you will see plenty of unfinished 
releases, and in fact, GIM should not be considered a finished product 
nor critiqued until the 1.0 release.  Also important is the fact that 
there's many memory leaks, though all the memory should end up free upon 
exiting gim.  These will be slowly fixed.  Also there seems to be some 
memory corruption from time to time (poor code) that can take down the 
system here and there.  It seems to be taken care of, but not sure.

As such with this initial release here are the details:

GIM is currently more limited than it is featureful so until the 
situation becomes otherwise, here is a current feature list:
Current Features:
Buddy list - shows online and offline buddies
Multiple conversations - hold as many conversations as you want in 
separate windows
Add/Remove from buddylist in conversation
Warning - should work, though doesn't let me
Blocking - currently implemented but not yet functional

Major limitations:
No clicking on buddy list to start a conversation, must enter buddy name 
manually
Cannot sign off and back on again.

System Requirements:
You should be able to use any Atari but this is only been tested on 
Freemint 1.16 and Aranym and a Falcon with CT60.  It may crash horribly 
with other systems.  Luckily I do have most other Atari systems 
available so I can make bugfix releases if necessary to fix the problems 
associated with those systems.  GIM likely will need only around 1 or 
1.5 megs of RAM to run.  GIM currently requires MiNTnet and MiNT only, 
and should be started from within a toswin2 window.

Getting things running:
Getting things running should be simple.  There's very little in the way 
of configuration options as of now.  Modify the buddylist file, 
acct1.blt, to suit your needs and execute gim.  Because gim is using an 
older version of the libfaim library, your buddy list is not stored 
server side, but instead client side.  Changes that you make to your 
buddylist locally probably will propogate to your stored server list, 
however I do not believe starting up with an empty buddy list will trash 
your server stored buddy list.  It really depends on how the AIM servers 
work which is not 100% understood even today due to their closed nature.  
The buddy list file format is simple.  It's designed to read in gaim 
buddy lists so if you have access to a windows linux box or a properly 
setup atari, you can simply sign on to your account with gaim and hijack 
the resulting buddylist file.

The format goes like this:
m 1                (unknown, not used)
g Buddies      (gim does not yet support groups)
b buddy1
b buddy2
b buddy3       (gim only reads lines beginning with a b and imports the 
text after as a buddy ).

It's important to have a buddy line as b<space>buddyname as gim reads 3 
bytes into the line.  

Compiling GIM:

Compiling GIM is another story.  Eventually CVS access will be available 
but for now only .tar.gz archives will be made available. 

Simply download gim-0.1-src.tar.gz.  Everything is already setup for you 
to compile it.  Edit the makefiles to your liking and simply type "make" 
to build a debugging binary, or "make opt" to build an optimized 060 
binary.  This wil need to be optimized.  This will only really be 
functional with gcc 2.95.3 or higher and freemint.  Compiling under 
MagiC or singleTOS is pretty much out of the question.

You will need quite a few prerequesite libs:
Windom 0.21
GEMLib 0.43
libfaim (included)
mintlib
libreadline (sparemint)
libtermcap (sparemint)
libm (math lib, also on sparemint)

The math lib is needed for a simple ceil() function on float values for 
drawing calcs.

Generally, you really don't want to compile gim unless you know what 
you're doing.  Everything is pretty hardcoded so unless you install 
sparemint packages for all of the above, and install windom into 
/usr/lib and /usr/include you will end up having troubles.  Unless you 
intend to help out GIM development, I won't provide assistance because 
that's just a waste of my time ;-)  

GIM is licensed under the GNU GPL.  As such if I come to find the code 
used in any commercial or shareware project I'll have to personally beat 
the offender senseless.  GIM code is pretty crappy but it's probably a 
great first example of an open source windom application.  If you learn 
from GIM code, PLEASE GPL YOUR APPLICATIONS.  Be good to the community.  
Atari doesn't have room for payware anymore.  To be technical though, I 
wouldn't mind if you learned from GIM code and wrote your own closed 
application, but no code copying :)
