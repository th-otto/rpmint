#include <scancode.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <windom.h>
#include <mint/osbind.h>
#include "gim.rsh"
#include "gim_faim.h"
#include "main.h"
#include "buddfunc.h"
#include "config.h"

#define WTXT 0x57545854L /*WTXT*/
#define BLST 0x57545855L /*BLST*/
#define CONV 0x57545856L /*CONV*/
#define PROF 0x57545857L /*PROF*/
#define UNFO 0x57545858L /*UNFO*/
#define INFOS 0x57545859L /*INFOS*/

#define DEBUG(s)	FormAlert(1,"[1][Text %d|%s][ok]", __LINE__, s)
#define TESTATTR

#define VT_UNIX 1
#define VT_DOS 2
#define VT_MAC 3

#define WCAR	attr[6]
#define HCAR	attr[7]
#define WCELL attr[8]
#define HCELL	attr[9]

#define BOLD_BEG "�B"
#define BOLD_END "�b"
#define ITAL_BEG "�I"
#define ITAL_END "�i"
#define UNDL_BEG "�U"
#define UNDL_END "�u"
#define NONE_END "�0"

#define BOLD 0x1
#define LIGH 0x2
#define ITAL 0x4
#define UNDL 0x8

#define SYS_TOS    0x0001
#define SYS_MAGIC  0x0002
#define SYS_MINT   0x0004
#define SYS_GENEVA 0x0010
#define SYS_NAES   0x0020
#define SYS_XAAES  0x0040
#define WORD short
#define UWORD unsigned short
UWORD _systype_v;
UWORD _systype(void);
#define sys_type()    (_systype_v ? _systype_v : _systype())
#define sys_MAGIC()   ((sys_type() & SYS_MAGIC) != 0)
#define sys_NAES()    ((sys_type() & SYS_NAES)  != 0)
#define sys_XAAES()   ((sys_type() & SYS_XAAES) != 0)

/* Special thanks to Ralph Lowinski and the highwire project for
   this aes detection code! */

UWORD
_systype (void)
{
	long * ptr = (long *)Setexc(0x5A0/4, (void (*)())-1);
	
	_systype_v = SYS_TOS;
	
	if (!ptr) {
		return _systype_v;   /* stone old TOS without any cookie support */
	}
	while (*ptr) {
		if (*ptr == 0x4D674D63L/*MgMc*/ || *ptr == 0x4D616758L/*MagX*/) {
			_systype_v = (_systype_v & ~0xF) | SYS_MAGIC;
		} else if (*ptr == 0x4D694E54L/*MiNT*/) {
			_systype_v = (_systype_v & ~0xF) | SYS_MINT;
		
		} else if (*ptr == 0x476E7661L/*Gnva*/) {
			_systype_v |= SYS_GENEVA;
		} else if (*ptr == 0x6E414553L/*nAES*/) {
			_systype_v |= SYS_NAES;
		}
		ptr += 2;
	}
	if (_systype_v & SYS_MINT) { /* check for XaAES */
		WORD out = 0, u;
		if (wind_get (0, (((WORD)'X') <<8)|'A', &out, &u,&u,&u) && out) {
			_systype_v |= SYS_XAAES;
		}
	}
	return _systype_v;
}

typedef struct buddyinfo_s {
	struct aim_userinfo_s *userinfo;
	char *prof;
	int offset;
} buddyinfo_t;

/* We might not need this anymore
char *buddylist=" * AOL Instant Messenger *";*/
WINDOW *mainwin;

void grect_conv(PARMBLK *pblk, short int *array)
{
	*array++ = pblk->pb_x;
	*array++ = pblk->pb_y;
	*array++ = pblk->pb_x+pblk->pb_w - 1;
	*array = pblk->pb_y + pblk->pb_h - 1;
}

void Destroy(WINDOW *win)
{
	WindClose(win);
	WindDelete(win);
	return;
}

char *get_string(int idx)
{
	char *txt;
	rsrc_gaddr(5, idx, &txt);
	return txt;
}

OBJECT *get_tree(int idx)
{
	OBJECT *tree;
	rsrc_gaddr(0, idx, &tree);
	return tree;
}

void about_gim(void)
{
	WINDOW *win;
	int res;

	win=FormWindBegin(get_tree(ABOUTGIM), get_string(APP_NAME));
	res = FormWindDo(MU_MESAG|MU_BUTTON|MU_KEYBD);
	if (res==ABOUTGIM_OKAYBUTTON)
	{
		ObjcChange(OC_FORM, win, res, NORMAL, 0);
		FormWindEnd();
	}
}

void set_conversation_window_state(void)
{
	OBJECT *tree;
	conversation_t *conversation = DataSearch(mainwin, CONV);
	
	while (conversation)
	{	
		tree=ObjcTree(OC_FORM, conversation->win);
		if (get_buddy(conversation->screenname))
		{
			ObjcStrCpy(tree, IM_ADDREMOVE, "Remove from Buddylist");
#ifdef __GIM_DEBUG__
			printf("ObjcAttach remove sn is: %s\n", conversation->screenname);
#endif
			ObjcAttach(OC_FORM, conversation->win, IM_ADDREMOVE, BIND_FUNC, remove_buddy_by_win);
			ObjcChange(OC_FORM, conversation->win, IM_ADDREMOVE, NORMAL, TRUE); /* w00t */
		}
		else
		{
			ObjcStrCpy(tree, IM_ADDREMOVE, "   Add to Buddylist  ");
#ifdef __GIM_DEBUG__
			printf("ObjcAttach add sn is: %s\n", conversation->screenname);
#endif
			ObjcAttach(OC_FORM, conversation->win, IM_ADDREMOVE, BIND_FUNC, add_buddy_by_win);
			ObjcChange(OC_FORM, conversation->win, IM_ADDREMOVE, NORMAL, TRUE); /* w00t */
		}
		conversation=conversation->next;
	}
	draw_buddylist(mainwin);
}

void not_implemented(char *msg)
{
	FormAlert(1, "[1][%s is not yet implemented.  Sorry.][Okay]", msg);
}

void draw_user_input(WINDOW *win, PARMBLK *pblk, char *sn)
{
	/* This function should at very LEAST be fixed to not redraw the whole
	freaking window ;-) */
	conversation_t *conversation;
	char *buf;
	short int x,y,w,h,attr[10];
	short int hcell, wcell;
	short int pxy[8];
	int run=0, linelen=0, runs=0, templen=0;
	
	conversation=find_conversation(sn);
	h=pblk->pb_h;
	w=pblk->pb_w;
	x=pblk->pb_x;
	y=pblk->pb_y-1;;
	grect_conv(pblk, pxy);
	vsf_color(win->graf.handle, WHITE);
	vr_recfl(win->graf.handle, pxy);
	vswr_mode(win->graf.handle, MD_TRANS);
	vst_font(win->graf.handle, prefs->convinfontid);
	vst_point(win->graf.handle, prefs->convinfontsize, NULL, NULL, NULL, NULL);
	vqt_attributes(win->graf.handle, attr);
	hcell=HCELL;
	wcell=WCELL;
	y+=hcell;
	linelen=pblk->pb_w/wcell;
	buf=malloc(sizeof(char)*linelen);
	runs=ceil((float)conversation->sendbuflen/(float)linelen);

#ifdef __GIM_DEBUG__
	printf("linelen %d, runs: %d\n", linelen, runs);
#endif
	
	if (conversation->sendbuflen)
		while (run<runs)
		{
#ifdef __GIM_DEBUG__
			printf("Looping once, run: %d\n", run);
#endif
			if (linelen>conversation->sendbuflen)
			{
				strncpy(buf, conversation->sendbuf, conversation->sendbuflen);
				buf[conversation->sendbuflen]='\0';				
			}
			else
			{
				if (runs-run==1)
				{
					templen=conversation->sendbuflen-(run*linelen);
					strncpy(buf, (run*linelen)+conversation->sendbuf, templen);
					buf[templen]='\0';
				}
				else
				{
					strncpy(buf, (run*linelen)+conversation->sendbuf, linelen);
					buf[linelen]='\0';
				}		
			}
			v_gtext(win->graf.handle, pblk->pb_x, y, buf);
			y+=hcell;
			run++;
		}
	free(buf);
}

void draw_conversation_nonprop(WINDOW *win, PARMBLK *pblk, char *sn)
{
	conversation_t *conversation;
	short int x,y,w,h,attr[10];
	short int hcell;
	short int wcell;
	int k=0, i=0, j=0, linelen=0, origlinelen=0, templen=0, drawn=0, lefttodraw=0, numlines=0;
	int fontattr=0;
	int hlines;
	short int pxy[8];
	char *textstring = NULL, *buf = NULL;

	conversation=find_conversation(sn);
	h=pblk->pb_h;
	w=pblk->pb_w;
	x=pblk->pb_x;
	y=pblk->pb_y;
	h+=pblk->pb_y-1;
	grect_conv(pblk, pxy);
	vsf_color(win->graf.handle, WHITE);
	vr_recfl(win->graf.handle, pxy);
	vswr_mode(win->graf.handle, MD_TRANS);
	vqt_attributes(win->graf.handle, attr);
	hcell = HCELL;
	w = HCELL - HCAR;
	wcell = WCELL;	
	hlines=pblk->pb_h/hcell;
	y+=hcell*hlines;
	origlinelen=pblk->pb_w/wcell;
	linelen=origlinelen;

	for (j=0;j<=hlines;j++)
	{
		textstring=get_latest_chat_num(conversation, j);
		if (textstring)
		{
			if (get_latest_chat_num_type(conversation, j)==0)
			{
				drawn=0;
				lefttodraw=strlen(textstring);
				buf=malloc(sizeof(char)*linelen);
				numlines=get_num_lines(textstring, linelen, strlen(sn)+2);
				y-=hcell*numlines;
				for (i=1;i<=numlines;i++)
				{
					if (i==1)
					{
						fontattr|=BOLD;
						vst_effects(win->graf.handle, fontattr);
						vst_color(win->graf.handle, 2);
						v_gtext(win->graf.handle, x, y, sn);
						v_gtext(win->graf.handle, x+(wcell*strlen(sn)), y, ": ");
						fontattr&=~BOLD;
						vst_effects(win->graf.handle, fontattr);
						vst_color(win->graf.handle, 1);
						templen=linelen;
						templen-=(strlen(sn)+2);
						if (i<numlines)
							for (k=(drawn+templen);textstring[k]!=' '; k--)
								templen--;
						else
							templen=lefttodraw;
						strncpy(buf, drawn+textstring, templen);
						buf[templen]='\0';
						lefttodraw-=templen-1;
						drawn+=templen+1;
						v_gtext(win->graf.handle, x+(wcell*(strlen(sn)+2)), y, buf);
						y+=hcell;
					}
					else
					{
						templen=linelen;
						if (i<numlines)
							for (k=(drawn+templen);textstring[k]!=' ';k--)
								templen--;
						else
							templen=lefttodraw;
						strncpy(buf, drawn+textstring, templen);
						buf[templen]='\0';
						lefttodraw-=templen-1;
						drawn+=templen+1;
						v_gtext(win->graf.handle, x, y, buf);
						y+=hcell;
					}
				}
				y-=hcell*(numlines);
			}
			if (get_latest_chat_num_type(conversation, j)==1)
			{
				/* Prefix myself */
				drawn=0;
				lefttodraw=strlen(textstring);
				buf=malloc(sizeof(char)*linelen);
				numlines=get_num_lines(textstring, linelen, 8);
				y-=hcell*numlines;
				for (i=1;i<=numlines;i++)
				{
					if (i==1)
					{
						fontattr|=BOLD;
						vst_effects(win->graf.handle, fontattr);
						vst_color(win->graf.handle, 4);
						v_gtext(win->graf.handle, x, y, "Myself: ");
						fontattr&=~BOLD;
						vst_effects(win->graf.handle, fontattr);
						vst_color(win->graf.handle, 1);
						templen=linelen;
						templen-=8;
						if (i<numlines)
							for (k=(drawn+templen);textstring[k]!=' '; k--)
								templen--;
						else
							templen=lefttodraw;
						strncpy(buf, drawn+textstring, templen);
						buf[templen]='\0';
						lefttodraw-=templen-1;
						drawn+=templen+1;
						v_gtext(win->graf.handle, x+(wcell*8), y, buf);
						y+=hcell;
					}
					else
					{
						templen=linelen;
						if (i<numlines)
							for (k=(drawn+templen);textstring[k]!=' ';k--)
								templen--;
						else
							templen=lefttodraw;
						strncpy(buf, drawn+textstring, templen);
						buf[templen]='\0';
						lefttodraw-=templen-1;
						drawn+=templen+1;
						v_gtext(win->graf.handle, x, y, buf);
						y+=hcell;
					}
				}
				y-=hcell*(numlines);
			}
			if (get_latest_chat_num_type(conversation, j)==2)
			{
				/* Draw system, lets just not worry about word wrap here for now */
				/* Assume the system is smart enough to do it itself, seeing as how we are
				   the system!  ;-)  */
				drawn=0;
				lefttodraw=strlen(textstring);
				buf=malloc(sizeof(char)*linelen);
				strncpy(buf, textstring, lefttodraw);
				y-=hcell;
				v_gtext(win->graf.handle, x, y, buf);
				y+=hcell;
			}
			free(buf);
		}
	}
	/* 1, myself, 2 just draw (system) */
}
int get_wrap_string(WINDOW *win, char *string, int maxwidth)
{
	short int i=0;
	int j=0;
	short int cw;
	
	while (i<maxwidth)
	{
		vqt_width(win->graf.handle, string[j], &cw, NULL, NULL);
		i+=cw;
		j++;
	}		
	for (j=j;string[j]!=' ';j--)
	{
		vqt_width(win->graf.handle, string[j], &cw, NULL, NULL);
		i-=cw;
	}
	return j;
}

void draw_conversation(WINDOW *win, PARMBLK *pblk, char *sn)
{
	conversation_t *conversation;
	short int x,y,w,h,hcell,wcell,attr[10];
	int i=0, j=0, templen=0, drawn=0, lefttodraw=0, numlines=0, fontattr=0, beginwidth=0;
	int hlines;
	short int pxy[8];
	char *textstring = NULL;
	char *buf = NULL, *tempbuf = NULL;

	conversation=find_conversation(sn);
	h=pblk->pb_h;
	w=pblk->pb_w;
	x=pblk->pb_x;
	y=pblk->pb_y;
	h+=pblk->pb_y-1;
	grect_conv(pblk, pxy);
	vsf_color(win->graf.handle, WHITE);
	vr_recfl(win->graf.handle, pxy);
	vswr_mode(win->graf.handle, MD_TRANS);
	vst_font(win->graf.handle, prefs->convfontid);
	vst_point(win->graf.handle, prefs->convfontsize, NULL, NULL, NULL, NULL);
	vqt_attributes(win->graf.handle, attr);
	hcell = HCELL;
	w = HCELL - HCAR;
	wcell = WCELL;	
	hlines=pblk->pb_h/hcell;
	y+=hcell*hlines;

	for (j=0;j<=hlines;j++)
	{
		textstring=get_latest_chat_num(conversation, j);
		if (textstring)
		{
			if (get_latest_chat_num_type(conversation, j)==0)
			{
				drawn=0;
				lefttodraw=strlen(textstring);
				buf=malloc(sizeof(char)*1024);
				tempbuf=malloc(sizeof(char)*(strlen(textstring)+strlen(sn)+2));
				sprintf(tempbuf, "%s%s%s", sn, ": ", textstring);
				numlines=get_num_lines_prop(tempbuf, win, pblk->pb_w);
				free(tempbuf);
				y-=hcell*numlines;
				for (i=1;i<=numlines;i++)
				{
					if (i==1)
					{
						fontattr|=BOLD;
						vst_effects(win->graf.handle, fontattr);
						vst_color(win->graf.handle, RED);
						v_gtext(win->graf.handle, x, y, sn);
						vqt_extent(win->graf.handle, sn, pxy);
						beginwidth=pxy[2]-pxy[0];
						v_gtext(win->graf.handle, x+beginwidth, y, ": ");
						vqt_extent(win->graf.handle, ": ", pxy);
						beginwidth+=pxy[2]-pxy[0];
						fontattr&=~BOLD;
						vst_effects(win->graf.handle, fontattr);
						vst_color(win->graf.handle, BLACK);
						if (i<numlines)
							templen=get_wrap_string(win, drawn+textstring, pblk->pb_w-beginwidth);
						else
							templen=lefttodraw;
						strncpy(buf, drawn+textstring, templen);
						buf[templen]='\0';
						drawn+=templen+1;
						lefttodraw-=templen-1;
						v_gtext(win->graf.handle, x+beginwidth, y, buf);
						y+=hcell;
					}
					else
					{
						if (i<numlines)
							templen=get_wrap_string(win, drawn+textstring, pblk->pb_w);
						else
							templen=lefttodraw;
						strncpy(buf, drawn+textstring, templen);
						buf[templen]='\0';
						lefttodraw-=templen-1;
						drawn+=templen+1;
						v_gtext(win->graf.handle, x, y, buf);
						y+=hcell;
					}
				}
				y-=hcell*(numlines);
			}
			else if (get_latest_chat_num_type(conversation, j)==1)
			{
				drawn=0;
				lefttodraw=strlen(textstring);
				buf=malloc(sizeof(char)*1024);
				tempbuf=malloc(sizeof(char)*(strlen(textstring)+8));
				sprintf(tempbuf, "Myself: %s", textstring);
				numlines=get_num_lines_prop(tempbuf, win, pblk->pb_w);
				free(tempbuf);
				y-=hcell*numlines;
				for (i=1;i<=numlines;i++)
				{
					if (i==1)
					{
						fontattr|=BOLD;
						vst_effects(win->graf.handle, fontattr);
						vst_color(win->graf.handle, BLUE);
						v_gtext(win->graf.handle, x, y, "Myself: ");
						vqt_extent(win->graf.handle, "Myself: ", pxy);
						beginwidth=pxy[2]-pxy[0];
						fontattr&=~BOLD;
						vst_effects(win->graf.handle, fontattr);
						vst_color(win->graf.handle, BLACK);
						if (i<numlines)
							templen=get_wrap_string(win, drawn+textstring, pblk->pb_w-beginwidth);
						else
							templen=lefttodraw;
						strncpy(buf, drawn+textstring, templen);
						buf[templen]='\0';
						drawn+=templen+1;
						lefttodraw-=templen-1;
						v_gtext(win->graf.handle, x+beginwidth, y, buf);
						y+=hcell;
					}
					else
					{
						if (i<numlines)
							templen=get_wrap_string(win, drawn+textstring, pblk->pb_w);
						else
							templen=lefttodraw;
						strncpy(buf, drawn+textstring, templen);
						buf[templen]='\0';
						lefttodraw-=templen-1;
						drawn+=templen+1;
						v_gtext(win->graf.handle, x, y, buf);
						y+=hcell;
					}
				}
				y-=hcell*(numlines);
			}
			else if (get_latest_chat_num_type(conversation, j)==2)
			{
				buf=malloc(sizeof(char)*1024);
				strncpy(buf, textstring, strlen(textstring));
				buf[strlen(textstring)]='\0';
				y-=hcell;
				v_gtext(win->graf.handle, x, y, buf);
				y-=hcell;
			}
			free(buf);
		}
	}
	/* 1, myself, 2 just draw (system) */
}

void draw_conversation_old(WINDOW *win, PARMBLK *pblk, char *sn)
{
	conversation_t *conversation;
	short int x,y,w,h,attr[10];
	short int hcell;
	short int wcell;
	int i;
	short int pxy[8];
	char *textstring;

	conversation=find_conversation(sn);
	h=pblk->pb_h;
	w=pblk->pb_w;
	x=pblk->pb_x;
	y=pblk->pb_y;
	h+=pblk->pb_y-1;
	grect_conv(pblk, pxy);
	vsf_color(win->graf.handle, WHITE);
	vr_recfl(win->graf.handle, pxy);
	vswr_mode(win->graf.handle, MD_TRANS);
	vqt_attributes(win->graf.handle, attr);
	hcell = HCELL;
	w = HCELL - HCAR;
	wcell = WCELL;
	y+=hcell;
	for(i=8;i>=0;i--)
	{
		textstring=get_latest_chat_num(conversation, i);
		if (textstring)
		{
			if (get_latest_chat_num_type(conversation, i)==0)
			{
				v_gtext(win->graf.handle, x, y, sn);
				v_gtext(win->graf.handle, x+(wcell*(strlen(sn))), y, ": ");
				v_gtext(win->graf.handle, x+(wcell*(strlen(sn)+2)), y, textstring);
			}
			else if (get_latest_chat_num_type(conversation, i)==1)
			{
				v_gtext(win->graf.handle, x, y, "Myself: ");
				v_gtext(win->graf.handle, x+(wcell*8), y, textstring);
			}
			else if (get_latest_chat_num_type(conversation, i)==2)
				v_gtext(win->graf.handle, x, y, textstring);
		}
		y+=hcell;
	}
	return;
}

void redraw_conversation(WINDOW *win)
{
	EvntRedraw(win);
	return;
}

void keybd_conversation(WINDOW *win, char *sn)
{
	char *buf;
	/*char key = keybd2ascii(evnt.keybd, evnt.mkstate & (K_LSHIFT|K_RSHIFT));
	char keyout[3];
	int i=0;*/
	conversation_t *conversation;
				
	conversation=find_conversation(sn);
	if (!conversation->sendbuf)
	{
		conversation->sendbuf=malloc(sizeof(char)*4096);  /* FIXME WE need to establish size */
		conversation->sendbuf[4096]='\0';
		conversation->sendbuflen=0;
		memset(conversation->sendbuf, ' ', strlen(conversation->sendbuf));
	}
	switch (evnt.keybd>>8) {
		case SC_RETURN:
			if (conversation->sendbuflen)
      {
        buf=malloc(sizeof(char)*conversation->sendbuflen);
				strncpy(buf, conversation->sendbuf, conversation->sendbuflen);
				buf[conversation->sendbuflen]='\0';
				im_send_message(sn, buf);
				free(buf);
				free(conversation->sendbuf);
				conversation->sendbuflen=0;
				conversation->sendbuf=NULL;
				redraw_conversation(win);
			}
			break;
		case SC_BACK:
			if (conversation->sendbuflen)
			{
				conversation->sendbuf[conversation->sendbuflen-1]=' ';
				ObjcDraw(OC_FORM, win, IM_USERDEF2, 0);
				conversation->sendbuflen--;
			}
			break;
		case SC_DEL:
			break;
		default:
			conversation->sendbuf[conversation->sendbuflen++]=evnt.keybd;
			ObjcDraw(OC_FORM, win, IM_USERDEF2, 0);
	}
}

void destroy_conversation_nowinclose(WINDOW *win)
{
	conversation_t *conversation;
	
	conversation=DataSearch(mainwin, CONV);
	while (conversation->win!=win)
		conversation=conversation->next;
	if (conversation->win==win)
		free_conversation(conversation);
	else
		printf("Windows don't match in delete_conversation_full!\n");
}

void destroy_conversation_winclose(WINDOW *win)
{
	conversation_t *conversation;
	
	conversation=DataSearch(mainwin, CONV);
	while (conversation->win!=win && conversation!=NULL)
		conversation=conversation->next;
	if (conversation->win==win)
	{
		free_conversation(conversation);
		Destroy(win);
	}
	else
		printf("Windows don't match in delete_conversation_full!\n");
}

void conversation_warn(WINDOW *win)
{
	conversation_t *conversation;
	char *str;
		
	if ((conversation=find_conversation_by_win(win)))
	{
		str=get_string(WARN);
		if (form_alert(1, str)==1)
			aim_send_warning(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), conversation->screenname, AIM_WARN_ANON);
		else
			aim_send_warning(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), conversation->screenname, 0);
		ObjcChange(OC_FORM, win, IM_WARN, NORMAL, TRUE);
	}
	else
		return;
}

void conversation_block(WINDOW *win)
{
	conversation_t *conversation = NULL;
	char *namelist;
	
	namelist=malloc(sizeof(char)*(strlen(conversation->screenname)+1));
	sprintf(namelist, "%s&", conversation->screenname);
	if ((conversation=find_conversation_by_win(win)))
	{
		aim_bos_changevisibility(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), AIM_VISIBILITYCHANGE_DENYADD, namelist);		
		ObjcChange(OC_FORM, win, IM_BLOCK, NORMAL, TRUE);
		EvntRedraw(win);
		EvntRedraw(mainwin);
	}
	else
		return;
}

void destroy_info_winclose(WINDOW *win, int index, int mode, buddyinfo_t *buddyinfo)
{	
	ObjcChange(OC_FORM, win, USERINFO_CLOSE, NORMAL, TRUE);
	Destroy(win);
	free(buddyinfo->prof);
	free(buddyinfo->userinfo);
}

void draw_info(WINDOW *win, PARMBLK *pblk, buddyinfo_t *buddyinfo)
{
	char *buf;
	time_t time_slot;
	struct tm *online_loctime = malloc(sizeof(struct tm));
	short int x,y,attr[10];
	short int hcell, wcell;
	int linelen=0, templen=0, lefttodraw=0, drawn=0, i=0, count=0;
	short int pxy[8];
	int returnstate=0;

	x=pblk->pb_x;
	y=pblk->pb_y-1;
	grect_conv(pblk, pxy);
	vsf_color(win->graf.handle, WHITE);
	vr_recfl(win->graf.handle, pxy);
	vswr_mode(win->graf.handle, MD_TRANS);
	vst_font(win->graf.handle, prefs->infofontid);
	vqt_attributes(win->graf.handle, attr);
	hcell=HCELL;
	wcell=WCELL;
	y+=hcell;
	lefttodraw=strlen(buddyinfo->prof);
	linelen=pblk->pb_w/wcell;
	buf=malloc(sizeof(char)*4096);
	//buf=malloc(sizeof(char)*linelen);

	time_slot=(time_t)buddyinfo->userinfo->onlinesince;
	online_loctime=localtime(&time_slot);

	sprintf(buf, "Member Since: %lu", buddyinfo->userinfo->membersince);
	v_gtext(win->graf.handle, pblk->pb_x, y, buf);
	y+=hcell;
	sprintf(buf, "Online Since: %s", asctime(online_loctime));
	v_gtext(win->graf.handle, pblk->pb_x, y, buf);
	y+=hcell;
	sprintf(buf, "Idle Time: 0x%04x", buddyinfo->userinfo->idletime);
	v_gtext(win->graf.handle, pblk->pb_x, y, buf);
	y+=hcell;
	sprintf(buf, "Capabilities: 0x%04x", buddyinfo->userinfo->capabilities);
	v_gtext(win->graf.handle, pblk->pb_x, y, buf);
	y+=hcell;
	v_gtext(win->graf.handle, pblk->pb_x, y, "**********************");
	y+=hcell;

	if (lefttodraw)
	{		
		buddyinfo->prof[lefttodraw]='\0';
		while (lefttodraw>linelen)
		{
			templen=linelen;
			for (i=(drawn+linelen);buddyinfo->prof[i]!='\n' && i>drawn;i--)
				templen--;
			if (!templen) /* No return found, reset and proceed */
			{
				templen=linelen;
				for (i=(drawn+linelen);buddyinfo->prof[i]!=' ' && i>drawn;i--)
					templen--;
				if (!templen) /* no spaces on this line! */
					templen=linelen;
			}
			else
			{
				templen--;
				returnstate=1;
			}
			strncpy(buf, drawn+buddyinfo->prof, templen);
			buf[templen]='\0';
			if (returnstate)
			{
				templen++;
				returnstate=0;
			}
			lefttodraw -= templen-1;
			drawn += templen+1;
			if (count==buddyinfo->offset)
			{
				v_gtext(win->graf.handle, pblk->pb_x, y, buf);
				y+=hcell;
			}
			else
				count++;
		}
		strncpy(buf, drawn+buddyinfo->prof, lefttodraw);
		buf[lefttodraw]='\0';
		if (count==buddyinfo->offset)
			v_gtext(win->graf.handle, pblk->pb_x, y, buf);
	}
	free(buf);
}

void up_info_window(WINDOW *win, int index, int mode, buddyinfo_t *buddyinfo)
{
	ObjcChange(OC_FORM, win, USERINFO_UP, NORMAL, TRUE);
	if (buddyinfo->offset)
	{
		buddyinfo->offset--;
		EvntRedraw(win);
	}
#ifdef __GIM_DEBUG__
	printf("Offset is: %d\n", buddyinfo->offset);
#endif
}

void dn_info_window(WINDOW *win, int index, int mode, buddyinfo_t *buddyinfo)
{
	ObjcChange(OC_FORM, win, USERINFO_DN, NORMAL, TRUE);
	buddyinfo->offset++;
	EvntRedraw(win);
#ifdef __GIM_DEBUG__
	printf("Offset is: %d\n", buddyinfo->offset);
#endif
}

void create_info_window(struct aim_userinfo_s *userinfo, char *prof)
{
	OBJECT *tree;
	WINDOW *infowin;
	char *buf;
	buddyinfo_t *buddyinfo = NULL;

	buddyinfo=malloc(sizeof(buddyinfo_t));
	rsrc_gaddr(0, USERINFO, &tree);
	buf=malloc(sizeof(char)*(strlen(userinfo->sn)+6));
	sprintf(buf, "Info: %s", userinfo->sn);
	infowin=FormCreate(tree, NAME|MOVER, NULL, buf, NULL, TRUE, TRUE);
	buddyinfo->offset=0;
	buddyinfo->prof=strdup(prof);
	buddyinfo->userinfo=userinfo;
	RsrcUserDraw(OC_FORM, infowin, USERINFO_BOX, draw_info, buddyinfo);
	ObjcAttach(OC_FORM, infowin, USERINFO_CLOSE, BIND_FUNC, destroy_info_winclose, buddyinfo);
	ObjcAttach(OC_FORM, infowin, USERINFO_UP, BIND_FUNC, up_info_window, buddyinfo);
	ObjcAttach(OC_FORM, infowin, USERINFO_DN, BIND_FUNC, dn_info_window, buddyinfo);
	return;
}

void req_info(WINDOW *win, int index)
{
	conversation_t *conversation;
	
#ifdef __GIM_DEBUG__
	printf("Requesting info from aim servers\n");
#endif
	conversation=find_conversation_by_win(win);
	if (conversation->screenname)
	{
		aim_getinfo(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), conversation->screenname, AIM_GETINFO_GENERALINFO);
		ObjcChange(OC_FORM, conversation->win, IM_GETINFO, NORMAL, TRUE);
	}
	return;
}

void set_away(void)
{
	/* we need to open the away message dialog and stuff */
}

WINDOW *create_conversation_window(char *sn)
{
	WINDOW *win;
	OBJECT *tree;
	char *buf;

	buf=malloc(sizeof(char)*(20+sizeof(sn))); /* FIXME memory leak */
	sprintf(buf, "Conversation with: %s", sn);
	rsrc_gaddr(0, IM, &tree);
	win=FormCreate(tree, NAME|MOVER|CLOSER, NULL, buf, NULL, TRUE, TRUE);
	EvntAdd(win, WM_DESTROY, destroy_conversation_nowinclose, EV_TOP);
	RsrcUserDraw(OC_FORM, win, IM_USERDEF1, draw_conversation, sn);
	RsrcUserDraw(OC_FORM, win, IM_USERDEF2, draw_user_input, sn);
	EvntDataAttach(win, WM_XKEYBD, keybd_conversation, sn);
	ObjcAttach(OC_FORM, win, IM_GETINFO, BIND_FUNC, req_info);
	ObjcAttach(OC_FORM, win, IM_WARN, BIND_FUNC, conversation_warn);
	ObjcAttach(OC_FORM, win, IM_BLOCK, BIND_FUNC, conversation_block);
	ObjcAttach(OC_FORM, win, IM_CLOSE, BIND_FUNC, destroy_conversation_winclose);
	return win;
}

void destroy_set_info(void)
{

}

void draw_set_info(WINDOW *win, PARMBLK *pblk)
{
	/* This function should at very LEAST be fixed to not redraw the whole
	freaking window ;-) */
	char *buf;
	short int x,y,w,h,attr[10];
	short int hcell, wcell;
	int run=0, linelen=0, runs=0, templen=0, proflen=0;
	short int pxy[8];

	h=pblk->pb_h;
	w=pblk->pb_w;
	x=pblk->pb_x;
	y=pblk->pb_y-1;
	grect_conv(pblk, pxy);
	vsf_color(win->graf.handle, WHITE);
	vr_recfl(win->graf.handle, pxy);
	vswr_mode(win->graf.handle, MD_TRANS);
	vst_font(win->graf.handle, prefs->convinfontid);
	vst_point(win->graf.handle, prefs->convinfontsize, NULL, NULL, NULL, NULL);
	vqt_attributes(win->graf.handle, attr);
	hcell=HCELL;
	wcell=WCELL;
	y+=hcell;
	linelen=pblk->pb_w/wcell;
	buf=malloc(sizeof(char)*linelen);
	proflen=strlen(prefs->profile);
	runs=ceil((float)proflen/(float)linelen);
#ifdef __GIM_DEBUG__
	printf("linelen %d, runs: %d\n", linelen, runs);
#endif
	
	if (prefs->profile)
		while (run<runs)
		{
#ifdef __GIM_DEBUG__
			printf("Looping once, run: %d\n", run);
#endif
			if (linelen>proflen)
			{
				strncpy(buf, prefs->profile, proflen);
				buf[proflen]='\0';				
			}
			else
			{
				if (runs-run==1)
				{
					templen=proflen-(run*linelen);
					strncpy(buf, (run*linelen)+prefs->profile, templen);
					buf[templen]='\0';
				}
				else
				{
					strncpy(buf, (run*linelen)+prefs->profile, linelen);
					buf[linelen]='\0';
				}
			}
			v_gtext(win->graf.handle, pblk->pb_x, y, buf);
			y+=hcell;
			run++;
		}
	free(buf);
}

void keybd_set_info(WINDOW *win)
{
	char *buf;
	int proflen;
				
	/* We can guarantee a 4096 byte profile buffer now */
	proflen=strlen(prefs->profile);

	switch (evnt.keybd>>8) {
		case SC_RETURN:
			if (proflen)
      {
        buf=malloc(sizeof(char)*proflen);
				strncpy(buf, prefs->profile, proflen);
				buf[proflen]='\0';
				set_profile(buf);
				free(buf);
				save_prefs();
				Destroy(win);
			}
			break;
		case SC_BACK:
			if (proflen)
			{
				prefs->profile[proflen-1]='\0';
				EvntRedraw(win);
			}
			break;
		case SC_DEL:
			break;
		default:
			prefs->profile[proflen]=evnt.keybd;
			prefs->profile[proflen+1]='\0';
			ObjcDraw(OC_FORM, win, INFO_ED_USERDEF1, 0);
	}
}

void set_info_okay(WINDOW *win, int index)
{
	int proflen;
	char *buf;
	
	proflen=strlen(prefs->profile);
	
	ObjcChange(OC_FORM, win, INFO_ED_OKAY, NORMAL, TRUE);
	if (proflen)
  {
    buf=malloc(sizeof(char)*proflen);
		strncpy(buf, prefs->profile, proflen);
		buf[proflen]='\0';
		set_profile(buf);
		free(buf);
	}
	save_prefs();
	Destroy(win);
}

void set_info_cancel(WINDOW *win, int index)
{
	ObjcChange(OC_FORM, win, INFO_ED_CANCEL, NORMAL, TRUE);
	Destroy(win);
}

void create_set_info_window(void)
{
	WINDOW *win;
	OBJECT *tree;
	
	rsrc_gaddr(0, INFO_ED, &tree);
	win=FormCreate(tree, NAME|MOVER|CLOSER, NULL, "Modify Profile", NULL, TRUE, TRUE);
	EvntAdd(win, WM_DESTROY, destroy_set_info, EV_TOP);
	RsrcUserDraw(OC_FORM, win, INFO_ED_USERDEF1, draw_set_info, NULL);
	EvntAttach(win, WM_XKEYBD, keybd_set_info);
	ObjcAttach(OC_FORM, win, INFO_ED_CANCEL, BIND_FUNC, set_info_cancel);
	ObjcAttach(OC_FORM, win, INFO_ED_OKAY, BIND_FUNC, set_info_okay);
}

void newim_okay(WINDOW *win, int index)
{
	OBJECT *tree;
	char *sn;
	
  rsrc_gaddr(0, NEWIM, &tree);
	sn=ObjcString(tree, NEWIM_SCREENNAME, NULL);
	ObjcChange(OC_FORM, win, NEWIM_OKAY, NORMAL, TRUE);
	initiate_conversation(sn);
	Destroy(win);	
}

void newim_cancel(WINDOW *win, int index)
{
	ObjcChange(OC_FORM, win, NEWIM_CANCEL, NORMAL, TRUE);
	Destroy(win);
}

void new_im_create(void)
{
  WINDOW *win;
  OBJECT *tree;
	static char *sn;

	sn=malloc(sizeof(char)*40);   /* MGD FIXME This is a memory leak! */
	sn[0]=0;
  rsrc_gaddr(0, NEWIM, &tree);
  ObjcString(tree, NEWIM_SCREENNAME, sn);
  win=FormCreate(tree, NAME|MOVER|CLOSER, NULL, "New Instant Message", NULL, 1, 0);
	ObjcAttach(OC_FORM, win, NEWIM_OKAY, BIND_FUNC, newim_okay);
	ObjcAttach(OC_FORM, win, NEWIM_CANCEL, BIND_FUNC, newim_cancel);
}

void addbuddy_okay(WINDOW *win, int index)
{
	OBJECT *tree;
	char *sn;
	
  rsrc_gaddr(0, ADDBUDDY, &tree);
	sn=ObjcString(tree, ADDBUDDY_SCREENNAME, NULL);
	ObjcChange(OC_FORM, win, ADDBUDDY_OKAY, NORMAL, TRUE);
	add_buddy(sn);
	Destroy(win);
}

void addbuddy_cancel(WINDOW *win, int index)
{
	ObjcChange(OC_FORM, win, ADDBUDDY_CANCEL, NORMAL, TRUE);
	Destroy(win);
}

void addbuddy_create(void)
{
  WINDOW *win;
  OBJECT *tree;
	static char *sn;

	sn=malloc(sizeof(char)*40);
	sn[0]=0;
  rsrc_gaddr(0, ADDBUDDY, &tree);
  ObjcString(tree, ADDBUDDY_SCREENNAME, sn);
  win=FormCreate(tree, NAME|MOVER|CLOSER, NULL, "Add Buddy", NULL, 1, 0);
	ObjcAttach(OC_FORM, win, ADDBUDDY_OKAY, BIND_FUNC, addbuddy_okay);
	ObjcAttach(OC_FORM, win, ADDBUDDY_CANCEL, BIND_FUNC, addbuddy_cancel);
}

void getinfo_okay(WINDOW *win, int index)
{
	OBJECT *tree;
	char *sn;
	
  rsrc_gaddr(0, GETINFO, &tree);
	sn=ObjcString(tree, GETINFO_SCREENNAME, NULL);
	ObjcChange(OC_FORM, win, GETINFO_OKAY, NORMAL, TRUE);
	Destroy(win);
	aim_getinfo(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), sn, AIM_GETINFO_GENERALINFO);
}

void getinfo_cancel(WINDOW *win, int index)
{
	ObjcChange(OC_FORM, win, GETINFO_CANCEL, NORMAL, TRUE);
	Destroy(win);
}

void getinfo_create(void)
{
  WINDOW *win;
  OBJECT *tree;
	static char *sn;

	sn=malloc(sizeof(char)*40);   /* MGD FIXME This is a memory leak! */
	sn[0]=0;
  rsrc_gaddr(0, GETINFO, &tree);
  ObjcString(tree, GETINFO_SCREENNAME, sn);
  win=FormCreate(tree, NAME|MOVER|CLOSER, NULL, "Get User Info", NULL, 1, 0);
	ObjcAttach(OC_FORM, win, GETINFO_OKAY, BIND_FUNC, getinfo_okay);
	ObjcAttach(OC_FORM, win, GETINFO_CANCEL, BIND_FUNC, getinfo_cancel);
}

void prefs_okay(WINDOW *win, int index)
{	
	ObjcChange(OC_FORM, win, CONFIG_OKAY, NORMAL, TRUE);
	Destroy(win);	
	save_prefs();
}

void prefs_cancel(WINDOW *win, int index)
{
	ObjcChange(OC_FORM, win, CONFIG_CANCEL, NORMAL, TRUE);
	Destroy(win);
}

void prefs_apply(WINDOW *win, int index)
{
	ObjcChange(OC_FORM, win, CONFIG_APPLY, NORMAL, TRUE);
	save_prefs();
}

void prefs_blist_font(WINDOW *win, int index)
{
	OBJECT *tree;
	int fontid, size=0;
	char name[60];
	static char buf[64];

	rsrc_gaddr(0, CONFIG, &tree);
	ObjcChange(OC_FORM, win, CONFIG_BLIST_FONT_BUTTON, NORMAL, TRUE);
	FontSel("Buddylist Font", "Buddy Entry", MONOSPACED, &fontid, &size, name);
	FontId2Name(fontid, buf);
	ObjcString(tree, CONFIG_BLIST_FONT_BUTTON, buf);
	prefs->blistfontid=fontid;
	prefs->blistfontsize=size;

	/* FIXME Ermm yeah  We need to adjust slider sizes when the fonts change... hrmm */
}

void prefs_conv_font(WINDOW *win, int index)
{
	OBJECT *tree;
	int fontid, size=0;
	char name[60];
	static char buf[64];

	rsrc_gaddr(0, CONFIG, &tree);
	ObjcChange(OC_FORM, win, CONFIG_CONV_FONT_BUTTON, NORMAL, TRUE);
	FontSel("Conversation Font", "Hey buddy what's up?", 0, &fontid, &size, name);
	FontId2Name(fontid, buf);
	ObjcString(tree, CONFIG_CONV_FONT_BUTTON, buf);
	prefs->convfontid=fontid;
	prefs->convfontsize=size;
}

void prefs_conv_infont(WINDOW *win, int index)
{
	OBJECT *tree;
	int fontid, size=0;
	char name[60];
	static char buf[64];

	rsrc_gaddr(0, CONFIG, &tree);
	ObjcChange(OC_FORM, win, CONFIG_CONV_INFONT, NORMAL, TRUE);
	FontSel("Conversation Input Font", "Hey buddy what's up?", MONOSPACED, &fontid, &size, name);
	FontId2Name(fontid, buf);
	ObjcString(tree, CONFIG_CONV_INFONT, buf);
	prefs->convinfontid=fontid;
	prefs->convinfontsize=size;
}

void prefs_info_font(WINDOW *win, int index)
{
	OBJECT *tree;
	int fontid, size=0;
	char name[60];
	static char buf[64];

	rsrc_gaddr(0, CONFIG, &tree);
	ObjcChange(OC_FORM, win, CONFIG_INFO_FONT, NORMAL, TRUE);
	FontSel("Buddy Info Font", "This is how my profile would look", MONOSPACED, &fontid, &size, name);
	FontId2Name(fontid, buf);
	ObjcString(tree, CONFIG_INFO_FONT, buf);
	prefs->infofontid=fontid;
	prefs->infofontsize=size;
}

void do_prefs(void)
{
	WINDOW *win;
	OBJECT *tree;
	char *buf1, *buf2, *buf3, *buf4;
	
	rsrc_gaddr(0, CONFIG, &tree);
	buf1=malloc(sizeof(char)*64);
	buf2=malloc(sizeof(char)*64);
	buf3=malloc(sizeof(char)*64);
	buf4=malloc(sizeof(char)*64);
	FontId2Name(prefs->blistfontid, buf1);
	FontId2Name(prefs->convfontid, buf2);
	FontId2Name(prefs->convinfontid, buf3);
	FontId2Name(prefs->infofontid, buf4);
	printf("Fonts: %s, %s, %s, %s\n", buf1, buf2, buf3, buf4);
	ObjcString(tree, CONFIG_BLIST_FONT_BUTTON, buf1);
	ObjcString(tree, CONFIG_CONV_FONT_BUTTON, buf2);
	ObjcString(tree, CONFIG_CONV_INFONT, buf3);
	ObjcString(tree, CONFIG_INFO_FONT, buf4);
	win=FormCreate(tree, NAME|MOVER|CLOSER, NULL, "GIM Preferences", NULL, 1, 0);
	ObjcAttach(OC_FORM, win, CONFIG_OKAY, BIND_FUNC, prefs_okay);
	ObjcAttach(OC_FORM, win, CONFIG_CANCEL, BIND_FUNC, prefs_cancel);
	ObjcAttach(OC_FORM, win, CONFIG_APPLY, BIND_FUNC, prefs_apply);
	ObjcAttach(OC_FORM, win, CONFIG_BLIST_FONT_BUTTON, BIND_FUNC, prefs_blist_font);
	ObjcAttach(OC_FORM, win, CONFIG_CONV_FONT_BUTTON, BIND_FUNC, prefs_conv_font);
	ObjcAttach(OC_FORM, win, CONFIG_CONV_INFONT, BIND_FUNC, prefs_conv_infont);
	ObjcAttach(OC_FORM, win, CONFIG_INFO_FONT, BIND_FUNC, prefs_info_font);
}

void do_logon_form(struct faimtest_priv *priv)
{
	OBJECT *tree;
	WINDOW *win;
	int res;
	char sn[40]="", passwd[40]="";
	
	rsrc_gaddr(0, LOGON, &tree);
	ObjcString(tree, LOGON_SCREENNAME, sn);
	ObjcString(tree, LOGON_PASSWORD, passwd);
	win=FormWindBegin(tree, "Logon to AIM");
	res=FormWindDo(MU_MESAG);
	if (res==LOGON_EXIT)
	{
		FormWindEnd();
		RsrcXtype(0, NULL, 0);
		RsrcFree();
		ApplExit();
		exit(0);
	}
	FormWindEnd();
	priv->screenname=strdup(ObjcString(tree, LOGON_SCREENNAME, NULL));
	priv->password=strdup(ObjcString(tree, LOGON_PASSWORD, NULL));
}

void delete_buddylist(WINDOW *win)
{
	buddylist_t *blist = DataSearch(win, BLST);
	buddylist_t *blisttemp;
	
	if (blist)
	{
		DataDelete(win, BLST);
		while (blist->next!=NULL)
		{
			free(blist->screenname);
			blisttemp=blist->next;
			free(blist);
			blist=blisttemp;
		}
	}
}

/* blist_click
   This function is activated when a user clicks on the buddylist */

static void blist_click(WINDOW *win)
{
	short int x, y, w, h, attr[10], hcell;
	int count=0, done=0;
	buddylist_t *blist;

#ifdef __GIM_DEBUG__
	printf("Mouse X: %d, Mouse Y: %d\n", evnt.mx, evnt.my);
#endif

	WindGet(mainwin, WF_WORKXYWH, &x, &y, &w, &h);
	h += y-1;
	vst_font(mainwin->graf.handle, prefs->blistfontid);
	vqt_attributes(mainwin->graf.handle, attr);
	hcell = HCELL;

	while(!done)
	{
		y+=hcell;
		count++;
		if (evnt.my<=y)
			done=1;
	}
	
	blist=get_buddy_pos(count);
	if (blist)
	{
#ifdef __GIM_DEBUG__
		printf("You clicked on: %s!\n", blist->screenname);
		printf("Out count is %d\n", count);
#endif
		buddy_selected(blist->screenname);
		EvntRedraw(mainwin);
		
		sleep(1);
		
		initiate_conversation(blist->screenname);
		buddy_unselected(blist->screenname);
		EvntRedraw(mainwin);
	}
#ifdef __GIM_DEBUG__
	else
		printf("Blist was null\n");
		
	printf("Our blist count is: %d\n", count);
#endif
}

void draw_buddylist(WINDOW *win)
{
	short int x, y, w, h, attr[10];
	short int hcell;
	buddylist_t *blist = DataSearch(win, BLST);
	int count=0;
	
	WindGet(win, WF_WORKXYWH, &x, &y, &w, &h);
	
	WindClear(win);
	vswr_mode(win->graf.handle, MD_TRANS);
	vst_font(win->graf.handle, prefs->blistfontid);
	vst_point(win->graf.handle, prefs->blistfontsize, NULL, NULL, NULL, NULL);
	vqt_attributes(win->graf.handle, attr);
	hcell = HCELL;
	
	while (blist)
	{
		if (blist->online)
		{
			if (count>=(int)win->ypos)
			{	
				y += hcell;
				if (strlen(blist->screenname)>win->xpos)
				{
					if (blist->away)
						vst_effects(win->graf.handle, TXT_LIGHT);
					if (blist->selected)
						vst_effects(win->graf.handle, TXT_THICKENED);
					v_gtext(win->graf.handle, x, y, blist->screenname + win->xpos);
					if (blist->selected || blist->away)
						vst_effects(win->graf.handle, TXT_NORMAL);
				}
			}
			count++;
		}
		blist=blist->next;
	}
}

/* add_to_buddylist
   This function adds a buddy to the end of the buddylist */

void add_to_buddylist(WINDOW *win, char *data)
{
	int found=0,iterations=0;
	buddylist_t *blist = DataSearch(win, BLST);
	buddylist_t *blisttemp;

	while (blist)
	{
		iterations=iterations+1;
		if (strcasecmp(data, blist->screenname)==0)
		{
#ifdef __GIM_DEBUG__
			printf("We've found a match while adding, not doing so\n");
			printf("Our match was found after %d iterations\n", iterations);
#endif
			found=1;
		}
#ifdef __GIM_DEBUG__
		printf("addtolist: looking at %s\n", blist->screenname);
#endif
		blist=blist->next;
	}
	
	blist=DataSearch(win, BLST);
	/* renavigate to the appropiate spot */
	while (blist->next)
		blist=blist->next;
	
	/* now we SHOULD be at the end of the list, lets make sure
	   Also, we don't add if we already found the buddy in the list */
	
	if (blist->next==NULL && !found)
	{
		blisttemp=malloc(sizeof(buddylist_t));
		blisttemp->next=NULL;
		blisttemp->screenname=strdup(data);
		blist->next=blisttemp;
#ifdef __GIM_DEBUG__
		printf("I've just added %s and it should match %s\n", data, blisttemp->screenname);
#endif
	}
	return;
}

/* remove_from_buddylist
   This function picks through the buddylist linked list, deletes a node
   and links the prior record to the next record */

void remove_from_buddylist(WINDOW *win, char *data)
{
	buddylist_t *blist = DataSearch(win, BLST);
	buddylist_t *blisttemp;
	char *p;
	
	while (blist)
	{
		if (blist->next)
			blisttemp=blist->next;
		else
			blisttemp=blist;
#ifdef __GIM_DEBUG__
		printf("We're comparing %s and %s\n", blisttemp->screenname, data);
#endif
		if (!strcasecmp(blisttemp->screenname, data))
		{
#ifdef __GIM_DEBUG__
			printf("Found sn %s in the linked list, deleting\n", data);
#endif
			p=blisttemp->screenname;
			if (blisttemp->next)
				blist->next=blisttemp->next;
			free(p);
			free(blisttemp);
		}
		blist=blist->next;
	}	
	return;
}

/* draw_mono_icon
   This function draws the GIM icon when the buddylist window is minimized */

void draw_mono_icon( WINDOW *win) {
	OBJECT *tree = get_tree(GIM_ICN);
	INT16 w, h;
	
	WindGet( win, WF_WORKXYWH, &tree->ob_x, &tree->ob_y, &w, &h);
	objc_draw( tree, 0, 2, clip.g_x, clip.g_y, clip.g_w, clip.g_h);
}

/* Create_Buddylist_Window
   This function creates the window handle and basic foundation for the buddylist
   window */

WINDOW *Create_Buddylist_Window(int attrib)
{
	WINDOW *win;
	buddylist_t *blist;
	INT16 attr[10];
	
	win = WindCreate(attrib, app.x, app.y, app.w, app.h);
	mainwin=win;
	blist=create_buddylist();
	WindSetStr(win, WF_ICONTITLE, "GIM");
	WindSetPtr(win, WF_ICONDRAW, draw_mono_icon, NULL);
	EvntAdd(win, WM_REDRAW, draw_buddylist, EV_BOT);
	EvntAttach(NULL, WM_XBUTTON, blist_click);
	EvntAdd(win, WM_DESTROY, delete_buddylist, EV_TOP);
	vst_font(win->graf.handle, prefs->blistfontid);
	vst_point(win->graf.handle, prefs->blistfontsize, NULL, NULL, NULL, NULL);
	vqt_attributes(win->graf.handle, attr);
	win->w_u=WCELL;  /* set slider unit to be the size of a character cell */
	win->h_u=HCELL;
	win->ypos_max=50; /* Number of lines the window is or maximum maybe? */
	/* maybe we should dynamically update the ypos based on how many blist entries
	hrmm indeed! let's add a FIXME for that */
	win->xpos_max=50;
	WindSetStr(win, WF_NAME, "Buddy List");
	WindSlider(win, VSLIDER);
	return win;
}

/* destroy_all_conversations
   This function walks the conversation linked list and frees the mem held by each
   one */

void destroy_all_conversations(void)
{
	conversation_t *conversation, *nextconv;
	
	conversation=DataSearch(mainwin, CONV);
#ifdef __GIM_DEBUG__
	printf("Starting the free conversation\n");
#endif
	while (conversation)
	{
#ifdef __GIM_DEBUG__
		printf("Freeing a conversation\n");
#endif
		nextconv=conversation->next;
		destroy_conversation_winclose(conversation->win);
		conversation=nextconv;
	}
}