#include <stdio.h>
#include <windom.h>
#include <aim.h>

typedef struct away_array_s {
	char *title;
	char *message;
	struct away_array_s *next;
} away_array_t;

typedef struct prefs_params_s {
	int blistfontid;
	int blistfontsize;
	int convfontid;
	int convfontsize;
	int convinfontid;
	int convinfontsize;
	int infofontid;
	int infofontsize;
	short int x;
	short int y;
	short int w;
	short int h;
	char *profile;
	int away_count;
	struct away_array_s *away_array;
} prefs_params_t;

prefs_params_t *prefs;

void save_prefs(void)
{
	FILE *fp;
	away_array_t *away_array;
	
	fp=fopen("./gim.cnf", "w");
	if (!fp)
	{
		printf("There was a serious error creating the GIM Config file\n");
		exit(1);
	}
	else
	{
		fprintf(fp, "#This config file is NOT user editable!\n#Please do not edit or you may crash!\n");
		fprintf(fp, "protocol_version=1\n");
		fprintf(fp, "blist_font=%d\n", prefs->blistfontid);
		fprintf(fp, "blist_font_size=%d\n", prefs->blistfontsize);
		fprintf(fp, "conv_font=%d\n", prefs->convfontid);
		fprintf(fp, "conv_font_size=%d\n", prefs->convfontsize);
		fprintf(fp, "conv_in_font=%d\n", prefs->convinfontid);
		fprintf(fp, "conv_in_font_size=%d\n", prefs->convinfontsize);
		fprintf(fp, "info_font=%d\n", prefs->infofontid);
		fprintf(fp, "info_font_size=%d\n", prefs->infofontsize);
		fprintf(fp, "window_x=%d\n", prefs->x);
		fprintf(fp, "window_y=%d\n", prefs->y);
		fprintf(fp, "window_w=%d\n", prefs->w);
		fprintf(fp, "window_h=%d\n", prefs->h);
		fprintf(fp, "profile=%s\n", prefs->profile);
		fprintf(fp, "away_count=%d\n", prefs->away_count);
		away_array=prefs->away_array;
		while (away_array)
		{
			fprintf(fp, "away_title=%s\naway_message=%s\n", away_array->title, away_array->message);
			away_array=away_array->next;
		}
		fclose(fp);
	}
}

void create_prefs(void)
{
	prefs=malloc(sizeof(prefs_params_t));
	prefs->blistfontid=1;
	prefs->convfontid=1;
	prefs->convinfontid=1;
	prefs->infofontid=1;
	prefs->blistfontsize=9;
	prefs->convfontsize=9;
	prefs->convinfontsize=9;
	prefs->infofontsize=9;
	prefs->x=0;
	prefs->y=0;
	prefs->w=0;
	prefs->h=0;
	prefs->profile=malloc(sizeof(char)*4096);
	strcpy(prefs->profile, "This is your first GIM Profile");
	prefs->away_count=1;
	prefs->away_array=malloc(sizeof(struct away_array_s));
	prefs->away_array->title="Sample Away Title";
	prefs->away_array->message="Sample Away Message";
	prefs->away_array->next=NULL;	
	save_prefs();
}

void load_prefs(void)
{
	FILE *fp;
	size_t len=0;
	static char buf1[64], buf2[64], buf3[64], buf4[64];
	char *line=NULL, *tempbuf=NULL;
	away_array_t *away_array = NULL;
	int i=0, j=0, count=0;

	fp=fopen("./gim.cnf", "r");
	if (!fp)
	{
		printf("Creating config\n");
		create_prefs();
		fp=fopen("./gim.cnf", "r");
		if (!fp)
		{
			printf("There was a serious error loading/creating gim config file\n");
			exit(1);
		}
	}
	else
	{
		prefs=malloc(sizeof(prefs_params_t));

		/* First two lines are comments */
		getdelim(&line, &len, '\n', fp);
		getdelim(&line, &len, '\n', fp);

		/* Check protocol version and upgrade configuration if necessary */
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=i;line[j]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		if (atoi(tempbuf)==1)
			/* Do Nothing! */;
		free(tempbuf);

		/* Buddy list font id and size*/
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=i;line[j]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		prefs->blistfontid=atoi(tempbuf);
		free(tempbuf);
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=i;line[j]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		prefs->blistfontsize=atoi(tempbuf);
		free(tempbuf);

		/* conversation font id and size */
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=i;line[j]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		prefs->convfontid=atoi(tempbuf);
		free(tempbuf);
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=i;line[j]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		prefs->convfontsize=atoi(tempbuf);
		free(tempbuf);
		
		/* Conversation input font id and size */
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=i;line[j]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		prefs->convinfontid=atoi(tempbuf);
		free(tempbuf);
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=i;line[j]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		prefs->convinfontsize=atoi(tempbuf);
		free(tempbuf);

		/* Info font id and size */
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=i;line[j]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		prefs->infofontid=atoi(tempbuf);
		free(tempbuf);
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=i;line[j]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		prefs->infofontsize=atoi(tempbuf);
		free(tempbuf);
		
		/* window size/position */
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=i;line[j]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		prefs->x=atoi(tempbuf);
		free(tempbuf);
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=i;line[j]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		prefs->y=atoi(tempbuf);
		free(tempbuf);		
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=i;line[j]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		prefs->w=atoi(tempbuf);
		free(tempbuf);
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=i;line[j]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		prefs->h=atoi(tempbuf);
		free(tempbuf);
		
		
		/* Profile */
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=0;line[j+i]!='\n';j++);
		tempbuf=malloc(sizeof(char)*4096);
		strncpy(tempbuf, i+line, j);
		tempbuf[j]='\0';
		prefs->profile=tempbuf;
		
		//printf("Our loaded profile is: %s\n", prefs->profile);
		
		/* Away Message Count */
		getdelim(&line, &len, '\n', fp);
		for (i=0;line[i]!='=';i++);
		i++;
		for (j=0;line[j+i]!='\n';j++);
		tempbuf=malloc(sizeof(char)*(j+1));
		strncpy(tempbuf, i+line, j);
		tempbuf[j]='\0';
		prefs->away_count=atoi(tempbuf);
		free(tempbuf);
		
		//printf("Our loaded away count is: %d\n", prefs->away_count);
		
		/* Away Messages */

		while (count<prefs->away_count)
		{
			if (!away_array)
			{	
				away_array=malloc(sizeof(struct away_array_s));
				prefs->away_array=away_array;
			}
			else
			{
				away_array->next=malloc(sizeof(struct away_array_s));
				away_array=away_array->next;
			}
			getdelim(&line, &len, '\n', fp);
			for (i=0;line[i]!='=';i++);
			i++;
			for (j=0;line[j+i]!='\n';j++);
			tempbuf=malloc(sizeof(char)*(j+1));
			strncpy(tempbuf, i+line, j);
			away_array->title=tempbuf;
			tempbuf[j]='\0';
			
			getdelim(&line, &len, '\n', fp);
			for (i=0;line[i]!='=';i++);
			i++;
			for (j=0;line[j+i]!='\n';j++);
			tempbuf=malloc(sizeof(char)*(j+1));
			strncpy(tempbuf, i+line, j);
			away_array->message=tempbuf;
			tempbuf[j]='\0';
			count++;
		}
		away_array->next=NULL;
		
		FontId2Name(prefs->blistfontid, buf1);
		FontId2Name(prefs->convfontid, buf2);
		FontId2Name(prefs->convinfontid, buf3);
		FontId2Name(prefs->infofontid, buf4);

		//printf("Config params: %s - %s - %s - %s\n%d - %d - %d - %d\n", buf1, buf2, buf3, buf4, prefs->blistfontsize, prefs->convfontsize, prefs->convinfontsize, prefs->infofontsize);
		//printf("Font IDs: %d, %d, %d, %d\n", prefs->blistfontid, prefs->convfontid, prefs->convinfontid, prefs->infofontid);
		fclose(fp);
	}
}
