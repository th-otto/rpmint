#include <scancode.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <windom.h>
#include <sys/stat.h>
#include "gim_faim.h"
#include "faimfunc.h"
#include "gim.rsh"
#include "config.h"

/* external vars can hover around main */
int lines=1;
aim_session_t aimsess;
int keepgoing=1;
int timer=0;
int size_change_flag=0;


typedef struct buddylist_s {
	char *screenname;
	short int selected;
	short int highlighted;
	short int online;
	short int away;
	struct aim_userinfo_s *userinfo;
	char *prof;
	struct buddylist_s *next;
} buddylist_t;

#include "buddfunc.h"
#include "aes.h"

void destroy_mainwin_nowinclose(WINDOW *win, int index)
{
	destroy_all_conversations();
	save_blist();
	Destroy(win);
	while (wglb.first) 
	{
		ApplWrite((int)wglb.first, WM_DESTROY,0,0,0,0,0);
		EvntWindom(MU_MESAG);
	}
	aim_session_kill(&aimsess);
	logout(&aimsess);
	RsrcXtype(0, NULL, 0);
	RsrcFree();
	ApplExit();
	exit(0);
}

void quit_gim(WINDOW *win, short buff[8])
{
	char *str;

					str=get_string(QUITSURE);
					if (form_alert(1, str)==1)
					{
						save_blist();
						destroy_all_conversations();
						Destroy(win);
						while (wglb.first) {
							ApplWrite((int)wglb.first, WM_DESTROY,0,0,0,0,0);
							EvntWindom(MU_MESAG);
						}
						aim_session_kill(&aimsess);
  					logout(&aimsess);
						RsrcXtype(0, NULL, 0);
						RsrcFree();
						ApplExit();
						exit(0);
					}
}

void menu_binding(WINDOW *win)
{
	ObjcAttachMenuFunc(win, MAINMEN_QUIT, quit_gim, NULL);
	ObjcAttachMenuFunc(win, MAINMEN_ABOUT, about_gim, NULL);
	ObjcAttachMenuFunc(win, MAINMEN_ADDBUDDY, addbuddy_create, NULL);
	ObjcAttachMenuFunc(win, MAINMEN_JOINCHAT, print_buddylist, NULL);
	ObjcAttachMenuFunc(win, MAINMEN_NEWIM, new_im_create, NULL);
	ObjcAttachMenuFunc(win, MAINMEN_SETAWAY, set_away, NULL);
	ObjcAttachMenuFunc(win, MAINMEN_CHANGEINFO, create_set_info_window, NULL);
	ObjcAttachMenuFunc(win, MAINMEN_GETUSERINFO, getinfo_create, NULL);
	ObjcAttachMenuFunc(win, MAINMEN_PREFS, do_prefs, NULL);
}

void main_moved(WINDOW *win, short buff[8])
{
			timer=100;
			if (!size_change_flag)
		  	WindSetStr(win, WF_NAME, "(*) Gem Instant Messenger");
			size_change_flag=1;
			prefs->x=buff[4];
			prefs->y=buff[5];
			prefs->w=buff[6];
			prefs->h=buff[7];
}

int main(void)
{
	OBJECT *menu, *abouttree;
	WINDOW *win;
	extern WINDOW *mainwin;
	int res, title;
	int selstat = 0;

	/* Aim stuff */
	aim_conn_t *waitingconn = NULL;
	int connectstat=0;
	static int faimtest_mode = 0;
	struct timeval tv;
	time_t lastnop = 0;
	const char *buddyiconpath = NULL;
	struct faimtest_priv priv = {NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
															 0, NULL, NULL, NULL, 0, 0, 0};
	int testmode=0;
  
  ApplInit();

  if (sys_type() & SYS_MINT)
	{
		if (!RsrcLoad("GIM.RSC"))
		{
			form_alert(1, "[1][Resource File Not Found!][End]");
			ApplExit();
			exit(0);
		}
	}
	else
	{
		form_alert(1, "[1][GIM Unfortunately depends on MiNT.  Sorry.][End]");
		ApplExit();
		exit(0);
	}  

  RsrcXtype(1, NULL, 0);

  menu=get_tree(MAINMEN);
  abouttree=get_tree(ABOUTGIM);
 
	load_prefs();  
  priv.server = "login.oscar.aol.com";  
  do_logon_form(&priv);

  aim_session_init(&aimsess, AIM_SESS_FLAGS_NONBLOCKCONNECT, 1);
  aim_setdebuggingcb(&aimsess, faimtest_debugcb);
  aimsess.aux_data = &priv;  

  /* end aim stuff */

  /*MenuBar(menu, 1);  BUG?  Disabled for XaAES.  Perhaps dual menu is bad */

  win=Create_Buddylist_Window(WAT_ALL);
  mainwin=win;
  EvntAdd(win, WM_DESTROY, destroy_mainwin_nowinclose, EV_TOP);
  WindSetStr(win, WF_INFO, "* Status: Offline");
  WindSetPtr(win, WF_MENU, menu, menu_hilight);
  WindSetStr(win, WF_NAME, "Gem Instant Messenger");
 
  menu_binding(win);
  
  if (!prefs->x || !prefs->y || !prefs->w || !prefs->h)
  {
  	/* Reset config due to invalid format */
  	prefs->x=app.x;
  	prefs->y=app.y;
  	prefs->w=app.w/4;
  	prefs->h=app.h/2;
  	save_prefs();
  }
  WindOpen(win, prefs->x, prefs->y, prefs->w, prefs->h);

 	if (buddyiconpath) 
 	{
		struct stat st;
		FILE *f;

		if ((stat(buddyiconpath, &st) != -1) && (st.st_size <= MAXICONLEN) && (f = fopen(buddyiconpath, "r"))) 
		{
			priv.buddyiconlen = st.st_size;
			priv.buddyiconstamp = st.st_mtime;
			priv.buddyicon = malloc(priv.buddyiconlen);
			fread(priv.buddyicon, 1, st.st_size, f);
			priv.buddyiconsum = aim_iconsum(priv.buddyicon, priv.buddyiconlen);
			printf("read %d bytes of %s for buddy icon (sum 0x%08x)\n", priv.buddyiconlen, buddyiconpath, priv.buddyiconsum);
			fclose(f);
		} 
		else
			printf("could not open buddy icon %s\n", buddyiconpath);
	}

	faimtest_init();

	if (login(&aimsess, priv.screenname, priv.password) == -1) 
		exit(-1);
	
	if (!strcmpi("test", priv.screenname))
		testmode=1; 
	
	evnt_timer(500);

	while(keepgoing)
	{
		res=EvntWindom(MU_MESAG|MU_TIMER);

		if (timer)
			timer--;
		if (!timer && size_change_flag)
		{
			size_change_flag=0;
		  WindSetStr(win, WF_NAME, "Gem Instant Messenger");
			save_prefs();
		}
		EvntAdd(mainwin, WM_MOVED, main_moved, EV_BOT);
		EvntAdd(mainwin, WM_SIZED, main_moved, EV_BOT);

	
  /* insert aim eventloop code */  
	/* FIXME - in the long run, this needs to be gone over and better integrated */
	
	if (!testmode)
	{
	tv.tv_sec = 0;
	tv.tv_usec = 500;

  waitingconn = aim_select(&aimsess, &tv, &selstat);
  if (priv.connected && ((time(NULL) - lastnop) > 30)) {
    lastnop = time(NULL);
    aim_flap_nop(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS));
  }
  if (priv.connected && !connectstat)
  {
  	  WindSetStr(win, WF_INFO, "* Status: Online");
  	  connectstat=1;
 	}

		if (selstat == -1) { /* error */
			keepgoing = 0; /* fall through */
		} else if (selstat == 0) { /* no events pending */
			;
		} else if (selstat == 1) { /* outgoing data pending */
			aim_tx_flushqueue(&aimsess);
		} else if (selstat == 2) { /* incoming data pending */
			if ((faimtest_mode < 2) && (waitingconn->fd == STDIN_FILENO)) {
				// cmd_gotkey used to be here;
			} else {
				if (waitingconn->type == AIM_CONN_TYPE_RENDEZVOUS_OUT) {
					if (aim_handlerendconnect(&aimsess, waitingconn) < 0) {
						printf("connection error (rend out)\n");
						aim_conn_kill(&aimsess, &waitingconn);
					}
				} else {
					if (aim_get_command(&aimsess, waitingconn) >= 0) {
						aim_rxdispatch(&aimsess);
					} else {
						printf("connection error (type 0x%04x:0x%04x)\n", waitingconn->type, waitingconn->subtype);
						/* we should have callbacks for all these, else the library will do the conn_kill for us. */
						if (waitingconn->type == AIM_CONN_TYPE_RENDEZVOUS) {
							if (waitingconn->subtype == AIM_CONN_SUBTYPE_OFT_DIRECTIM)
								printf("disconnected from %s\n", aim_directim_getsn(waitingconn));
							aim_conn_kill(&aimsess, &waitingconn);
						} else
							aim_conn_kill(&aimsess, &waitingconn);
						if (!aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS)) {
							printf("major connection error\n");
							if (faimtest_mode == 2)
								break;
						}
					}
				}
			}
		}
	}	 /* if (!testmode); */
	}
  ApplExit();
  return 0;
}
