#include <stdio.h>
#include <windom.h>
#include <aim.h>
#include "faimfunc.h"
#include "main.h"
#include "gim_faim.h"

/* chat text types */
#define CONV_OTHERUSER 	0
#define CONV_USER				1
#define CONV_SYSTEM			2

typedef struct chat_s
{
	char *text;
	int type;
	struct chat_s *next;
	struct chat_s *prior;
} chat_t;

typedef struct conversation_s 
{
	WINDOW *win;
	char *screenname;
	char *sendbuf;
	int sendbuflen;
	chat_t *chat;
	struct conversation_s *next;
} conversation_t;

#include "aes.h"

/* simple function to figure out how many lines a string is going to take for a 
   non-proportional font accounting for word-wrap.  This could possibly be 
   more efficient */

int get_num_lines_prop(char *string, WINDOW *win, int width)
{
	short int pxy[8];
	short int cw;
	short int i=0;
	int lefttoaccount=0, j=0, line=1;
	
	vqt_extent(win->graf->handle, string, pxy);
	lefttoaccount=pxy[2]-pxy[0];
	while (lefttoaccount>width)
	{
#ifdef __GIM_DEBUG__
		printf("Left to account is still > width\n");
#endif
		while (i<width)
		{
			vqt_width(win->graf->handle, string[j], &cw, NULL, NULL);
			i+=cw;
			j++;
		}
	
		for (j=j;string[j]!=' ';j--)
		{
			vqt_width(win->graf->handle, string[j], &cw, NULL, NULL);
			i-=cw;
		}
	
		lefttoaccount-=i;
		line++;
		j++;
	}
	return line;
}

/* Number of lines a string will take, taking word-wrap into account */

int get_num_lines(char *string, int linelen, int extra)
{
	int templen=0, i=0, accounted=0, lefttoaccount=0, returnval=1;
	
	lefttoaccount=strlen(string)+extra;
	while (lefttoaccount>linelen)
	{
		templen=linelen;
		for (i=(accounted+linelen);string[i]!=' ';i--)
			templen--;
		lefttoaccount-=templen-1;
		accounted+=templen+1;
		returnval++;
	}
	return returnval;
}

void print_buddylist(void)
{
	buddylist_t *blist = DataSearch(mainwin, BLST);

	while (blist)
	{
		/* This will eventually be debug, but for now we keep this to remind us that
		   we need to implement something here.  Some sort of audiovisual cue */
		printf("Buddy: %s is online: %d\n", blist->screenname, blist->online);
		blist=blist->next;
	}
}

chat_t *create_chat(void)
{
	chat_t *chat;
	
	chat=malloc(sizeof(chat));
	chat->text="System: Beginning Conversation";
	chat->next=NULL;
	chat->prior=NULL;
	chat->type=CONV_SYSTEM;
	return chat;
}

void add_conversation(conversation_t *conversation)
{
	conversation_t *original_conv = DataSearch(mainwin, CONV);
	
	while (original_conv->next)
		original_conv=original_conv->next;
	original_conv->next=conversation;
}

conversation_t *create_conversation(char *sn)
{
	conversation_t *conversation;
	
	conversation=malloc(sizeof(conversation_t));
	conversation->screenname=strdup(sn);
	conversation->sendbuf=NULL;
	conversation->sendbuflen=0;
	conversation->chat=create_chat();
	conversation->next=NULL;
	if (DataSearch(mainwin, CONV))
		add_conversation(conversation);
	else
		DataAttach(mainwin, CONV, conversation);
	conversation->win=create_conversation_window(conversation->screenname);
	set_conversation_window_state();
	return conversation;
}

/* Walk the buddy list and return the pointer to a specific buddy */
buddylist_t *get_buddy(char *sn)
{
	buddylist_t *blist = DataSearch(mainwin, BLST);
	while (blist)
	{
		if (!strcasecmp(blist->screenname, sn))
			return blist;
		blist=blist->next;
	}
	return NULL;
}

conversation_t *find_conversation(char *sn)
{
	conversation_t *conversation;
	
	conversation=DataSearch(mainwin, CONV);
	if (conversation)
	{
		while (conversation)
		{
			if (!strcasecmp(sn, conversation->screenname))
				return conversation;
			conversation=conversation->next;
		}	
	}
	else
		return NULL;
	return NULL;
}

conversation_t *find_conversation_by_win(WINDOW *win)
{
	conversation_t *conversation;
	
	conversation=DataSearch(mainwin, CONV);
	if (conversation)
	{
		while (conversation)
		{
			if (conversation->win==win)
				return conversation;
			conversation=conversation->next;
		}
	}
	else
		return NULL;
	return NULL;
}

buddylist_t *add_buddy(char *sn)
{
	buddylist_t *blist = DataSearch(mainwin, BLST);
	conversation_t *conversation; 
	
#ifdef __GIM_DEBUG__
	printf("Running addbuddy function against sn: %s\n", sn);
#endif
	while (blist)
	{
		if (!strcasecmp(blist->screenname, sn))
			return blist;
		blist=blist->next;
	}
	
	blist=DataSearch(mainwin, BLST);
	
	while (blist->next)
		blist=blist->next;
		
	blist->next=malloc(sizeof(buddylist_t));
	blist=blist->next;
	blist->screenname=strdup(sn);
	blist->online=0;
	blist->away=0;
	blist->selected=0;
	blist->next=NULL;

	aim_add_buddy(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), blist->screenname);

	if ((conversation=find_conversation(sn)))
	{
#ifdef __GIM_DEBUG__
		printf("Conversation found on add buddy\n");
#endif
		set_conversation_window_state();
	}
	
#ifdef __GIM_DEBUG__
	if (conversation)
		printf("Conversation is not null in addbuddy\n");
	else
		printf("Conversation is null in addbuddy\n");
#endif
	
	EvntRedraw(mainwin);
	
	return blist;
}

void remove_buddy(char *sn)
{
/* implement based on repaired bywin function ????????????*/
}

void save_blist(void)
{
	buddylist_t *blist = DataSearch(mainwin, BLST);
	FILE *fp;
	
	fp=fopen("./acct1.blt", "w");
	if (!fp)
	{
		printf("There was an error writing the GIM buddy list\n");
		exit(1);
	}
	else
	{
		fprintf(fp, "#This buddylist shouldn't be edited unless\n#you know what you're doing\n");
		while (blist)
		{
			fprintf(fp, "b %s\n", blist->screenname);
			blist=blist->next;
		}
		fclose(fp);
	}
}

buddylist_t *add_buddy_by_win(WINDOW *win, int obj)
{
	buddylist_t *blist = DataSearch(mainwin, BLST);
	conversation_t *conversation; 
	char *sn;
	
	conversation=DataSearch(mainwin, CONV);
	while (conversation)
	{
		if (conversation->win==win)
			break;
		conversation=conversation->next;
	}
	sn=conversation->screenname;
#ifdef __GIM_DEBUG__
	printf("Running addbuddy by win function against sn: %s\n", sn);
#endif
	while (blist)
	{
		if (!strcasecmp(blist->screenname, sn))
			return blist;
		blist=blist->next;
	}
	
	blist=DataSearch(mainwin, BLST);
	
	while (blist->next)
		blist=blist->next;
		
	blist->next=malloc(sizeof(buddylist_t));
	blist=blist->next;
	blist->screenname=strdup(sn);
	blist->online=0;
	blist->selected=0;
	blist->next=NULL;

	aim_add_buddy(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), blist->screenname);

	if ((conversation=find_conversation(sn)))
		set_conversation_window_state();

	return blist;
}

void remove_buddy_by_win(WINDOW *win, int obj)
{
	buddylist_t *blist = DataSearch(mainwin, BLST);
	buddylist_t *priorblist=NULL;
	conversation_t *conversation;
	char *sn=NULL;
	
	conversation=DataSearch(mainwin, CONV);
	while (conversation)
	{
		if (conversation->win==win)
			break;
		conversation=conversation->next;
	}
	sn=conversation->screenname;
	if (sn)
	{
		if (get_buddy(sn))
		{
			while (blist)
			{
#ifdef __GIM_DEBUG__
				printf("Run comparing %s against %s\n", blist->screenname, sn);
#endif
				if (!strcasecmp(blist->screenname, sn))
				{
					/* We have a match */
					aim_remove_buddy(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), sn);
					free(blist->screenname);
					/* Ok here's the fun part, we have to figure out where we're at */
					if (!priorblist)
					{
						/* We're on record 1, lets act accordingly */
						DataAttach(mainwin, BLST, blist->next);
						free(blist);
					}
					else if (!blist->next)
					{
						/* We're on the LAST record, let's act accordingly */
						free(blist);
						priorblist->next=NULL;
					}
					else
					{
						/* We're somewhere in the middle, again act accordingly */
						priorblist->next=blist->next;
						free(blist);
					}
				}
				priorblist=blist;
				blist=blist->next;
			}
		}
#ifdef __GIM_DEBUG__
		else
			printf("Not in the buddy list (get_buddy(sn))\n");
#endif
	}
#ifdef __GIM_DEBUG__
	else
		printf("conversation not found properly (sn is null)\n");
#endif
		
	if ((conversation=find_conversation(sn)))
	{
#ifdef __GIM_DEBUG__
		printf("Conversation found on add buddy\n");
#endif
		set_conversation_window_state();
	}
}

int print_chat(char *sn)
{
	conversation_t *conversation=find_conversation(sn);
	chat_t *chat=conversation->chat;
	
	while (chat)
	{
		printf("%s: %s\n", sn, chat->text);
		chat=chat->next;
	}
	return 0;
}

char *get_latest_chat(conversation_t *conversation)
{
	chat_t *chat=conversation->chat;
	
	while (chat->next)
		chat=chat->next;
	
	return chat->text;
}

/* print_chat_backwards
	 A debugging function used to print a chat backwards */

void print_chat_backwards(conversation_t *conversation)
{
	chat_t *chat=conversation->chat;
	
	while (chat->next)
		chat=chat->next;
		
	while (chat->prior)
	{
		printf("Reverse string: %s\n", chat->text);
		chat=chat->prior;
	}
}

char *get_latest_chat_num(conversation_t *conversation, int num)
{
	int i=0;
	chat_t *chat=conversation->chat;
	
	while (chat->next)
	{
		chat=chat->next;
		i=i+1;
	}
		
	if (num>i)
		return NULL;
		
	i=0;
	while (i<num && chat->prior!=NULL)
	{
		chat=chat->prior;
		i=i+1;
	}
	return chat->text;
}

int get_latest_chat_num_type(conversation_t *conversation, int num)
{
	int i=0;
	chat_t *chat=conversation->chat;
	
	while (chat->next) {
		chat=chat->next;
		i=i+1;
	}
	if (num>i)
		return (-1);
	i=0;
	while (i<num && chat->prior!=NULL) {
		chat=chat->prior;
		i=i+1;
	}
	return chat->type;
}

int initiate_conversation(char *sn)
{
	conversation_t *conversation;

	if (!(conversation=find_conversation(sn)))
		conversation=create_conversation(sn);
	
	WindSet(conversation->win, WF_TOP, conversation->win->handle, 0, 0, 0);
	
	redraw_conversation(conversation->win);
	return 0;
}

int add_to_conversation(char *sn, char *string, int type)
{
	conversation_t *conversation;
	chat_t *chat, *tempchat;
		
	if ((conversation=find_conversation(sn))==NULL)
		conversation=create_conversation(sn);
	chat=conversation->chat;
	while (chat->next)
		chat=chat->next;
	
	if (chat->next==NULL)
	{
		chat->next=malloc(sizeof(chat_t));
		tempchat=chat;
		chat=chat->next;
		chat->next=NULL;
		chat->text=strdup(string);
		chat->type=type;
		chat->prior=tempchat;
	}
	
	redraw_conversation(conversation->win);

/* Serious debugging here.. Let's not ifdef this
	print_chat(sn);
	print_buddylist();*/
	return 0;
}

int free_chat(chat_t *chat)
{
	chat_t *chattemp;
	
	while (chat)
	{
		chattemp=chat->next;
		free(chat->text);
		free(chat);
		chat=chat->next;	
	}
	return 0;
}

int free_conversation(conversation_t *conversation)
{
	conversation_t *convtemp, *nextconv;
	int count=0;
	
	convtemp=DataSearch(mainwin, CONV);
	while (convtemp)
	{
		if (!count)
		{
#ifdef __GIM_DEBUG__
			if (convtemp->screenname)
				printf("convtemp->screenname isn't null\n");
			if (conversation->screenname)
				printf("conversation->screenname isn't null\n");
#endif
			if (!strcasecmp(convtemp->screenname, conversation->screenname))
			{
				free_chat(convtemp->chat);
				free(convtemp->screenname);
				free(convtemp->sendbuf);
				if (convtemp->next)
					DataAttach(mainwin, CONV, convtemp->next);
				else
					DataDelete(mainwin, CONV);
				break;
			}			
		}

		nextconv=convtemp->next;
		if (!strcasecmp(nextconv->screenname, conversation->screenname))
		{
			free_chat(nextconv->chat);
			free(nextconv->screenname);
			free(nextconv->sendbuf);
			if (nextconv->next)
				convtemp->next=nextconv->next;
			else
				convtemp->next=NULL;
		}			
		count++;
		convtemp=convtemp->next;
	}
	return 0;
}

void buddy_online(char *sn)
{
	buddylist_t *blist;
	
	blist=get_buddy(sn);
	if (blist)
		blist->online=1;
	else
	{
		blist=add_buddy(sn);
		blist->online=1;
	}
}

void buddy_offline(char *sn)
{
	buddylist_t *blist;
		
	blist=get_buddy(sn);
	if (blist)
		blist->online=0;
	else
	{
		blist=add_buddy(sn);
		blist->online=0;
	}
}

void buddy_away(char *sn)
{
	buddylist_t *blist;
	
	blist=get_buddy(sn);
	if (blist)
		blist->away=1;
}

void buddy_unaway(char *sn)
{
	buddylist_t *blist;
	
	blist=get_buddy(sn);
	if (blist)
		blist->away=0;
}

void buddy_selected(char *sn)
{
	buddylist_t *blist;
	
#ifdef __GIM_DEBUG__
	printf("Selecting %s\n", sn);
#endif
	blist=get_buddy(sn);
	if (blist)
		blist->selected=1;
#ifdef __GIM_DEBUG__
	else
	{
		printf("Nonexistent buddy\n");
	}
#endif
}

void buddy_unselected(char *sn)
{
	buddylist_t *blist;
	
#ifdef __GIM_DEBUG__
	printf("Unselecting %s\n", sn);
#endif
	blist=get_buddy(sn);
	if (blist)
		blist->selected=0;
#ifdef __GIM_DEBUG__
	else
	{
		printf("Nonexistent buddy\n");
	}
#endif
}

buddylist_t *get_buddy_pos(int pos)
{
	buddylist_t *blist = DataSearch(mainwin, BLST);
	int count=0;
	
	while (blist)
	{
		if (blist->online)
			count++;
		if (count==pos)
			return blist;
		blist=blist->next;
	}
	return NULL;
}

/* create_buddylist
   This creates a basic buddylist from a file on disk.  Later this will be created
   and maintained in program rather than user created (or copied from gaim */

buddylist_t *create_buddylist(void)
{
	buddylist_t *blist=NULL, *blistorig=NULL;
	FILE *fp;
	int i=0, notfirst=0;
	size_t len = 0;
	ssize_t read;
	char *line=NULL;
	char *buf=NULL;

	fp=fopen("./acct1.blt", "r");
	if (!fp)
	{
		printf("Buddylist config not found!\n");
		exit(1);
	}
#ifdef __GIM_DEBUG__
	printf("Beginning buddylist configuration\n");
#endif
	while ((read=getdelim(&line, &len, '\n', fp))!=-1)
	{
		if (line[0]=='b')
		{
			if (notfirst)
			{
				blist->next=malloc(sizeof(buddylist_t));
				blist=blist->next;
			}
			else
			{
				blist=malloc(sizeof(buddylist_t));
				blistorig=blist;
				notfirst=1;
			}
			blist->online=0;
			blist->selected=0;
			blist->away=0;
			buf=malloc(sizeof(char)*strlen(line));
			for (i=2;line[i]!='\n'&&line[i]!='\r';i++)
				buf[i-2]=line[i];
			buf[i-2]='\0';
#ifdef __GIM_DEBUG__
			printf("Our line: %s, our buf %s\n", line, buf);
#endif
			blist->screenname=buf;
			blist->userinfo=NULL;
			blist->prof=NULL;
			blist->next=NULL;
			free(line);
			line=NULL;
		}
	}
	DataAttach(mainwin, BLST, blistorig);
	return blistorig;
}

/* buddylist_init
   This function is used to send a buddylist init string to the Oscar server.  We do
   this because our current versioning is too stupid to use server side buddylists,
   and in fact probably always will be due to the integration of libfaim into gaim.
   Separating out libfaim again is outside the scope of this project, so we just use
   the most recent separate one. */

char *buddylist_init(void)
{
	buddylist_t *blist=NULL;
	char *buf=NULL, *newbuf=NULL;
	int length=0;

	blist=DataSearch(mainwin, BLST);
	buf=malloc(sizeof(char)*8192);
	buf[0]=0;
	while (blist)
	{
		length=length+strlen(blist->screenname)+1;
		sprintf(buf, "%s%s&", buf, blist->screenname);
		blist=blist->next;
	}
	newbuf=malloc(sizeof(char)*length);
	strncpy(newbuf, buf, length);	
#ifdef __GIM_DEBUG__
	printf("Initlist before strcpy: %s\n", buf);
#endif
	free(buf);
#ifdef __GIM_DEBUG__
	printf("Sending init list : %s\n", newbuf);
#endif
	return newbuf; 
}

void im_send_message(char *sn, char *message)
{
	extern aim_session_t aimsess;
	aim_send_im(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), sn, AIM_IMFLAGS_ACK, message);
	add_to_conversation(sn, message, CONV_USER);
}

void set_profile(char *profile)
{
	extern aim_session_t aimsess;
	aim_bos_setprofile(&aimsess, aim_getconn_type(&aimsess, AIM_CONN_TYPE_BOS), profile, "", AIM_CAPS_BUDDYICON | AIM_CAPS_CHAT | AIM_CAPS_GETFILE | AIM_CAPS_SENDFILE | AIM_CAPS_IMIMAGE | AIM_CAPS_GAMES | AIM_CAPS_SAVESTOCKS | AIM_CAPS_SENDBUDDYLIST);
}
