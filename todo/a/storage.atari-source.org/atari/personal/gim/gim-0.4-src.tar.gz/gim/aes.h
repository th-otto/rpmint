#ifndef __AES_H__
#define __AES_H__

#define WTXT 0x57545854L /*WTXT*/
#define BLST 0x57545855L /*BLST*/
#define CONV 0x57545856L /*CONV*/

extern WINDOW *mainwin;
/* We might not need this anymore
extern char *buddylist;*/

#define SYS_TOS    0x0001
#define SYS_MAGIC  0x0002
#define SYS_MINT   0x0004
#define SYS_GENEVA 0x0010
#define SYS_NAES   0x0020
#define SYS_XAAES  0x0040
#define WORD short
#define UWORD unsigned short
extern UWORD _systype_v;
extern UWORD _systype(void);
#define sys_type()    (_systype_v ? _systype_v : _systype())
#define sys_MAGIC()   ((sys_type() & SYS_MAGIC) != 0)
#define sys_NAES()    ((sys_type() & SYS_NAES)  != 0)
#define sys_XAAES()   ((sys_type() & SYS_XAAES) != 0)

void Destroy(WINDOW *win);
char *get_string(int idx);
OBJECT *get_tree(int idx);
void about_gim(void);
void set_conversation_window_state(void);
void not_implemented(char *msg);
void join_chat(void);
void create_info_window(struct aim_userinfo_s *userinfo, char *prof);
void create_set_info_window(void);
void newim_okay(WINDOW *win, int index);
void newim_cancel(WINDOW *win, int index);
void new_im_create(void);
void addbuddy_okay(WINDOW *win, int index);
void addbuddy_cancel(WINDOW *win, int index);
void addbuddy_create(void);
void getinfo_create(void);
void set_away(void);
WINDOW *create_conversation_window(char *sn);
void redraw_conversation(WINDOW *win);
void do_prefs(void);
void do_logon_form(struct faimtest_priv *priv);
void delete_buddylist(WINDOW *win);
void draw_buddylist(WINDOW *win);
void add_to_buddylist(WINDOW *win, char *data);
void remove_from_buddylist(WINDOW *win, char *data);
buddylist_t *CreateBuddylist(void);
void menu_hilight(WINDOW *win, short buff[8]);
WINDOW *Create_Buddylist_Window(int attrib);
void destroy_all_conversations(void);
#endif
