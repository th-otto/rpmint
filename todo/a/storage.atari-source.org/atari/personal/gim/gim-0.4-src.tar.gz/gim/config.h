typedef struct away_array_s {
	char *title;
	char *message;
	struct away_array_s *next;
} away_array_t;

typedef struct prefs_params_s {
	int blistfontid;
	int blistfontsize;
	int convfontid;
	int convfontsize;
	int convinfontid;
	int convinfontsize;
	int infofontid;
	int infofontsize;
	short int x;
	short int y;
	short int w;
	short int h;
	char *profile;
	int away_count;
	away_array_t *away_array;
} prefs_params_t;

extern prefs_params_t *prefs;

void save_prefs(void);
void create_prefs(void);
void load_prefs(void);
